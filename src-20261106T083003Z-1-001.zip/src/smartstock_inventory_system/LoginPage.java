/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Micov
 */
public class LoginPage extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginPage.class.getName());

    /**
     * Creates new form LoginPage
     */
    public LoginPage() {
        initComponents();
        setResizable(false);
    }
    
    


 // ================= ADMIN PANEL =================

    private static final java.awt.Color ADMIN_NAVY = new java.awt.Color(9, 9, 89);
    private static final java.awt.Color ADMIN_ORANGE = new java.awt.Color(255, 179, 0);

    private javax.swing.JLabel adminValueLabel(String text) {
        javax.swing.JLabel label = new javax.swing.JLabel(text);
        label.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 20));
        label.setForeground(ADMIN_ORANGE);
        return label;
    }

    private javax.swing.JLabel adminLabel(String text) {
        javax.swing.JLabel label = new javax.swing.JLabel(text);
        label.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
        label.setForeground(ADMIN_NAVY);
        return label;
    }

    private javax.swing.JPanel adminCard(String title, javax.swing.JLabel valueLabel) {
        javax.swing.JLabel titleLabel = new javax.swing.JLabel(title);
        titleLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
        titleLabel.setForeground(java.awt.Color.WHITE);

        javax.swing.JPanel card = new javax.swing.JPanel(new java.awt.BorderLayout(0, 4));
        card.setBackground(ADMIN_NAVY);
        card.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 14, 10, 14));
        card.add(titleLabel, java.awt.BorderLayout.NORTH);
        card.add(valueLabel, java.awt.BorderLayout.CENTER);
        return card;
    }

    private javax.swing.JButton adminButton(String text) {
        javax.swing.JButton button = new javax.swing.JButton(text);
        button.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        button.setBackground(ADMIN_NAVY);
        button.setForeground(java.awt.Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new java.awt.Dimension(110, 34));
        return button;
    }

    private javax.swing.table.DefaultTableModel adminModel(String... columns) {
        return new javax.swing.table.DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void styleAdminTable(javax.swing.JTable table, int... widths) {
        table.setRowHeight(28);
        table.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        table.setBackground(java.awt.Color.WHITE);
        table.setGridColor(new java.awt.Color(230, 230, 230));
        table.setSelectionBackground(new java.awt.Color(255, 220, 150));
        table.setSelectionForeground(java.awt.Color.BLACK);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        table.getTableHeader().setBackground(ADMIN_NAVY);
        table.getTableHeader().setForeground(java.awt.Color.WHITE);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 32));
        table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);

        for (int i = 0; i < widths.length && i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }

    private javax.swing.JScrollPane adminScroll(javax.swing.JTable table) {
        javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(table);
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(ADMIN_NAVY, 1));
        scroll.getViewport().setBackground(java.awt.Color.WHITE);
        return scroll;
    }

    private void showAdminMonitor() {

        final String[] order = {"DESC"};

        final javax.swing.JDialog dialog =
                new javax.swing.JDialog(this, "Admin Panel", true);

        
        final javax.swing.JLabel lblUsers = adminValueLabel("0");
        final javax.swing.JLabel lblProducts = adminValueLabel("0");
        final javax.swing.JLabel lblIn = adminValueLabel("0");
        final javax.swing.JLabel lblOut = adminValueLabel("0");
        final javax.swing.JLabel lblRevenue = adminValueLabel("₱0.00");
        final javax.swing.JLabel lblAlerts = adminValueLabel("0 / 0");

        // ---------- tables ----------
        final javax.swing.table.DefaultTableModel usersModel = adminModel(
                "ID", "Username", "Full Name", "Role", "Products",
                "Stock In", "Stock Out", "Revenue", "Registered");
        final javax.swing.JTable usersTable = new javax.swing.JTable(usersModel);
        styleAdminTable(usersTable, 40, 110, 160, 60, 80, 80, 80, 110, 170);

        final javax.swing.table.DefaultTableModel lowModel = adminModel(
                "ID", "Owner", "Product", "Category", "Stock", "Status");
        final javax.swing.JTable lowTable = new javax.swing.JTable(lowModel);
        styleAdminTable(lowTable, 40, 130, 220, 130, 80, 100);

        final javax.swing.table.DefaultTableModel activityModel = adminModel(
                "ID", "User", "Activity", "Date & Time");
        final javax.swing.JTable activityTable = new javax.swing.JTable(activityModel);
        styleAdminTable(activityTable, 40, 120, 440, 170);

        
        lowTable.getColumnModel().getColumn(5).setCellRenderer(
                new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(
                    javax.swing.JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                java.awt.Component c = super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column);

                String s = value == null ? "" : value.toString();

                if (!isSelected) {
                    if ("Empty".equals(s)) {
                        c.setForeground(new java.awt.Color(190, 35, 35));
                        c.setBackground(new java.awt.Color(255, 225, 225));
                    } else if ("Low".equals(s)) {
                        c.setForeground(new java.awt.Color(160, 110, 0));
                        c.setBackground(new java.awt.Color(255, 245, 190));
                    } else {
                        c.setForeground(table.getForeground());
                        c.setBackground(table.getBackground());
                    }
                    c.setFont(c.getFont().deriveFont(java.awt.Font.BOLD));
                }
                return c;
            }
        });

      
        final javax.swing.JTextField searchField = new javax.swing.JTextField(16);

        final javax.swing.JComboBox<String> sortBox = new javax.swing.JComboBox<>(
                new String[]{"Newest First", "Oldest First"});

        final javax.swing.table.TableRowSorter<javax.swing.table.DefaultTableModel> userSorter =
                new javax.swing.table.TableRowSorter<>(usersModel);

        for (int i = 0; i < usersModel.getColumnCount(); i++) {
            userSorter.setSortable(i, false);
        }
        usersTable.setRowSorter(userSorter);

        searchField.getDocument().addDocumentListener(
                new javax.swing.event.DocumentListener() {
            private void apply() {
                String text = searchField.getText().trim();
                if (text.isEmpty()) {
                    userSorter.setRowFilter(null);
                } else {
                    userSorter.setRowFilter(javax.swing.RowFilter.regexFilter(
                            "(?i)" + java.util.regex.Pattern.quote(text), 1, 2));
                }
            }

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) { apply(); }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) { apply(); }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) { apply(); }
        });

        javax.swing.JPanel userFilters = new javax.swing.JPanel(
                new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 6));
        userFilters.setOpaque(false);
        userFilters.add(adminLabel("Search user:"));
        userFilters.add(searchField);
        userFilters.add(adminLabel("Sort by registration:"));
        userFilters.add(sortBox);

        javax.swing.JPanel usersTab = new javax.swing.JPanel(new java.awt.BorderLayout(0, 4));
        usersTab.setOpaque(false);
        usersTab.add(userFilters, java.awt.BorderLayout.NORTH);
        usersTab.add(adminScroll(usersTable), java.awt.BorderLayout.CENTER);

        javax.swing.JPanel lowTab = new javax.swing.JPanel(new java.awt.BorderLayout());
        lowTab.setOpaque(false);
        lowTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 0, 0, 0));
        lowTab.add(adminScroll(lowTable), java.awt.BorderLayout.CENTER);

        javax.swing.JPanel activityTab = new javax.swing.JPanel(new java.awt.BorderLayout());
        activityTab.setOpaque(false);
        activityTab.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 0, 0, 0));
        activityTab.add(adminScroll(activityTable), java.awt.BorderLayout.CENTER);


        final String[] tabKeys = {"USERS", "LOW", "ACTIVITY"};
        final String[] tabLabels = {"Users Overview", "Low Stock Alerts", "Recent Activity"};
        final javax.swing.JButton[] navButtons = new javax.swing.JButton[3];

        final java.awt.CardLayout cardLayout = new java.awt.CardLayout();
        final javax.swing.JPanel cardPanel = new javax.swing.JPanel(cardLayout);
        cardPanel.setOpaque(false);
        cardPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12));
        cardPanel.add(usersTab, tabKeys[0]);
        cardPanel.add(lowTab, tabKeys[1]);
        cardPanel.add(activityTab, tabKeys[2]);

        final java.util.function.IntConsumer selectTab = index -> {
            cardLayout.show(cardPanel, tabKeys[index]);
            for (int i = 0; i < navButtons.length; i++) {
                boolean active = i == index;
                navButtons[i].setBackground(active ? ADMIN_NAVY : java.awt.Color.WHITE);
                navButtons[i].setForeground(active ? ADMIN_ORANGE : ADMIN_NAVY);
            }
        };

        javax.swing.JPanel navBar = new javax.swing.JPanel(
                new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 8));
        navBar.setOpaque(false);
        navBar.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 4, 0, 0));

        for (int i = 0; i < tabLabels.length; i++) {
            final int index = i;
            javax.swing.JButton b = new javax.swing.JButton(tabLabels[i]);
            b.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
            b.setFocusPainted(false);
            b.setPreferredSize(new java.awt.Dimension(170, 34));
            b.addActionListener(e -> selectTab.accept(index));
            navButtons[i] = b;
            navBar.add(b);
        }

       
        final Runnable refresh = () -> {

            usersModel.setRowCount(0);
            lowModel.setRowCount(0);
            activityModel.setRowCount(0);

            int totalUsers = 0;
            int totalProducts = 0;
            int unitsIn = 0;
            int unitsOut = 0;
            double revenue = 0.0;
            int lowCount = 0;
            int emptyCount = 0;

            java.time.format.DateTimeFormatter fmt =
                    java.time.format.DateTimeFormatter.ofPattern(
                            "MMM d, yyyy h:mm a", java.util.Locale.US);

            String userSql =
                    "SELECT u.users_id, u.username, u.fullname, u.created_at, "
                    + "COUNT(DISTINCT p.id) AS product_count, "
                    + "COALESCE(MAX(si.qty), 0) AS stock_in, "
                    + "COALESCE(MAX(so.qty), 0) AS stock_out, "
                    + "COALESCE(MAX(so.revenue), 0) AS revenue "
                    + "FROM tbl_users u "
                    + "LEFT JOIN tbl_products p ON p.users_id = u.users_id "
                    + "LEFT JOIN ( "
                    + "SELECT users_id, SUM(quantity) AS qty "
                    + "FROM tbl_stocks_in WHERE status = 'Received' "
                    + "GROUP BY users_id ) si ON si.users_id = u.users_id "
                    + "LEFT JOIN ( "
                    + "SELECT users_id, SUM(quantity) AS qty, "
                    + "SUM(total_amount) AS revenue "
                    + "FROM tbl_stocks_out WHERE status = 'Completed' "
                    + "GROUP BY users_id ) so ON so.users_id = u.users_id "
                    + "GROUP BY u.users_id, u.username, u.fullname, u.created_at "
                    + "ORDER BY u.created_at " + order[0]
                    + ", u.users_id " + order[0];

            String lowSql =
                    "SELECT u.username, p.product_name, p.category, p.stock "
                    + "FROM tbl_products p "
                    + "JOIN tbl_users u ON u.users_id = p.users_id "
                    + "WHERE p.stock <= 10 "
                    + "ORDER BY p.stock ASC, p.product_name ASC";

            String activitySql =
                    "SELECT u.username, a.activity, a.created_at "
                    + "FROM tbl_activity_log a "
                    + "JOIN tbl_users u ON u.users_id = a.users_id "
                    + "ORDER BY a.created_at DESC, a.id DESC LIMIT 100";

            try (Connection conn = DBConnection.connect()) {

                if (conn == null) {
                    JOptionPane.showMessageDialog(dialog,
                            "Cannot connect to the database.",
                            "Database Connection Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Users overview
                try (PreparedStatement pst = conn.prepareStatement(userSql);
                     ResultSet rs = pst.executeQuery()) {

                    while (rs.next()) {
                        String username = rs.getString("username");
                        String role = "admin".equalsIgnoreCase(username) ? "admin" : "user";
                        int products = rs.getInt("product_count");
                        int stockIn = rs.getInt("stock_in");
                        int stockOut = rs.getInt("stock_out");
                        double userRevenue = rs.getDouble("revenue");
                        java.sql.Timestamp created = rs.getTimestamp("created_at");

                        usersModel.addRow(new Object[]{
                            usersModel.getRowCount() + 1,
                            username,
                            rs.getString("fullname"),
                            role,
                            products,
                            stockIn,
                            stockOut,
                            String.format(java.util.Locale.US, "₱%,.2f", userRevenue),
                            created == null ? "-" : created.toLocalDateTime().format(fmt)
                        });

                        totalUsers++;
                        totalProducts += products;
                        unitsIn += stockIn;
                        unitsOut += stockOut;
                        revenue += userRevenue;
                    }
                }

              
                try (PreparedStatement pst = conn.prepareStatement(lowSql);
                     ResultSet rs = pst.executeQuery()) {

                    while (rs.next()) {
                        int stock = rs.getInt("stock");
                        String status = stock == 0 ? "Empty" : "Low";

                        if (stock == 0) {
                            emptyCount++;
                        } else {
                            lowCount++;
                        }

                        lowModel.addRow(new Object[]{
                            lowModel.getRowCount() + 1,
                            rs.getString("username"),
                            rs.getString("product_name"),
                            rs.getString("category"),
                            stock,
                            status
                        });
                    }
                }

                
                ActivityLog.ensureTable(conn);

                try (PreparedStatement pst = conn.prepareStatement(activitySql);
                     ResultSet rs = pst.executeQuery()) {

                    while (rs.next()) {
                        java.sql.Timestamp ts = rs.getTimestamp("created_at");

                        activityModel.addRow(new Object[]{
                            activityModel.getRowCount() + 1,
                            rs.getString("username"),
                            rs.getString("activity"),
                            ts == null ? "-" : ts.toLocalDateTime().format(fmt)
                        });
                    }
                }

                lblUsers.setText(String.valueOf(totalUsers));
                lblProducts.setText(String.valueOf(totalProducts));
                lblIn.setText(String.valueOf(unitsIn));
                lblOut.setText(String.valueOf(unitsOut));
                lblRevenue.setText(String.format(java.util.Locale.US, "₱%,.2f", revenue));
                lblAlerts.setText(lowCount + " / " + emptyCount);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(dialog,
                        "Failed to load admin data:\n" + e.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        };

        sortBox.addActionListener(e -> {
            order[0] = "Oldest First".equals(sortBox.getSelectedItem()) ? "ASC" : "DESC";
            refresh.run();
        });

       
        javax.swing.JLabel title = new javax.swing.JLabel("SmartStock Admin Panel");
        title.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 24));
        title.setForeground(ADMIN_ORANGE);

        javax.swing.JLabel subtitle = new javax.swing.JLabel(
                "Inventory monitoring: users, stock movement and alerts");
        subtitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12));
        subtitle.setForeground(java.awt.Color.WHITE);

        javax.swing.JPanel titleBox = new javax.swing.JPanel(new java.awt.GridLayout(2, 1));
        titleBox.setOpaque(false);
        titleBox.add(title);
        titleBox.add(subtitle);

        javax.swing.JPanel header = new javax.swing.JPanel(new java.awt.BorderLayout());
        header.setBackground(ADMIN_NAVY);
        header.setBorder(javax.swing.BorderFactory.createEmptyBorder(14, 20, 14, 20));
        header.add(titleBox, java.awt.BorderLayout.WEST);

        javax.swing.JPanel accent = new javax.swing.JPanel();
        accent.setBackground(ADMIN_ORANGE);
        accent.setPreferredSize(new java.awt.Dimension(0, 5));

        javax.swing.JPanel headerWrap = new javax.swing.JPanel(new java.awt.BorderLayout());
        headerWrap.add(header, java.awt.BorderLayout.CENTER);
        headerWrap.add(accent, java.awt.BorderLayout.SOUTH);

        
        javax.swing.JPanel cardsRow = new javax.swing.JPanel(new java.awt.GridLayout(1, 6, 10, 0));
        cardsRow.setBackground(ADMIN_ORANGE);
        cardsRow.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 4, 12));
        cardsRow.add(adminCard("USERS", lblUsers));
        cardsRow.add(adminCard("PRODUCTS", lblProducts));
        cardsRow.add(adminCard("STOCK IN (UNITS)", lblIn));
        cardsRow.add(adminCard("STOCK OUT (UNITS)", lblOut));
        cardsRow.add(adminCard("REVENUE", lblRevenue));
        cardsRow.add(adminCard("LOW / EMPTY", lblAlerts));

        javax.swing.JPanel topArea = new javax.swing.JPanel(new java.awt.BorderLayout());
        topArea.add(headerWrap, java.awt.BorderLayout.NORTH);
        topArea.add(cardsRow, java.awt.BorderLayout.CENTER);

        
        javax.swing.JPanel centerArea = new javax.swing.JPanel(new java.awt.BorderLayout());
        centerArea.setBackground(ADMIN_ORANGE);
        centerArea.add(navBar, java.awt.BorderLayout.NORTH);
        centerArea.add(cardPanel, java.awt.BorderLayout.CENTER);

      
        javax.swing.JButton refreshBtn = adminButton("Refresh");
        refreshBtn.addActionListener(e -> refresh.run());

        javax.swing.JButton closeBtn = adminButton("Log Out");
        closeBtn.addActionListener(e -> {
        
            int choice = javax.swing.JOptionPane.showConfirmDialog(dialog, 
                "Are you sure you want to Log out?",
                "Confirm Logout",
                javax.swing.JOptionPane.YES_NO_OPTION,
                javax.swing.JOptionPane.QUESTION_MESSAGE
            );
            
            if (choice == javax.swing.JOptionPane.YES_OPTION) {
                dialog.dispose();
            }
        });

        javax.swing.JPanel bottom = new javax.swing.JPanel(
                new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 8));
        bottom.setBackground(ADMIN_ORANGE);
        bottom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 4, 10));
        bottom.add(refreshBtn);
        bottom.add(closeBtn);

        javax.swing.JPanel main = new javax.swing.JPanel(new java.awt.BorderLayout());
        main.setBackground(ADMIN_ORANGE);
        main.add(topArea, java.awt.BorderLayout.NORTH);
        main.add(centerArea, java.awt.BorderLayout.CENTER);
        main.add(bottom, java.awt.BorderLayout.SOUTH);

        dialog.setDefaultCloseOperation(javax.swing.JDialog.DISPOSE_ON_CLOSE);
        dialog.setContentPane(main);
        dialog.setSize(1020, 640);
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(true);

        selectTab.accept(0);
        refresh.run();

        dialog.setVisible(true);
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        showpass = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Login Account");
        jLabel1.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Username");
        jLabel2.setOpaque(true);

        username.addActionListener(this::usernameActionPerformed);

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Password");
        jLabel3.setOpaque(true);

        showpass.setBackground(new java.awt.Color(0, 0, 0));
        showpass.setForeground(new java.awt.Color(255, 255, 255));
        showpass.setText("Show Passowrd");
        showpass.setOpaque(true);
        showpass.addActionListener(this::showpassActionPerformed);

        jButton1.setBackground(new java.awt.Color(0, 102, 102));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Log In");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(51, 51, 51));
        jButton2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Don't have an Account? Sign Up");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jPanel18.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(showpass)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(password, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 131, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(133, 133, 133))
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(showpass)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(30, 30, 30))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(380, 0, 430, 440);

        jPanel2.setBackground(new java.awt.Color(255, 179, 0));

        jLabel5.setBackground(new java.awt.Color(255, 153, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\user (1).png")); // NOI18N
        jLabel5.setText("Access Account");
        jLabel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel5.setOpaque(true);

        jLabel6.setBackground(new java.awt.Color(255, 255, 0));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\add-user (1).png")); // NOI18N
        jLabel6.setText("New Account");
        jLabel6.setOpaque(true);

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Welcome To SmartStock ");

        jPanel4.setBackground(new java.awt.Color(0, 0, 102));
        jPanel4.setForeground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 293, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));
        jPanel17.setForeground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 295, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(58, 58, 58))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 150, 380, 290);

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        jLabel7.setText("jLabel7");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 380, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(0, 0, 380, 150);

        setSize(new java.awt.Dimension(826, 480));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void showpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showpassActionPerformed
        if(showpass.isSelected()){
            password.setEchoChar((char)0);
        }else{
            password.setEchoChar('*');
        }
    }//GEN-LAST:event_showpassActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String uN = username.getText();
    String pW = new String(password.getPassword());

    if (uN.isEmpty() || pW.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter username and password!");
        return; 
    }
    

    Connection conn = DBConnection.connect();

    try {
        String sql = "SELECT * FROM tbl_users WHERE username= ? AND password= ?";
        PreparedStatement pst = conn.prepareStatement(sql); // ' OR '1'='1 SQL Injection
        pst.setString(1, uN);
        pst.setString(2, pW);

        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
        int userId = rs.getInt("users_id");
            String uname = rs.getString("username");
            String role = "user";
    
        try {
        role = rs.getString("role");
        if (role == null || role.isEmpty()) role = "user";
           } catch (Exception ignore) {
            role = "user";
           }

        UserSession.setUser(userId, uname);
        
        JOptionPane.showMessageDialog(this, "Login successful!");

        if ("admin".equalsIgnoreCase(role)) {
        showAdminMonitor();
        username.setText("");
        password.setText("");
         } else {
        HomePage home = new HomePage();
        home.setVisible(true);
        this.dispose();
        }

        } else {
        JOptionPane.showMessageDialog(this, "Invalid username or password");
        }

        conn.close();
        } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        SignupPage signupForm = new SignupPage();
        signupForm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new LoginPage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPasswordField password;
    private javax.swing.JCheckBox showpass;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
