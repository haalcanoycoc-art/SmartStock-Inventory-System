/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ViewReportPage extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ViewReportPage.class.getName());

    
    
    public ViewReportPage() {
    initComponents();
    setupResponsiveLayout();
    
// ===== Inventory =====
cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{"All Categories", "Supplies", "Office", "Electronics", "Consumables", "Others"}
));
cmbCategory.setSelectedItem("All Categories");

fillDateCombo(jComboBox1); 
jComboBox1.setSelectedItem("All");

fillDateCombo(jComboBox2); 
jComboBox2.setSelectedItem("All");

jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{
            "Select Report",
            "All Products",
            "Available Stock",
            "Low Stock",
            "Out of Stock"
        }
));
jComboBox3.setSelectedItem("Select Report");

// ===== Sales / Stock In =====
jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{"SALES REPORT", "STOCK IN REPORT"}
));
jComboBox8.setSelectedItem("SALES REPORT");

jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{
            "Select Report",
            "All Sales",
            "Completed Sales",
            "Cancelled Sales"
        }
));
jComboBox4.setSelectedItem("Select Report");

jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(
        new String[]{"All Categories", "Supplies", "Office", "Electronics", "Consumables", "Others"}
));
jComboBox5.setSelectedItem("All Categories");

fillDateCombo(jComboBox6); 
jComboBox6.setSelectedItem("All");

fillDateCombo(jComboBox7); 
jComboBox7.setSelectedItem("All");

clearInventorySummary();
clearSalesSummary();
loadInventorySummaryOverall();
loadSalesSummaryOverall();


jComboBox8.addActionListener(e -> applyReportMode());
jButton10.addActionListener(e -> resetInventoryFilters());

   
}
    
    private void resetInventoryFilters() {
        jComboBox3.setSelectedItem("Select Report");
        cmbCategory.setSelectedItem("All Categories");
        jComboBox1.setSelectedItem("All");
        jComboBox2.setSelectedItem("All");
        clearInventorySummary();
        loadInventorySummaryOverall();
    }

    private String[][] summaryOf(javax.swing.JLabel... labels) {
        String[][] rows = new String[labels.length][];
        for (int i = 0; i < labels.length; i++) {
            String text = labels[i].getText() == null ? "" : labels[i].getText().trim();
            int idx = text.indexOf(" : ");
            if (idx >= 0) {
                rows[i] = new String[]{text.substring(0, idx).trim(), text.substring(idx + 3).trim()};
            } else {
                rows[i] = new String[]{text, ""};
            }
        }
        return rows;
    }
    
    private void fillDateCombo(javax.swing.JComboBox<String> combo) {
    combo.removeAllItems();
    combo.addItem("All");

    java.time.LocalDate today = java.time.LocalDate.now();
    for (int i = 0; i <= 60; i++) {
        combo.addItem(today.minusDays(i).toString());
    }
}

    private void clearInventorySummary() {
    jLabel1.setText("Total Products : 0");
    jLabel9.setText("Available : 0");
    jLabel7.setText("Low Stock : 0");
    jLabel5.setText("Empty : 0");
}

    private void clearSalesSummary() {
    jLabel8.setText("Total Sales : ₱0.00");
    jLabel21.setText("Total Transactions : 0");
    jLabel22.setText("Items Sold : 0");
    jLabel23.setText("Average Sale : ₱0.00");
}
    
    private void loadInventorySummaryOverall() {
    int userId = UserSession.getUserId();
    if (userId <= 0) {
        clearInventorySummary();
        return;
    }

    int total = 0;
    int totalStockUnits = 0;
    int low = 0;
    int empty = 0;

    String sql =
            "SELECT stock FROM tbl_products WHERE users_id = ?";

    try (Connection con = DBConnection.connect()) {
        if (con == null) return;

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    int stock = rs.getInt("stock");
                    total++;
                    totalStockUnits += stock;
                    if (stock == 0) {
                        empty++;
                    } else if (stock <= 10) {
                        low++;
                    }
                }
            }
        }

        jLabel1.setText("Total Product : " + total);
        jLabel9.setText("Total Stock Units : " + totalStockUnits);
        jLabel7.setText("Low Stock : " + low);
        jLabel5.setText("Out of Stock : " + empty);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Inventory summary error: " + e.getMessage());
    }
}

private void loadSalesSummaryOverall() {
    int userId = UserSession.getUserId();
    if (userId <= 0) {
        clearSalesSummary();
        return;
    }

    int transactions = 0;
    int itemsSold = 0;
    double totalSales = 0.0;

    String sql =
            "SELECT quantity, status, total_amount "
            + "FROM tbl_stocks_out "
            + "WHERE users_id = ? AND status <> 'Archived'";

    try (Connection con = DBConnection.connect()) {
        if (con == null) return;

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    transactions++;
                    String st = rs.getString("status");
                    if ("Completed".equalsIgnoreCase(st)) {
                        itemsSold += rs.getInt("quantity");
                        totalSales += rs.getDouble("total_amount");
                    }
                }
            }
        }

        double average = transactions > 0 ? totalSales / transactions : 0.0;

        jLabel8.setText("Total Sales : "
                + String.format(java.util.Locale.US, "₱%,.2f", totalSales));
        jLabel21.setText("Total Transactions : " + transactions);
        jLabel22.setText("Items Sold : " + itemsSold);
        jLabel23.setText("Average Sale : "
                + String.format(java.util.Locale.US, "₱%,.2f", average));

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Sales summary error: " + e.getMessage());
    }
}
    
  private void generateInventoryReport() {
    String category = String.valueOf(cmbCategory.getSelectedItem());
    String fromDate = String.valueOf(jComboBox1.getSelectedItem());
    String toDate = String.valueOf(jComboBox2.getSelectedItem());
    String reportType = String.valueOf(jComboBox3.getSelectedItem());

    if ("Select Report".equals(reportType)) {
        JOptionPane.showMessageDialog(this, "Please select a Report Type.");
        return;
    }

    boolean hasFrom = fromDate != null && !"All".equals(fromDate);
    boolean hasTo = toDate != null && !"All".equals(toDate);

    StringBuilder sql = new StringBuilder(
            "SELECT id, product_name, category, price, stock, supplier, date_added, status "
            + "FROM tbl_products WHERE users_id = ?"
    );

    if (!"All Categories".equals(category) && !"All".equals(category)) {
        sql.append(" AND category = ?");
    }

    if ("Available Stock".equals(reportType)) {
        sql.append(" AND stock > 10");
    } else if ("Low Stock".equals(reportType)) {
        sql.append(" AND stock > 0 AND stock <= 10");
    } else if ("Out of Stock".equals(reportType)) {
        sql.append(" AND stock = 0");
    }

    if (hasFrom && hasTo) {
        sql.append(" AND DATE(date_added) BETWEEN ? AND ?");
    } else if (hasFrom) {
        sql.append(" AND DATE(date_added) >= ?");
    } else if (hasTo) {
        sql.append(" AND DATE(date_added) <= ?");
    }

    sql.append(" ORDER BY date_added DESC, id DESC");

    DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Product Name", "Category", "Price", "Stock", "Date", "Status"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    int total = 0;

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
            int p = 1;
            pst.setInt(p++, UserSession.getUserId());

            if (!"All Categories".equals(category) && !"All".equals(category)) {
                pst.setString(p++, category);
            }

            if (hasFrom && hasTo) {
                pst.setDate(p++, java.sql.Date.valueOf(fromDate));
                pst.setDate(p++, java.sql.Date.valueOf(toDate));
            } else if (hasFrom) {
                pst.setDate(p++, java.sql.Date.valueOf(fromDate));
            } else if (hasTo) {
                pst.setDate(p++, java.sql.Date.valueOf(toDate));
            }

            try (ResultSet rs = pst.executeQuery()) {
                int rowNum = 1;
                while (rs.next()) {
                    int stock = rs.getInt("stock");
                    String status;

                    if (stock == 0) {
                        status = "Empty";
                    } else if (stock <= 10) {
                        status = "Low";
                    } else {
                        status = "Available";
                    }

                    total++;

                    model.addRow(new Object[]{
                        rowNum++,
                        rs.getString("product_name"),
                        rs.getString("category"),
                        String.format(java.util.Locale.US, "₱%.2f", rs.getDouble("price")),
                        stock,
                        rs.getDate("date_added"),
                        status
                    });
                }
            }
        }

        showReportDialog(
                "Inventory Report — " + reportType + " (" + total + ")",
                model,
                "Inventory_Report",
                summaryOf(jLabel1, jLabel9, jLabel7, jLabel5)
        );

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Inventory report failed: " + e.getMessage());
    }
}
    
   private void generateSalesReport() {
    String reportType = String.valueOf(jComboBox4.getSelectedItem());
    String category = String.valueOf(jComboBox5.getSelectedItem());
    String fromDate = String.valueOf(jComboBox6.getSelectedItem());
    String toDate = String.valueOf(jComboBox7.getSelectedItem());

    if ("Select Report".equals(reportType)) {
        JOptionPane.showMessageDialog(this, "Please select a Report Type.");
        return;
    }

    boolean hasFrom = fromDate != null && !"All".equals(fromDate);
    boolean hasTo = toDate != null && !"All".equals(toDate);

    StringBuilder sql = new StringBuilder(
            "SELECT s.id, s.product_name, s.quantity, s.date_out, "
            + "s.costumer, s.status, s.total_amount, p.category "
            + "FROM tbl_stocks_out s "
            + "JOIN tbl_products p ON s.product_id = p.id "
            + "WHERE s.users_id = ? "
            + "AND s.status <> 'Archived' "
    );

    if ("Completed Sales".equals(reportType)) {
        sql.append(" AND s.status = 'Completed' ");
    } else if ("Cancelled Sales".equals(reportType)) {
        sql.append(" AND s.status = 'Cancelled' ");
    }

    if (hasFrom && hasTo) {
        sql.append(" AND s.date_out BETWEEN ? AND ? ");
    } else if (hasFrom) {
        sql.append(" AND s.date_out >= ? ");
    } else if (hasTo) {
        sql.append(" AND s.date_out <= ? ");
    }

    if (!"All Categories".equals(category) && !"All".equals(category)) {
        sql.append(" AND p.category = ? ");
    }

    sql.append(" ORDER BY s.date_out DESC, s.id DESC");

    DefaultTableModel model = new DefaultTableModel(
            new Object[]{"ID", "Product", "Quantity", "Price", "Date", "Recipient", "Status"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    int transactions = 0;

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
            int p = 1;
            pst.setInt(p++, UserSession.getUserId());

            if (hasFrom && hasTo) {
                pst.setDate(p++, java.sql.Date.valueOf(fromDate));
                pst.setDate(p++, java.sql.Date.valueOf(toDate));
            } else if (hasFrom) {
                pst.setDate(p++, java.sql.Date.valueOf(fromDate));
            } else if (hasTo) {
                pst.setDate(p++, java.sql.Date.valueOf(toDate));
            }

            if (!"All Categories".equals(category) && !"All".equals(category)) {
                pst.setString(p++, category);
            }

            try (ResultSet rs = pst.executeQuery()) {
                int rowNum = 1;
                while (rs.next()) {
                    String st = rs.getString("status");
                    int qty = rs.getInt("quantity");
                    double amount = rs.getDouble("total_amount");

                    model.addRow(new Object[]{
                        rowNum++,
                        rs.getString("product_name"),
                        "Completed".equalsIgnoreCase(st) ? "-" + qty : qty,
                        String.format(java.util.Locale.US, "₱%.2f", amount),
                        rs.getDate("date_out"),
                        rs.getString("costumer"),
                        st
                    });

                    transactions++;
                }
            }
        }

        showReportDialog(
                "Sales Report — " + reportType + " (" + transactions + ")",
                model,
                "Sales_Report",
                summaryOf(jLabel8, jLabel21, jLabel22, jLabel23)
        );

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Sales report failed: " + e.getMessage());
    }
}
    
       // ================= STOCK IN REPORT =================

    private boolean isStockInMode() {
        return "STOCK IN REPORT".equals(String.valueOf(jComboBox8.getSelectedItem()));
    }

    
    private void applyReportMode() {
        boolean stockIn = isStockInMode();

        String[] types = stockIn
                ? new String[]{"Select Report", "All Stock In", "Received Stock In",
                               "Pending Stock In", "Cancelled Stock In"}
                : new String[]{"Select Report", "All Sales", "Completed Sales", "Cancelled Sales"};

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(types));
        jComboBox4.setSelectedItem("Select Report");

     

        if (stockIn) {
            clearStockInSummary();
            loadStockInSummaryOverall();
        } else {
            clearSalesSummary();
            loadSalesSummaryOverall();
        }
    }

       private void clearStockInSummary() {
        jLabel8.setText("Total Sell Price : ₱0.00");
        jLabel21.setText("Total Arrivals : 0");
        jLabel22.setText("Items Received : 0");
        jLabel23.setText("Pending / Cancelled / Received : 0 / 0 / 0");
    }

       private void loadStockInSummaryOverall() {
        int userId = UserSession.getUserId();
        if (userId <= 0) {
            clearStockInSummary();
            return;
        }

        int arrivals = 0;
        int itemsReceived = 0;
        int pending = 0;
        int cancelled = 0;
        int received = 0;
        double totalSellPrice = 0.0;

        String sql =
                "SELECT s.quantity, s.status, p.price "
                + "FROM tbl_stocks_in s "
                + "JOIN tbl_products p ON s.product_id = p.id "
                + "WHERE s.users_id = ? AND s.status <> 'Archived'";

        try (Connection con = DBConnection.connect()) {
            if (con == null) return;

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setInt(1, userId);
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        arrivals++;
                        String st = rs.getString("status");
                        int qty = rs.getInt("quantity");
                        double price = rs.getDouble("price");

                        if ("Received".equalsIgnoreCase(st)) {
                            received++;
                            itemsReceived += qty;
                            totalSellPrice += price * qty;   // only Received counts
                        } else if ("Pending".equalsIgnoreCase(st)) {
                            pending++;
                        } else if ("Cancelled".equalsIgnoreCase(st)) {
                            cancelled++;
                        }
                    }
                }
            }

            jLabel8.setText("Total Sell Price : "
                    + String.format(java.util.Locale.US, "₱%,.2f", totalSellPrice));
            jLabel21.setText("Total Arrivals : " + arrivals);
            jLabel22.setText("Items Received : " + itemsReceived);
            jLabel23.setText("Pending / Cancelled / Received : "
                    + pending + " / " + cancelled + " / " + received);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Stock In summary error: " + e.getMessage());
        }
    }

    private void generateStockInReport() {
        String reportType = String.valueOf(jComboBox4.getSelectedItem());
        String category = String.valueOf(jComboBox5.getSelectedItem());
        String fromDate = String.valueOf(jComboBox6.getSelectedItem());
        String toDate = String.valueOf(jComboBox7.getSelectedItem());

        if ("Select Report".equals(reportType)) {
            JOptionPane.showMessageDialog(this, "Please select a Report Type.");
            return;
        }

        boolean hasFrom = fromDate != null && !"All".equals(fromDate);
        boolean hasTo = toDate != null && !"All".equals(toDate);

        StringBuilder sql = new StringBuilder(
                "SELECT s.id, s.product_name, s.quantity, s.date_in, "
                + "s.status, p.price "
                + "FROM tbl_stocks_in s "
                + "JOIN tbl_products p ON s.product_id = p.id "
                + "WHERE s.users_id = ? "
                + "AND s.status <> 'Archived' "
        );

        if ("Received Stock In".equals(reportType)) {
            sql.append(" AND s.status = 'Received' ");
        } else if ("Pending Stock In".equals(reportType)) {
            sql.append(" AND s.status = 'Pending' ");
        } else if ("Cancelled Stock In".equals(reportType)) {
            sql.append(" AND s.status = 'Cancelled' ");
        }

        if (hasFrom && hasTo) {
            sql.append(" AND s.date_in BETWEEN ? AND ? ");
        } else if (hasFrom) {
            sql.append(" AND s.date_in >= ? ");
        } else if (hasTo) {
            sql.append(" AND s.date_in <= ? ");
        }

        if (!"All Categories".equals(category) && !"All".equals(category)) {
            sql.append(" AND p.category = ? ");
        }

        sql.append(" ORDER BY s.date_in DESC, s.id DESC");

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"ID", "Product", "Quantity", "Sell Price", "Date", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        int arrivals = 0;

        try (Connection con = DBConnection.connect()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Cannot connect to database.");
                return;
            }

            try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
                int p = 1;
                pst.setInt(p++, UserSession.getUserId());

                if (hasFrom && hasTo) {
                    pst.setDate(p++, java.sql.Date.valueOf(fromDate));
                    pst.setDate(p++, java.sql.Date.valueOf(toDate));
                } else if (hasFrom) {
                    pst.setDate(p++, java.sql.Date.valueOf(fromDate));
                } else if (hasTo) {
                    pst.setDate(p++, java.sql.Date.valueOf(toDate));
                }

                if (!"All Categories".equals(category) && !"All".equals(category)) {
                    pst.setString(p++, category);
                }

                try (ResultSet rs = pst.executeQuery()) {
                    int rowNum = 1;
                    while (rs.next()) {
                        model.addRow(new Object[]{
                            rowNum++,
                            rs.getString("product_name"),
                            rs.getInt("quantity"),
                            String.format(java.util.Locale.US, "₱%.2f", rs.getDouble("price")),
                            rs.getDate("date_in"),
                            rs.getString("status")
                        });
                        arrivals++;
                    }
                }
            }

            showReportDialog(
                    "Stock In Report — " + reportType + " (" + arrivals + ")",
                    model,
                    "Stock_In_Report",
                    summaryOf(jLabel8, jLabel21, jLabel22, jLabel23)
            );

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Stock In report failed: " + e.getMessage());
        }
    }
   
        private void showReportDialog(String title, DefaultTableModel model, String exportFileName, String[][] summary) {

    javax.swing.JTable table = new javax.swing.JTable(model);
    table.setRowHeight(28);
    table.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
    table.setBackground(java.awt.Color.WHITE);
    table.setGridColor(new java.awt.Color(230, 230, 230));
    table.setSelectionBackground(new java.awt.Color(255, 220, 150));
    table.setShowHorizontalLines(true);
    table.setShowVerticalLines(false);
    table.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    table.getTableHeader().setBackground(new java.awt.Color(9, 9, 89));
    table.getTableHeader().setForeground(java.awt.Color.WHITE);
    table.getTableHeader().setReorderingAllowed(false);
    table.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 32));
    table.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);

    javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(table);
    scroll.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(9, 9, 89), 1));
    scroll.getViewport().setBackground(java.awt.Color.WHITE);

    javax.swing.JPanel topBar = new javax.swing.JPanel(new java.awt.BorderLayout());
    topBar.setBackground(new java.awt.Color(9, 9, 89));
    topBar.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 15, 12, 15));
    topBar.setPreferredSize(new java.awt.Dimension(0, 52));

    javax.swing.JLabel titleLabel = new javax.swing.JLabel(title);
    titleLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18));
    titleLabel.setForeground(new java.awt.Color(255, 153, 0));
    topBar.add(titleLabel, java.awt.BorderLayout.WEST);

    javax.swing.JPanel center = new javax.swing.JPanel(new java.awt.BorderLayout());
    center.setBackground(new java.awt.Color(255, 179, 0));
    center.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
    center.add(scroll, java.awt.BorderLayout.CENTER);

    // Buttons
    javax.swing.JButton exportBtn = new javax.swing.JButton("Export CSV");
    exportBtn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    exportBtn.setBackground(new java.awt.Color(20, 125, 65));
    exportBtn.setForeground(java.awt.Color.WHITE);
    exportBtn.setFocusPainted(false);
    exportBtn.setPreferredSize(new java.awt.Dimension(120, 34));

    javax.swing.JButton closeBtn = new javax.swing.JButton("Close");
    closeBtn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    closeBtn.setBackground(new java.awt.Color(9, 9, 89));
    closeBtn.setForeground(java.awt.Color.WHITE);
    closeBtn.setFocusPainted(false);
    closeBtn.setPreferredSize(new java.awt.Dimension(100, 34));

    javax.swing.JPanel bottom = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
    bottom.setBackground(new java.awt.Color(255, 179, 0));
    bottom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 10, 10));
    bottom.add(exportBtn);
    bottom.add(closeBtn);

    javax.swing.JPanel main = new javax.swing.JPanel(new java.awt.BorderLayout());
    main.setBackground(new java.awt.Color(255, 179, 0));
    main.add(topBar, java.awt.BorderLayout.NORTH);
    main.add(center, java.awt.BorderLayout.CENTER);
    main.add(bottom, java.awt.BorderLayout.SOUTH);

    javax.swing.JDialog dialog = new javax.swing.JDialog(this, title, true);
    dialog.setDefaultCloseOperation(javax.swing.JDialog.DISPOSE_ON_CLOSE);
    dialog.setContentPane(main);
    dialog.setSize(860, 480);
    dialog.setLocationRelativeTo(this);
    dialog.setResizable(true);

    exportBtn.addActionListener(e -> {
        javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
        chooser.setDialogTitle("Export Report");
        chooser.setSelectedFile(new java.io.File(exportFileName + ".csv"));

        if (chooser.showSaveDialog(dialog) != javax.swing.JFileChooser.APPROVE_OPTION) {
            return;
        }

        java.io.File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new java.io.File(file.getAbsolutePath() + ".csv");
        }

        try (java.io.PrintWriter writer = new java.io.PrintWriter(file, "UTF-8")) {
            writer.print('\uFEFF'); // BOM so Excel reads UTF-8 correctly

            // Header
            for (int c = 0; c < model.getColumnCount(); c++) {
                if (c > 0) writer.print(",");
                writer.print("\"" + model.getColumnName(c) + "\"");
            }
            writer.println();

            // Rows
            for (int r = 0; r < model.getRowCount(); r++) {
                for (int c = 0; c < model.getColumnCount(); c++) {
                    if (c > 0) writer.print(",");
                    Object val = model.getValueAt(r, c);
                    String text = val == null ? "" : val.toString();

                    if (text.startsWith("₱")) {
                        text = text.substring(1).replace(",", "");
                    }

                    if (text.matches("-?\\d+(\\.\\d+)?")) {
                        writer.print(text);
                    } else {
                        writer.print("\"" + text.replace("\"", "\"\"") + "\"");
                    }
                }
                writer.println();
            }

            // Summary block (only in the exported file, not in the dialog)
            if (summary != null && summary.length > 0) {
                writer.println();
                writer.println("\"SUMMARY\"");

                for (String[] row : summary) {
                    String label = row[0].replace("\"", "\"\"");
                    String value = row[1];

                    if (value.startsWith("₱")) {
                        value = value.substring(1).replace(",", "");
                    }

                    writer.print("\"" + label + "\",");

                    if (value.matches("-?\\d+(\\.\\d+)?")) {
                        writer.print(value);
                    } else {
                        writer.print("\"" + value.replace("\"", "\"\"") + "\"");
                    }
                    writer.println();
                }
            }

            JOptionPane.showMessageDialog(dialog,
                    "Report exported successfully:\n" + file.getAbsolutePath());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog,
                    "Export failed: " + ex.getMessage());
        }
    });

    closeBtn.addActionListener(e -> dialog.dispose());
    dialog.setVisible(true);
}


    
    private static final int DESIGN_WIDTH = 1100;
    private static final int DESIGN_HEIGHT = 652;
    
    private ResponsiveScaler responsiveScaler;
    
    private void setupResponsiveLayout() {
        setMinimumSize(new Dimension(DESIGN_WIDTH, DESIGN_HEIGHT));

       
        layoutAll(masterPanel);

       
        Container content = getContentPane();
        content.removeAll();
        content.setLayout(new java.awt.BorderLayout());
        content.add(masterPanel, java.awt.BorderLayout.CENTER);

       
        responsiveScaler = new ResponsiveScaler(
                masterPanel, DESIGN_WIDTH, DESIGN_HEIGHT);

        content.revalidate();
        content.repaint();
    }
     
     private static void layoutAll(Container container) {
        container.doLayout();

        for (Component component : container.getComponents()) {
            if (component instanceof Container) {
                layoutAll((Container) component);
            }
        }
    }
     
      private static final class ResponsiveScaler {

        private final JPanel root;
        private final int designWidth;
        private final int designHeight;

        private final Map<Component, java.awt.Rectangle> originalBounds =
                new IdentityHashMap<>();
        private final Map<JComponent, Font> originalFonts =
                new IdentityHashMap<>();
        private final Map<JComponent, Icon> originalIcons =
                new IdentityHashMap<>();

        ResponsiveScaler(JPanel root, int designWidth, int designHeight) {
            this.root = root;
            this.designWidth = designWidth;
            this.designHeight = designHeight;

            capture(root);
            update();
        }
        
         private void capture(Container parent) {
            for (Component component : parent.getComponents()) {
                originalBounds.put(
                        component,
                        new java.awt.Rectangle(component.getBounds()));

                if (component instanceof JComponent) {
                    JComponent jc = (JComponent) component;

                    if (jc.getFont() != null) {
                        originalFonts.put(jc, jc.getFont());
                    }

                    Icon icon = null;

                    if (jc instanceof javax.swing.JLabel) {
                        icon = ((javax.swing.JLabel) jc).getIcon();
                    } else if (jc instanceof AbstractButton) {
                        icon = ((AbstractButton) jc).getIcon();
                    }

                    if (icon != null) {
                        originalIcons.put(jc, icon);
                    }
                }
                
                if (component instanceof Container) {
                    Container child = (Container) component;
                    capture(child);
                    child.setLayout(null);
                }
            }
        }
         
         void update() {
            if (root.getWidth() <= 0 || root.getHeight() <= 0) {
                return;
            }

            double scaleX = root.getWidth() / (double) designWidth;
            double scaleY = root.getHeight() / (double) designHeight;

            double uniformScale = Math.min(scaleX, scaleY);

            for (Map.Entry<Component, java.awt.Rectangle> entry
                    : originalBounds.entrySet()) {

                Component component = entry.getKey();
                java.awt.Rectangle original = entry.getValue();

                int x = (int) Math.round(original.x * scaleX);
                int y = (int) Math.round(original.y * scaleY);
                int width = Math.max(
                        1, (int) Math.round(original.width * scaleX));
                int height = Math.max(
                        1, (int) Math.round(original.height * scaleY));

                component.setBounds(x, y, width, height);
            }

            for (Map.Entry<JComponent, Font> entry
                    : originalFonts.entrySet()) {

                JComponent component = entry.getKey();
                Font original = entry.getValue();

                int size = Math.max(
                        8,
                        (int) Math.round(original.getSize2D() * uniformScale));

                component.setFont(original.deriveFont(
                        original.getStyle(), (float) size));
            }

            for (Map.Entry<JComponent, Icon> entry
                    : originalIcons.entrySet()) {

                JComponent component = entry.getKey();
                Icon originalIcon = entry.getValue();

                if (!(originalIcon instanceof ImageIcon)) {
                    continue;
                }

                ImageIcon imageIcon = (ImageIcon) originalIcon;
                Image image = imageIcon.getImage();

                int width = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconWidth() * scaleX));
                int height = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconHeight() * scaleY));

                Image scaledImage = image.getScaledInstance(
                        width, height, Image.SCALE_SMOOTH);

                ImageIcon scaledIcon = new ImageIcon(scaledImage);

                if (component instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) component).setIcon(scaledIcon);
                } else if (component instanceof AbstractButton) {
                    ((AbstractButton) component).setIcon(scaledIcon);
                }
            }

            root.revalidate();
            root.repaint();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        masterPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel8 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jPanel9 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton7 = new javax.swing.JButton();
        jPanel26 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jPanel23 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jPanel24 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();
        jPanel25 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jComboBox8 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        masterPanel.setBackground(new java.awt.Color(0, 0, 51));
        masterPanel.setPreferredSize(new java.awt.Dimension(0, 0));
        masterPanel.addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsListener() {
            public void ancestorMoved(java.awt.event.HierarchyEvent evt) {
            }
            public void ancestorResized(java.awt.event.HierarchyEvent evt) {
                masterPanelAncestorResized(evt);
            }
        });
        masterPanel.setLayout(null);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        masterPanel.add(jLabel2);
        jLabel2.setBounds(0, 0, 380, 110);

        jPanel2.setBackground(new java.awt.Color(226, 136, 1));

        jButton1.setBackground(new java.awt.Color(255, 255, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 204));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        jButton1.setText("Dashboard");
        jButton1.setFocusPainted(false);
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(255, 255, 51));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 0, 204));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        jButton2.setText("Manage Inventory  ");
        jButton2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(255, 255, 51));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 204));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        jButton3.setText("Stock In/Arrivals");
        jButton3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setBackground(new java.awt.Color(255, 255, 51));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 204));
        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        jButton4.setText("Stock Out/Sales");
        jButton4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setBackground(new java.awt.Color(255, 204, 51));
        jButton5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 0, 204));
        jButton5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        jButton5.setText(" SmartStock Report");
        jButton5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jButton6.setBackground(new java.awt.Color(255, 255, 51));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 0, 204));
        jButton6.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (4).png")); // NOI18N
        jButton6.setText("Log Out");
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jLabel4.setBackground(new java.awt.Color(255, 153, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Main Menu");

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 268, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jLabel4)))
                .addGap(0, 63, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(16, 16, 16)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addGap(39, 39, 39)
                .addComponent(jButton6)
                .addContainerGap(80, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel2);
        jPanel2.setBounds(0, 110, 380, 540);

        jPanel3.setBackground(new java.awt.Color(9, 9, 89));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        jLabel3.setText(" SmartStock Reports ");

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 374, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel3);
        jPanel3.setBounds(376, 0, 730, 110);

        jPanel21.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel21);
        jPanel21.setBounds(1090, 0, 10, 650);

        jPanel22.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel22);
        jPanel22.setBounds(380, 0, 10, 650);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        jLabel10.setBackground(new java.awt.Color(102, 102, 102));
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Category :");
        jLabel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel10.setOpaque(true);

        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Categories", "Supplies", "Office", "Electronics", "Consumables", "Others" }));
        cmbCategory.addActionListener(this::cmbCategoryActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cmbCategory, 0, 131, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmbCategory, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));

        jLabel11.setBackground(new java.awt.Color(102, 102, 102));
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("From Date :");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel11.setOpaque(true);

        jComboBox1.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));

        jLabel13.setBackground(new java.awt.Color(102, 102, 102));
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Report Type :");
        jLabel13.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel13.setOpaque(true);

        jComboBox3.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Report", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));

        jLabel12.setBackground(new java.awt.Color(102, 102, 102));
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("To Date :");
        jLabel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel12.setOpaque(true);

        jComboBox2.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(this::jComboBox2ActionPerformed);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jButton7.setBackground(new java.awt.Color(0, 0, 102));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("GENERATE REPORT");
        jButton7.addActionListener(this::jButton7ActionPerformed);

        jPanel26.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel27.setBackground(new java.awt.Color(255, 255, 102));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Total Product :");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(jLabel1))
        );

        jPanel28.setBackground(new java.awt.Color(255, 255, 102));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("Total Stock Units :");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel9))
        );

        jPanel29.setBackground(new java.awt.Color(255, 255, 102));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("Low Stock :");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel7))
        );

        jPanel30.setBackground(new java.awt.Color(255, 255, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Out of Stock :");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel5))
        );

        jButton10.setBackground(new java.awt.Color(0, 0, 102));
        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("RESET FILTERS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(185, 185, 185))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel30, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel29, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel27, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addContainerGap())
        );

        masterPanel.add(jPanel1);
        jPanel1.setBounds(430, 200, 270, 350);

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("INVENTORY REPORTS");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel17)
                .addContainerGap(88, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel17)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel5);
        jPanel5.setBounds(430, 150, 270, 50);

        jPanel11.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel11);
        jPanel11.setBounds(390, 110, 280, 20);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel13);
        jPanel13.setBounds(380, 570, 340, 20);

        jPanel14.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel14);
        jPanel14.setBounds(380, 610, 610, 20);

        jPanel15.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 430, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel15);
        jPanel15.setBounds(670, 110, 430, 20);

        jPanel16.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel16);
        jPanel16.setBounds(730, 570, 370, 20);

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel17);
        jPanel17.setBounds(1000, 610, 100, 20);

        jPanel12.setBackground(new java.awt.Color(102, 102, 102));
        jPanel12.setForeground(new java.awt.Color(153, 153, 153));

        jPanel20.setBackground(new java.awt.Color(51, 51, 51));

        jLabel14.setBackground(new java.awt.Color(102, 102, 102));
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Report Type :");
        jLabel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel14.setOpaque(true);

        jComboBox4.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Report", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox4, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel23.setBackground(new java.awt.Color(51, 51, 51));

        jLabel16.setBackground(new java.awt.Color(102, 102, 102));
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Category :");
        jLabel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel16.setOpaque(true);

        jComboBox5.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Categories", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox5, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel24.setBackground(new java.awt.Color(51, 51, 51));

        jLabel19.setBackground(new java.awt.Color(102, 102, 102));
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("From Date :");
        jLabel19.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel19.setOpaque(true);

        jComboBox6.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel25.setBackground(new java.awt.Color(51, 51, 51));

        jLabel20.setBackground(new java.awt.Color(102, 102, 102));
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("To Date :");
        jLabel20.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel20.setOpaque(true);

        jComboBox7.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jButton8.setBackground(new java.awt.Color(0, 0, 102));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("GENERATE REPORT");
        jButton8.addActionListener(this::jButton8ActionPerformed);

        jButton9.setBackground(new java.awt.Color(0, 0, 102));
        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("RESET FILTERS");
        jButton9.addActionListener(this::jButton9ActionPerformed);

        jPanel18.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        jPanel31.setBackground(new java.awt.Color(255, 255, 102));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Total Sales :");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel8))
        );

        jPanel32.setBackground(new java.awt.Color(255, 255, 102));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(51, 51, 51));
        jLabel21.setText("Total Transactions :");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel21))
        );

        jPanel33.setBackground(new java.awt.Color(255, 255, 102));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(51, 51, 51));
        jLabel23.setText("Average Sale :");

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel33Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel23))
        );

        jPanel34.setBackground(new java.awt.Color(255, 255, 102));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 51, 51));
        jLabel22.setText("Items Sold :");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addComponent(jLabel22))
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addComponent(jButton8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addComponent(jButton9)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(185, 185, 185))
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel32, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel33, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel34, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jButton9))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton8)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15)
                .addContainerGap())
        );

        masterPanel.add(jPanel12);
        jPanel12.setBounds(760, 200, 280, 350);

        jPanel37.setBackground(new java.awt.Color(51, 51, 51));

        jComboBox8.setBackground(new java.awt.Color(51, 51, 51));
        jComboBox8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox8.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SALES REPORT", "STOCK IN REPORT" }));
        jComboBox8.setOpaque(true);

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(73, Short.MAX_VALUE))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel37);
        jPanel37.setBounds(760, 150, 280, 50);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void openPage(JFrame nextPage) {

    java.awt.Rectangle currentBounds = this.getBounds();

    boolean maximized =
            (this.getExtendedState() & JFrame.MAXIMIZED_BOTH)
            == JFrame.MAXIMIZED_BOTH;

    nextPage.setVisible(true);

    if (maximized) {
        nextPage.setExtendedState(JFrame.MAXIMIZED_BOTH);
    } else {
        nextPage.setBounds(currentBounds);
    }

    this.dispose();
}
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       HomePage home = new HomePage();
       openPage(home);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Log Out", javax.swing.JOptionPane.YES_NO_OPTION);
     
        if (choice == javax.swing.JOptionPane.YES_OPTION) {
              LoginPage loginForm = new LoginPage();
              loginForm.setVisible(true);
              this.dispose();
        } else {}
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       StockoutPage stockout = new StockoutPage();
       openPage(stockout);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       StockinPage stockin = new StockinPage();
       openPage(stockin);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       ManagePage manage = new ManagePage();
       openPage(manage);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
       if (responsiveScaler != null) {
            responsiveScaler.update();
       }
    }//GEN-LAST:event_formComponentResized

    private void masterPanelAncestorResized(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_masterPanelAncestorResized
       if (responsiveScaler != null) {
            responsiveScaler.update();
       }
    }//GEN-LAST:event_masterPanelAncestorResized

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
       
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        generateInventoryReport();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        if (isStockInMode()) {
            generateStockInReport();
        } else {
            generateSalesReport();
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    jComboBox4.setSelectedItem("Select Report");
    jComboBox5.setSelectedItem("All Categories");
    jComboBox6.setSelectedItem("All");
    jComboBox7.setSelectedItem("All");

    if (isStockInMode()) {
        clearStockInSummary();
        loadStockInSummaryOverall();
    } else {
        clearSalesSummary();
        loadSalesSummaryOverall();
    }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ViewReportPage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel masterPanel;
    // End of variables declaration//GEN-END:variables
}
