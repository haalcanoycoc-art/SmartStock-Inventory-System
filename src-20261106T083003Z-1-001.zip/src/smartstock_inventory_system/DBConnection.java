
package smartstock_inventory_system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


class DBConnection {
    
    
    public static Connection connect() { 
        try {
            String url = "jdbc:mysql://localhost:3306/SmartStock_Inventory_System";
            String user = "root";
            String pass = "";
            Connection conn = DriverManager.getConnection(url, user, pass);
            return conn;
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
            return null;
        }
    }
}
