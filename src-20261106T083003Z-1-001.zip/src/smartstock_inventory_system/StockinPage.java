/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.util.IdentityHashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class StockinPage extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(StockinPage.class.getName());

    private boolean loadingDateOptions = false;

    public StockinPage() {
        initComponents();
        setupResponsiveLayout();

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{
                    "ID",
                    "Product Name",
                    "Quantity",
                    "Sell Price",
                    "Date",
                    "Status",
                    "DB_ID",
                    "PRODUCT_ID"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
        "All", "Received", "Pending", "Cancelled"
        }));
        jComboBox1.setSelectedItem("All");
        jComboBox1.addActionListener(e -> {
        if (!loadingDateOptions) {
        loadStockInRecords();
        }
        });

        jTable1.setModel(model);

        jTable1.setDefaultEditor(Object.class, null);
        jTable1.setDefaultEditor(String.class, null);
        jTable1.setDefaultEditor(Integer.class, null);
        jTable1.setDefaultEditor(java.sql.Date.class, null);

        jTable1.getTableHeader().setReorderingAllowed(false);

        jTable1.removeColumn(jTable1.getColumnModel().getColumn(6));
        jTable1.removeColumn(jTable1.getColumnModel().getColumn(6));

        setupStatusColors();

        cmbCategory.setSelectedItem("All");

        updateSummary();
        setupSearch();
        setupDateSorting();
        loadStockInRecords();

    }

    private void setupStatusColors() {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                Component component
                        = super.getTableCellRendererComponent(
                                table, value, isSelected, hasFocus, row, column);

                String status = value == null
                        ? ""
                        : value.toString();

                if (isSelected) {
                    return component;
                }

                switch (status) {
                    case "Received":
                        component.setForeground(new Color(20, 125, 65));
                        component.setBackground(new Color(215, 245, 225));
                        break;

                    case "Pending":
                        component.setForeground(new Color(170, 100, 0));
                        component.setBackground(new Color(255, 240, 200));
                        break;

                    case "Cancelled":
                        component.setForeground(new Color(190, 35, 35));
                        component.setBackground(new Color(255, 225, 225));
                        break;

                    default:
                        component.setForeground(table.getForeground());
                        component.setBackground(table.getBackground());
                        break;
                }

                component.setFont(
                        component.getFont().deriveFont(java.awt.Font.BOLD));

                return component;
            }
        };

        jTable1.getColumnModel()
                .getColumn(5)
                .setCellRenderer(renderer);
    }

    private static class ProductOption {

        int id;
        String name;
        int stock;

        ProductOption(int id, String name, int stock) {
            this.id = id;
            this.name = name;
            this.stock = stock;
        }

        @Override
        public String toString() {
            return name + " (Stock: " + stock + ")";
        }
    }

        private void loadStockInRecords() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    int rowNumber = 1;
    String dateOrder = "DESC";

    if ("Oldest First".equals(cmbDateSort.getSelectedItem())) {
        dateOrder = "ASC";
    }

    String selectedCategory = String.valueOf(cmbCategory.getSelectedItem());
    String selectedStatus = String.valueOf(jComboBox1.getSelectedItem());

    String sql
            = "SELECT s.id, s.product_id, s.product_name, s.quantity, s.date_in, "
            + "s.status, p.price "
            + "FROM tbl_stocks_in s "
            + "JOIN tbl_products p ON s.product_id = p.id "
            + "WHERE s.users_id = ? "
            + "AND s.status <> 'Archived' "
            + ("All".equals(selectedCategory) ? "" : "AND p.category = ? ")
            + ("All".equals(selectedStatus) ? "" : "AND s.status = ? ")
            + "ORDER BY s.date_in " + dateOrder
            + ", s.id " + dateOrder;

    try (Connection con = DBConnection.connect()) {

        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            int param = 1;
            pst.setInt(param++, UserSession.getUserId());

            if (!"All".equals(selectedCategory)) {
                pst.setString(param++, selectedCategory);
            }

            if (!"All".equals(selectedStatus)) {
                pst.setString(param++, selectedStatus);
            }

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    int quantity = rs.getInt("quantity");
                    double sellPrice = rs.getDouble("price");
                    String status = rs.getString("status");

                    model.addRow(new Object[]{
                        rowNumber++,
                        rs.getString("product_name"),
                        "+" + quantity,
                        String.format(java.util.Locale.US, "₱%.2f", sellPrice),
                        rs.getDate("date_in"),
                        status,
                        rs.getInt("id"),
                        rs.getInt("product_id")
                    });
                }
            }
        }

        updateSummary();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Failed to load Stock In records: " + e.getMessage()
        );
    }
}

    
private void recordArrival() {
    int userId = UserSession.getUserId();
 
    if (userId <= 0) {
        JOptionPane.showMessageDialog(this, "Please log in first.");
        return;
    }
 
    JComboBox<ProductOption> productBox = new JComboBox<>();
    JTextField quantityField = new JTextField();
    JTextField costPerPieceField = new JTextField("0.00");
    JTextField markupPercentField = new JTextField("20");
    JLabel sellPriceLabel = new JLabel("₱0.00 per quantity");
 
    Runnable recalculateSellPrice = () -> {
        try {
            double cost = Double.parseDouble(costPerPieceField.getText().trim());
            double markup = Double.parseDouble(markupPercentField.getText().trim());
 
            if (!Double.isFinite(cost) || !Double.isFinite(markup)
                    || cost < 0 || markup < 0) {
                sellPriceLabel.setText("Enter non-negative values");
                return;
            }
 
            double sellingPrice = Math.round(
                    (cost + cost * markup / 100.0) * 100.0
            ) / 100.0;
 
            sellPriceLabel.setText(String.format(
                    java.util.Locale.US, "₱%.2f per quantity", sellingPrice));
 
        } catch (NumberFormatException ex) {
            sellPriceLabel.setText("Enter valid numbers");
        }
    };
 
    DocumentListener priceCalculatorListener = new DocumentListener() {
        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            recalculateSellPrice.run();
        }
 
        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            recalculateSellPrice.run();
        }
 
        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            recalculateSellPrice.run();
        }
    };
 
    costPerPieceField.getDocument().addDocumentListener(priceCalculatorListener);
    markupPercentField.getDocument().addDocumentListener(priceCalculatorListener);
 
    String productSql =
            "SELECT id, product_name, stock FROM tbl_products "
            + "WHERE users_id = ? ORDER BY product_name";
 
    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }
 
        try (PreparedStatement pst = con.prepareStatement(productSql)) {
            pst.setInt(1, userId);
 
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    productBox.addItem(new ProductOption(
                            rs.getInt("id"),
                            rs.getString("product_name"),
                            rs.getInt("stock")
                    ));
                }
            }
        }
 
        if (productBox.getItemCount() == 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "No products found. Add a product in Manage Inventory first."
            );
            return;
        }
 
        Object[] fields = {
            "Product:", productBox,
            "Quantity to Transfer:", quantityField,
            "Cost per Piece (₱):", costPerPieceField,
            "Markup (%):", markupPercentField,
            "Selling Price per Piece:", sellPriceLabel
        };
 
        int choice = JOptionPane.showConfirmDialog(
                this,
                fields,
                "Record Stock Arrival",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );
 
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }
 
        ProductOption product = (ProductOption) productBox.getSelectedItem();
 
        if (product == null) {
            return;
        }
 
        int quantity;
        Date arrivalDate = Date.valueOf(LocalDate.now());
 
        try {
            quantity = Integer.parseInt(quantityField.getText().trim());
 
            if (quantity <= 0) {
                JOptionPane.showMessageDialog(
                        this, "Quantity must be greater than zero.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this, "Enter a valid positive quantity.");
            return;
        }
 
        double costPerPiece;
        double markupPercent;
        double sellingPricePerPiece;
 
        try {
            costPerPiece = Double.parseDouble(costPerPieceField.getText().trim());
            markupPercent = Double.parseDouble(markupPercentField.getText().trim());
 
            if (!Double.isFinite(costPerPiece) || !Double.isFinite(markupPercent)
                    || costPerPiece < 0 || markupPercent < 0) {
                throw new NumberFormatException();
            }
 
            sellingPricePerPiece = Math.round(
                    (costPerPiece + costPerPiece * markupPercent / 100.0) * 100.0
            ) / 100.0;
 
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enter valid non-negative numbers for cost and markup.");
            return;
        }
 
        con.setAutoCommit(false);
 
        try {
            int currentStock;
            String productName;
 
            String checkSql =
                    "SELECT product_name, stock FROM tbl_products "
                    + "WHERE id = ? AND users_id = ? FOR UPDATE";
 
            try (PreparedStatement pst = con.prepareStatement(checkSql)) {
                pst.setInt(1, product.id);
                pst.setInt(2, userId);
 
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Product was not found.");
                    }
 
                    productName = rs.getString("product_name");
                    currentStock = rs.getInt("stock");
                }
            }
 
            if (currentStock < quantity) {
                throw new SQLException(
                        "Insufficient inventory. Available: " + currentStock
                        + ", requested: " + quantity + ".");
            }
 
            String updateSql =
                    "UPDATE tbl_products SET "
                    + "price = ?, "
                    + "status = CASE "
                    + "WHEN stock - ? = 0 THEN 'Empty' "
                    + "WHEN stock - ? <= 10 THEN 'Low' "
                    + "ELSE 'Available' END, "
                    + "stock = stock - ? "
                    + "WHERE id = ? AND users_id = ? AND stock >= ?";
 
            try (PreparedStatement pst = con.prepareStatement(updateSql)) {
                pst.setDouble(1, sellingPricePerPiece);
                pst.setInt(2, quantity);
                pst.setInt(3, quantity);
                pst.setInt(4, quantity);
                pst.setInt(5, product.id);
                pst.setInt(6, userId);
                pst.setInt(7, quantity);
 
                if (pst.executeUpdate() != 1) {
                    throw new SQLException(
                            "Inventory could not be updated. Please try again.");
                }
            }
 
            
            String insertSql =
                    "INSERT INTO tbl_stocks_in "
                    + "(users_id, product_id, product_name, quantity, date_in, status) "
                    + "VALUES (?, ?, ?, ?, ?, 'Pending')";
 
            try (PreparedStatement pst = con.prepareStatement(insertSql)) {
                pst.setInt(1, userId);
                pst.setInt(2, product.id);
                pst.setString(3, productName);
                pst.setInt(4, quantity);
                pst.setDate(5, arrivalDate);
                pst.executeUpdate();
            }
 
            con.commit();
            ActivityLog.log("Stock In recorded: " + productName + " +" + quantity);
            loadStockInRecords();
 
            JOptionPane.showMessageDialog(this, "Stock In Successful!");
 
        } catch (Exception e) {
            con.rollback();
 
            JOptionPane.showMessageDialog(
                    this, "Unable to record arrival: " + e.getMessage());
 
        } finally {
            con.setAutoCommit(true);
        }
 
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Database error: " + e.getMessage());
    }
}


    private void setupDateSorting() {
        loadingDateOptions = true;

        cmbDateSort.setSelectedItem("Newest First");

        loadingDateOptions = false;

        cmbDateSort.addActionListener(e -> {
            if (!loadingDateOptions) {
                loadStockInRecords();
            }
        });
    }

    


private void updateSummary() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

    java.util.Set<Integer> uniqueProducts = new java.util.HashSet<>();
    int receivedRecords = 0;
    int pendingRecords = 0;
    int cancelledRecords = 0;
    int totalReceivedQuantity = 0;
    double totalSellPrice = 0.0;

    for (int i = 0; i < model.getRowCount(); i++) {

        // Count each product only once, no matter how many arrivals it has
        Object productId = model.getValueAt(i, 7);
        if (productId != null) {
            uniqueProducts.add(Integer.parseInt(productId.toString()));
        }

        String status = String.valueOf(model.getValueAt(i, 5)).trim();

        String qtyText = String.valueOf(model.getValueAt(i, 2))
                .replace("+", "")
                .replace(",", "")
                .trim();

        String priceText = String.valueOf(model.getValueAt(i, 3))
                .replace("₱", "")
                .replace(",", "")
                .trim();

        try {
            int quantity = Integer.parseInt(qtyText);
            double pricePerPiece = Double.parseDouble(priceText);

            if (status.equalsIgnoreCase("Received")) {
                receivedRecords++;
                totalReceivedQuantity += quantity;
                totalSellPrice += pricePerPiece * quantity;   // only Received
            } else if (status.equalsIgnoreCase("Pending")) {
                pendingRecords++;
            } else if (status.equalsIgnoreCase("Cancelled")) {
                cancelledRecords++;
            }

        } catch (NumberFormatException e) {
            System.err.println("Invalid quantity or sell price at row " + i);
        }
    }

    jLabel5.setText("Total Stock in : " + uniqueProducts.size());
    jLabel8.setText("Total Items Received : " + totalReceivedQuantity);
    jLabel12.setText("Received Records : " + receivedRecords);
    jLabel13.setText("Total Pending Stocks : " + pendingRecords);
    jLabel14.setText("Total Cancelled Stocks : " + cancelledRecords);
    jLabel9.setText("Total Sell Price : "
            + String.format(java.util.Locale.US, "₱%,.2f", totalSellPrice));
}



    private void setupSearch() {
        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        TableRowSorter<DefaultTableModel> sorter
                = new TableRowSorter<>(model);

        for (int i = 0; i < model.getColumnCount(); i++) {
            sorter.setSortable(i, false);
        }

        jTable1.setRowSorter(sorter);

        jTextField1.getDocument().addDocumentListener(
                new DocumentListener() {

            private void search() {
                String text = jTextField1.getText().trim();

                if (text.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(
                            RowFilter.regexFilter(
                                    "(?i)" + java.util.regex.Pattern.quote(text),
                                    1
                            )
                    );
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                search();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                search();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                search();
            }
        }
        );
    }

    private void editArrival() {
    int selectedRow = jTable1.getSelectedRow();
 
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an arrival record first.");
        return;
    }
 
    int row = jTable1.convertRowIndexToModel(selectedRow);
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
 
    int arrivalId = Integer.parseInt(model.getValueAt(row, 6).toString());
    int oldQuantity = Integer.parseInt(
            model.getValueAt(row, 2).toString().replace("+", "")
    );
 
    String oldDate = model.getValueAt(row, 4) == null
            ? ""
            : model.getValueAt(row, 4).toString();
 
    String oldStatus = model.getValueAt(row, 5) == null
            ? "Pending"
            : model.getValueAt(row, 5).toString();
 
    int userId = UserSession.getUserId();
    if (userId <= 0) {
        JOptionPane.showMessageDialog(this, "Please log in first.");
        return;
    }
 
    
    double existingSellingPrice = 0.0;
    String initialPriceSql =
            "SELECT p.price "
            + "FROM tbl_stocks_in s "
            + "JOIN tbl_products p ON s.product_id = p.id "
            + "WHERE s.id = ? AND s.users_id = ?";
 
    try (Connection priceCon = DBConnection.connect()) {
        if (priceCon == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }
 
        try (PreparedStatement pricePst = priceCon.prepareStatement(initialPriceSql)) {
            pricePst.setInt(1, arrivalId);
            pricePst.setInt(2, userId);
 
            try (ResultSet priceRs = pricePst.executeQuery()) {
                if (priceRs.next()) {
                    existingSellingPrice = priceRs.getDouble("price");
                } else {
                    JOptionPane.showMessageDialog(this, "Arrival record was not found.");
                    return;
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this,
                "Unable to load current selling price: " + ex.getMessage());
        return;
    }
 
    JTextField quantityField = new JTextField(String.valueOf(oldQuantity));
 
    double existingMarkup = 20.0;
    double existingCost = existingSellingPrice / (1.0 + existingMarkup / 100.0);
 
    JTextField costPerPieceField = new JTextField(
            String.format(java.util.Locale.US, "%.2f", existingCost)
    );
 
    JTextField markupPercentField = new JTextField(
            String.valueOf((int) existingMarkup)
    );
 
    JLabel sellPriceLabel = new JLabel(
            String.format(
                    java.util.Locale.US,
                    "₱%.2f per piece",
                    existingSellingPrice
            )
    );
 
    Runnable recalculateSellPrice = () -> {
        try {
            double cost = Double.parseDouble(costPerPieceField.getText().trim());
            double markup = Double.parseDouble(markupPercentField.getText().trim());
 
            if (!Double.isFinite(cost) || !Double.isFinite(markup)
                    || cost < 0 || markup < 0) {
                sellPriceLabel.setText("Enter non-negative values");
                return;
            }
 
            double sellingPrice = Math.round(
                    (cost + cost * markup / 100.0) * 100.0
            ) / 100.0;
 
            sellPriceLabel.setText(
                    String.format(java.util.Locale.US, "₱%.2f per piece", sellingPrice)
            );
        } catch (NumberFormatException ex) {
            sellPriceLabel.setText("Enter valid numbers");
        }
    };
 
    DocumentListener priceCalculatorListener = new DocumentListener() {
        @Override
        public void insertUpdate(DocumentEvent e) { recalculateSellPrice.run(); }
        @Override
        public void removeUpdate(DocumentEvent e) { recalculateSellPrice.run(); }
        @Override
        public void changedUpdate(DocumentEvent e) { recalculateSellPrice.run(); }
    };
 
    costPerPieceField.getDocument().addDocumentListener(priceCalculatorListener);
    markupPercentField.getDocument().addDocumentListener(priceCalculatorListener);
 
    
    java.util.Set<String> dateSet = new java.util.LinkedHashSet<>();
    if (oldDate != null && !oldDate.isEmpty()) {
        dateSet.add(oldDate);
    }
    LocalDate today = LocalDate.now();
    for (int i = 0; i <= 14; i++) {
        dateSet.add(today.minusDays(i).toString());
    }
    java.util.List<String> dateList = new java.util.ArrayList<>(dateSet);
    dateList.sort((d1, d2) -> d2.compareTo(d1));
 
    JComboBox<String> dateBox = new JComboBox<>(dateList.toArray(new String[0]));
    dateBox.setSelectedItem(oldDate);
 
    JComboBox<String> statusBox = new JComboBox<>(
            new String[]{"Received", "Pending", "Cancelled"}
    );
    statusBox.setSelectedItem(oldStatus);
 
    Object[] fields = {
        "Quantity:", quantityField,
        "Cost per Piece (₱):", costPerPieceField,
        "Markup (%):", markupPercentField,
        "Selling Price per Piece:", sellPriceLabel,
        "Date:", dateBox,
        "Status:", statusBox
    };
 
    int choice = JOptionPane.showConfirmDialog(
            this,
            fields,
            "Edit Stock Arrival",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );
 
    if (choice != JOptionPane.OK_OPTION) {
        return;
    }
 
  
    int newQuantity;
    Date newDate;
    String newStatus = statusBox.getSelectedItem().toString();
    double newSellingPrice;
 
    try {
        newQuantity = Integer.parseInt(quantityField.getText().trim());
        if (newQuantity <= 0) {
            JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.");
            return;
        }
 
        newDate = Date.valueOf(((String) dateBox.getSelectedItem()).trim());
 
        double cost = Double.parseDouble(costPerPieceField.getText().trim());
        double markup = Double.parseDouble(markupPercentField.getText().trim());
 
        if (!Double.isFinite(cost) || !Double.isFinite(markup)
                || cost < 0 || markup < 0) {
            throw new NumberFormatException();
        }
 
        newSellingPrice = Math.round(
                (cost + cost * markup / 100.0) * 100.0
        ) / 100.0;
 
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(this,
                "Enter a valid quantity, cost, markup, and date.");
        return;
    }
 
    // ===== Database update =====
    String findSql =
            "SELECT s.product_id, s.quantity, s.status "
            + "FROM tbl_stocks_in s "
            + "WHERE s.id = ? AND s.users_id = ? FOR UPDATE";
 
    String updateArrivalSql =
            "UPDATE tbl_stocks_in "
            + "SET quantity = ?, date_in = ?, status = ? "
            + "WHERE id = ? AND users_id = ?";
 
    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }
 
        con.setAutoCommit(false);
 
        try {
            int productId;
            int databaseOldQuantity;
            String databaseOldStatus;
 
            try (PreparedStatement pst = con.prepareStatement(findSql)) {
                pst.setInt(1, arrivalId);
                pst.setInt(2, userId);
 
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Arrival record was not found.");
                    }
                    productId = rs.getInt("product_id");
                    databaseOldQuantity = rs.getInt("quantity");
                    databaseOldStatus = rs.getString("status");
                }
            }
 
            
            int oldTaken = "Cancelled".equalsIgnoreCase(databaseOldStatus)
                    ? 0 : databaseOldQuantity;
            int newTaken = "Cancelled".equalsIgnoreCase(newStatus)
                    ? 0 : newQuantity;
            int extraTaken = newTaken - oldTaken;   // > 0 take more, < 0 give back
 
            if (extraTaken != 0) {
                String stockSql;
                if (extraTaken > 0) {
                    stockSql = "UPDATE tbl_products SET stock = stock - ? "
                            + "WHERE id = ? AND users_id = ? AND stock >= ?";
                } else {
                    stockSql = "UPDATE tbl_products SET stock = stock + ? "
                            + "WHERE id = ? AND users_id = ?";
                }
 
                try (PreparedStatement pst = con.prepareStatement(stockSql)) {
                    pst.setInt(1, Math.abs(extraTaken));
                    pst.setInt(2, productId);
                    pst.setInt(3, userId);
                    if (extraTaken > 0) {
                        pst.setInt(4, extraTaken);
                    }
                    if (pst.executeUpdate() != 1) {
                        throw new SQLException(
                                "Not enough stock in inventory to take "
                                + extraTaken + " more."
                        );
                    }
                }
            }
 
            try (PreparedStatement pst = con.prepareStatement(
                    "UPDATE tbl_products SET status = CASE "
                    + "WHEN stock = 0 THEN 'Empty' "
                    + "WHEN stock <= 10 THEN 'Low' "
                    + "ELSE 'Available' END "
                    + "WHERE id = ? AND users_id = ?")) {
                pst.setInt(1, productId);
                pst.setInt(2, userId);
                pst.executeUpdate();
            }
 
            String updateProductPriceSql =
                    "UPDATE tbl_products SET price = ? WHERE id = ? AND users_id = ?";
 
            try (PreparedStatement pst = con.prepareStatement(updateProductPriceSql)) {
                pst.setDouble(1, Math.abs(newSellingPrice - existingSellingPrice) < 0.005
                        ? existingSellingPrice : newSellingPrice);
                pst.setInt(2, productId);
                pst.setInt(3, userId);
                if (pst.executeUpdate() != 1) {
                    throw new SQLException("Product selling price could not be updated.");
                }
            }
 
            try (PreparedStatement pst = con.prepareStatement(updateArrivalSql)) {
                pst.setInt(1, newQuantity);
                pst.setDate(2, newDate);
                pst.setString(3, newStatus);
                pst.setInt(4, arrivalId);
                pst.setInt(5, userId);
                if (pst.executeUpdate() != 1) {
                    throw new SQLException("Arrival record could not be updated.");
                }
            }
 
            con.commit();
            ActivityLog.log("Stock In edited: " + model.getValueAt(row, 1)
                    + " (" + newStatus + ")");
            loadStockInRecords();
 
            JOptionPane.showMessageDialog(this, "Arrival record updated successfully.");
 
        } catch (Exception e) {
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(true);
        }
 
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Edit failed: " + e.getMessage());
    }
}
   
   private void archiveSelectedRecord() {
    int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(this,
                "Please select an arrival record first.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Archive this arrival record?\nIt will be hidden from the main list.",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    int modelRow = jTable1.convertRowIndexToModel(row);
    int arrivalId = Integer.parseInt(
            jTable1.getModel().getValueAt(modelRow, 6).toString());

    int userId = UserSession.getUserId();

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }

        String sql = "UPDATE tbl_stocks_in SET status = 'Archived' "
                   + "WHERE id = ? AND users_id = ?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, arrivalId);
            pst.setInt(2, userId);

            if (pst.executeUpdate() != 1) {
                throw new SQLException("Arrival record could not be archived.");
            }
        }

        ActivityLog.log("Stock In archived: "
                + jTable1.getModel().getValueAt(modelRow, 1));
        loadStockInRecords();
        JOptionPane.showMessageDialog(this, "Arrival archived successfully.");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
                "Archive failed: " + e.getMessage());
    }
}

private void viewArchivedArrivals() {

    // ===== Table model =====
    DefaultTableModel archiveModel = new DefaultTableModel(
            new Object[]{"ID", "Product Name", "Quantity", "Sell Price", "Date", "Status", "DB_ID"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    JTable archiveTable = new JTable(archiveModel);
    archiveTable.setRowHeight(28);
    archiveTable.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
    archiveTable.setBackground(java.awt.Color.WHITE);
    archiveTable.setGridColor(new java.awt.Color(230, 230, 230));
    archiveTable.setSelectionBackground(new java.awt.Color(255, 220, 150));
    archiveTable.setSelectionForeground(java.awt.Color.BLACK);
    archiveTable.setShowHorizontalLines(true);
    archiveTable.setShowVerticalLines(false);

    
    archiveTable.getColumnModel().getColumn(6).setMinWidth(0);
    archiveTable.getColumnModel().getColumn(6).setMaxWidth(0);
    archiveTable.getColumnModel().getColumn(6).setWidth(0);

    
    archiveTable.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    archiveTable.getTableHeader().setBackground(new java.awt.Color(9, 9, 89));
    archiveTable.getTableHeader().setForeground(java.awt.Color.WHITE);
    archiveTable.getTableHeader().setReorderingAllowed(false);
    archiveTable.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 32));
    archiveTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

    JScrollPane scrollPane = new JScrollPane(archiveTable);
    scrollPane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(9, 9, 89), 1));
    scrollPane.getViewport().setBackground(java.awt.Color.WHITE);

    // ===== Filters =====
    JComboBox<String> cmbArchiveCategory = new JComboBox<>(new String[]{
        "All", "Supplies", "Office", "Electronics", "Consumables", "Others"
    });

    JComboBox<String> cmbArchiveDateSort = new JComboBox<>(new String[]{
        "Newest First", "Oldest First"
    });

    cmbArchiveCategory.setBackground(java.awt.Color.WHITE);
    cmbArchiveDateSort.setBackground(java.awt.Color.WHITE);
    cmbArchiveCategory.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
    cmbArchiveDateSort.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));

    
    Runnable loadArchiveData = () -> {
        archiveModel.setRowCount(0);

        String selectedCategory = String.valueOf(cmbArchiveCategory.getSelectedItem());
        String dateOrder = "Newest First".equals(cmbArchiveDateSort.getSelectedItem())
                ? "DESC" : "ASC";

        String sql
                = "SELECT s.id, s.product_name, s.quantity, s.date_in, "
                + "s.status, p.price "
                + "FROM tbl_stocks_in s "
                + "JOIN tbl_products p ON s.product_id = p.id "
                + "WHERE s.users_id = ? "
                + "AND s.status = 'Archived' "
                + ("All".equals(selectedCategory) ? "" : "AND p.category = ? ")
                + "ORDER BY s.date_in " + dateOrder + ", s.id " + dateOrder;

        try (Connection con = DBConnection.connect()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Cannot connect to database.");
                return;
            }

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setInt(1, UserSession.getUserId());

                if (!"All".equals(selectedCategory)) {
                    pst.setString(2, selectedCategory);
                }

                try (ResultSet rs = pst.executeQuery()) {
                    int rowNumber = 1;
                    while (rs.next()) {
                        archiveModel.addRow(new Object[]{
                            rowNumber++,
                            rs.getString("product_name"),
                            "+" + rs.getInt("quantity"),
                            String.format(java.util.Locale.US, "₱%.2f", rs.getDouble("price")),
                            rs.getDate("date_in"),
                            rs.getString("status"),
                            rs.getInt("id")          
                        });
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to load archived records: " + e.getMessage());
        }
    };

    cmbArchiveCategory.addActionListener(e -> loadArchiveData.run());
    cmbArchiveDateSort.addActionListener(e -> loadArchiveData.run());
    loadArchiveData.run();

   
    JPanel topBar = new JPanel(new java.awt.BorderLayout());
    topBar.setBackground(new java.awt.Color(9, 9, 89));
    topBar.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 15, 10, 15));
    topBar.setPreferredSize(new java.awt.Dimension(0, 50));

    JLabel titleLabel = new JLabel("Archived Stock Arrivals");
    titleLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18));
    titleLabel.setForeground(new java.awt.Color(255, 153, 0));

    JPanel filterPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
    filterPanel.setOpaque(false);

    JLabel catLabel = new JLabel("Category:");
    catLabel.setForeground(java.awt.Color.WHITE);
    catLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));

    JLabel dateLabel = new JLabel("Sort:");
    dateLabel.setForeground(java.awt.Color.WHITE);
    dateLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));

    filterPanel.add(catLabel);
    filterPanel.add(cmbArchiveCategory);
    filterPanel.add(dateLabel);
    filterPanel.add(cmbArchiveDateSort);

    topBar.add(titleLabel, java.awt.BorderLayout.WEST);
    topBar.add(filterPanel, java.awt.BorderLayout.EAST);

   
    JPanel centerPanel = new JPanel(new java.awt.BorderLayout());
    centerPanel.setBackground(new java.awt.Color(255, 179, 0));
    centerPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
    centerPanel.add(scrollPane, java.awt.BorderLayout.CENTER);

    
    JButton undoButton = new JButton("Undo Archive");
    undoButton.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    undoButton.setBackground(new java.awt.Color(20, 125, 65));   // green
    undoButton.setForeground(java.awt.Color.WHITE);
    undoButton.setFocusPainted(false);
    undoButton.setPreferredSize(new java.awt.Dimension(130, 32));

    JButton closeButton = new JButton("Close");
    closeButton.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
    closeButton.setBackground(new java.awt.Color(9, 9, 89));
    closeButton.setForeground(java.awt.Color.WHITE);
    closeButton.setFocusPainted(false);
    closeButton.setPreferredSize(new java.awt.Dimension(100, 32));

    JPanel bottomPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
    bottomPanel.setBackground(new java.awt.Color(255, 179, 0));
    bottomPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 10, 10));
    bottomPanel.add(undoButton);
    bottomPanel.add(closeButton);

    // ===== MAIN PANEL =====
    JPanel mainPanel = new JPanel(new java.awt.BorderLayout());
    mainPanel.setBackground(new java.awt.Color(255, 179, 0));
    mainPanel.add(topBar, java.awt.BorderLayout.NORTH);
    mainPanel.add(centerPanel, java.awt.BorderLayout.CENTER);
    mainPanel.add(bottomPanel, java.awt.BorderLayout.SOUTH);

   
    javax.swing.JDialog dialog = new javax.swing.JDialog(this, "Archive List", true);
    dialog.setDefaultCloseOperation(javax.swing.JDialog.DISPOSE_ON_CLOSE);
    dialog.setContentPane(mainPanel);
    dialog.setSize(820, 420);
    dialog.setLocationRelativeTo(this);
    dialog.setResizable(true);

    // ===== Undo Archive  =====
    undoButton.addActionListener(e -> {
    int selectedRow = archiveTable.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(dialog,
                "Please select a record to restore.");
        return;
    }

   
    int qty = Integer.parseInt(
            archiveModel.getValueAt(selectedRow, 2).toString().replace("+", "").trim());
    if (qty <= 0) {
        JOptionPane.showMessageDialog(dialog,
                "This record was fully sold out and cannot be restored.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(dialog,
            "Restore this record back to the main list?\n(Status will be set to Pending)",
            "Undo Archive",
            JOptionPane.YES_NO_OPTION);

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    int arrivalId = Integer.parseInt(
            archiveModel.getValueAt(selectedRow, 6).toString());

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(dialog, "Cannot connect to database.");
            return;
        }

        String sql = "UPDATE tbl_stocks_in SET status = 'Pending' "
                   + "WHERE id = ? AND users_id = ?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, arrivalId);
            pst.setInt(2, UserSession.getUserId());

            if (pst.executeUpdate() == 1) {
                ActivityLog.log("Stock In restored: "
                        + archiveModel.getValueAt(selectedRow, 1));
                JOptionPane.showMessageDialog(dialog,
                        "Record restored successfully.");
                loadArchiveData.run();
                loadStockInRecords();
            } else {
                JOptionPane.showMessageDialog(dialog,
                        "Failed to restore the record.");
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(dialog,
                "Error: " + ex.getMessage());
    }
});

    closeButton.addActionListener(e -> dialog.dispose());

    dialog.setVisible(true);
}

    private void deleteArrival() {   // keep the same method name so the button still works

    String[] options = {
        "Archive Selected Record",
        "View Archived List",
        "Cancel"
    };

    int choice = JOptionPane.showOptionDialog(
            this,
            "What do you want to do?",
            "Archive Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
    );

    if (choice == 0) {
        // ===== Archive the selected record =====
        archiveSelectedRecord();
    } else if (choice == 1) {
        // ===== Show archived list =====
        viewArchivedArrivals();
    }
    
}

    private static final int DESIGN_WIDTH = 1100;
    private static final int DESIGN_HEIGHT = 652;

    private ResponsiveScaler responsiveScaler;

    private void setupResponsiveLayout() {
        setMinimumSize(new Dimension(DESIGN_WIDTH, DESIGN_HEIGHT));

        layoutAll(masterPanel);

        Container content = getContentPane();
        content.removeAll();
        content.setLayout(new java.awt.BorderLayout());
        content.add(masterPanel, java.awt.BorderLayout.CENTER);

        responsiveScaler = new ResponsiveScaler(
                masterPanel, DESIGN_WIDTH, DESIGN_HEIGHT);

        content.revalidate();
        content.repaint();
    }

    private static void layoutAll(Container container) {
        container.doLayout();

        for (Component component : container.getComponents()) {
            if (component instanceof Container) {
                layoutAll((Container) component);
            }
        }
    }

    private static final class ResponsiveScaler {

        private final JPanel root;
        private final int designWidth;
        private final int designHeight;

        private final Map<Component, java.awt.Rectangle> originalBounds
                = new IdentityHashMap<>();
        private final Map<JComponent, Font> originalFonts
                = new IdentityHashMap<>();
        private final Map<JComponent, Icon> originalIcons
                = new IdentityHashMap<>();

        ResponsiveScaler(JPanel root, int designWidth, int designHeight) {
            this.root = root;
            this.designWidth = designWidth;
            this.designHeight = designHeight;

            capture(root);
            update();
        }

        private void capture(Container parent) {
            for (Component component : parent.getComponents()) {
                originalBounds.put(
                        component,
                        new java.awt.Rectangle(component.getBounds()));

                if (component instanceof JComponent) {
                    JComponent jc = (JComponent) component;

                    if (jc.getFont() != null) {
                        originalFonts.put(jc, jc.getFont());
                    }

                    Icon icon = null;

                    if (jc instanceof javax.swing.JLabel) {
                        icon = ((javax.swing.JLabel) jc).getIcon();
                    } else if (jc instanceof AbstractButton) {
                        icon = ((AbstractButton) jc).getIcon();
                    }

                    if (icon != null) {
                        originalIcons.put(jc, icon);
                    }
                }

                if (component instanceof Container) {
                    Container child = (Container) component;
                    capture(child);
                    child.setLayout(null);
                }
            }
        }

        void update() {
            if (root.getWidth() <= 0 || root.getHeight() <= 0) {
                return;
            }

            double scaleX = root.getWidth() / (double) designWidth;
            double scaleY = root.getHeight() / (double) designHeight;

            double uniformScale = Math.min(scaleX, scaleY);

            for (Map.Entry<Component, java.awt.Rectangle> entry
                    : originalBounds.entrySet()) {

                Component component = entry.getKey();
                java.awt.Rectangle original = entry.getValue();

                int x = (int) Math.round(original.x * scaleX);
                int y = (int) Math.round(original.y * scaleY);
                int width = Math.max(
                        1, (int) Math.round(original.width * scaleX));
                int height = Math.max(
                        1, (int) Math.round(original.height * scaleY));

                component.setBounds(x, y, width, height);
            }

            for (Map.Entry<JComponent, Font> entry
                    : originalFonts.entrySet()) {

                JComponent component = entry.getKey();
                Font original = entry.getValue();

                int size = Math.max(
                        8,
                        (int) Math.round(original.getSize2D() * uniformScale));

                component.setFont(original.deriveFont(
                        original.getStyle(), (float) size));
            }

            for (Map.Entry<JComponent, Icon> entry
                    : originalIcons.entrySet()) {

                JComponent component = entry.getKey();
                Icon originalIcon = entry.getValue();

                if (!(originalIcon instanceof ImageIcon)) {
                    continue;
                }

                ImageIcon imageIcon = (ImageIcon) originalIcon;
                Image image = imageIcon.getImage();

                int width = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconWidth() * scaleX));
                int height = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconHeight() * scaleY));

                Image scaledImage = image.getScaledInstance(
                        width, height, Image.SCALE_SMOOTH);

                ImageIcon scaledIcon = new ImageIcon(scaledImage);

                if (component instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) component).setIcon(scaledIcon);
                } else if (component instanceof AbstractButton) {
                    ((AbstractButton) component).setIcon(scaledIcon);
                }
            }

            root.revalidate();
            root.repaint();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        masterPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        dashboard = new javax.swing.JButton();
        manage = new javax.swing.JButton();
        view = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        stock = new javax.swing.JButton();
        stockout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        cmbDateSort = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        masterPanel.setPreferredSize(new java.awt.Dimension(0, 0));
        masterPanel.addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsListener() {
            public void ancestorMoved(java.awt.event.HierarchyEvent evt) {
            }
            public void ancestorResized(java.awt.event.HierarchyEvent evt) {
                masterPanelAncestorResized(evt);
            }
        });
        masterPanel.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(226, 136, 1));
        jPanel2.setRequestFocusEnabled(false);

        dashboard.setBackground(new java.awt.Color(255, 255, 51));
        dashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard.setForeground(new java.awt.Color(0, 0, 204));
        dashboard.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        dashboard.setText("Dashboard");
        dashboard.setFocusPainted(false);
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dashboard.addActionListener(this::dashboardActionPerformed);

        manage.setBackground(new java.awt.Color(255, 255, 51));
        manage.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        manage.setForeground(new java.awt.Color(0, 0, 204));
        manage.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        manage.setText("Manage Inventory  ");
        manage.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manage.addActionListener(this::manageActionPerformed);

        view.setBackground(new java.awt.Color(255, 255, 51));
        view.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 204));
        view.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        view.setText("SmartStock Reports");
        view.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        view.addActionListener(this::viewActionPerformed);

        logout.setBackground(new java.awt.Color(255, 255, 51));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 0, 204));
        logout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (4).png")); // NOI18N
        logout.setText("Log Out");
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        jLabel4.setBackground(new java.awt.Color(255, 179, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Main Menu");
        jLabel4.setOpaque(true);

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 268, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        stock.setBackground(new java.awt.Color(255, 204, 51));
        stock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stock.setForeground(new java.awt.Color(0, 0, 204));
        stock.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        stock.setText("Stock In/Arrivals");
        stock.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        stock.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stock.addActionListener(this::stockActionPerformed);

        stockout.setBackground(new java.awt.Color(255, 255, 51));
        stockout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockout.setForeground(new java.awt.Color(0, 0, 204));
        stockout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        stockout.setText("Stock Out/Sales");
        stockout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stockout.addActionListener(this::stockoutActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(manage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stockout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(jLabel4)))
                .addContainerGap(92, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addGap(4, 4, 4)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dashboard)
                .addGap(18, 18, 18)
                .addComponent(manage)
                .addGap(18, 18, 18)
                .addComponent(stock)
                .addGap(18, 18, 18)
                .addComponent(stockout)
                .addGap(18, 18, 18)
                .addComponent(view)
                .addGap(45, 45, 45)
                .addComponent(logout)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel2);
        jPanel2.setBounds(0, 111, 380, 550);

        jPanel3.setBackground(new java.awt.Color(9, 9, 89));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        jLabel3.setText("Stock In/Arrivals");

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 359, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel3)))
                .addContainerGap(215, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel3);
        jPanel3.setBounds(376, 0, 730, 110);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton2.setBackground(new java.awt.Color(0, 51, 102));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("✎ Edit");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 51, 102));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("✚ Stock In");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 51, 102));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("↻ Refresh");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jTextField1.setForeground(new java.awt.Color(51, 51, 51));
        jTextField1.setText(" Search Product");

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("🔍︎");

        jButton1.setBackground(new java.awt.Color(0, 51, 102));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("ⓘ Archive");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(185, 185, 185))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jButton5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2)
                            .addComponent(jButton3)
                            .addComponent(jButton1))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        masterPanel.add(jPanel1);
        jPanel1.setBounds(430, 190, 630, 40);

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        jLabel10.setBackground(new java.awt.Color(102, 102, 102));
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Category :");
        jLabel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel10.setOpaque(true);

        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Supplies", "Office", "Electronics", "Consumables", "Others" }));
        cmbCategory.addActionListener(this::cmbCategoryActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbCategory, 0, 78, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        masterPanel.add(jPanel10);
        jPanel10.setBounds(430, 240, 160, 30);

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        cmbDateSort.setForeground(new java.awt.Color(255, 255, 255));
        cmbDateSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Newest First", "Oldest First", "All Dates" }));
        cmbDateSort.addActionListener(this::cmbDateSortActionPerformed);

        jLabel11.setBackground(new java.awt.Color(102, 102, 102));
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Date :");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel11.setOpaque(true);

        jLabel15.setBackground(new java.awt.Color(102, 102, 102));
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Status Category :");
        jLabel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel15.setOpaque(true);

        jComboBox1.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, 0, 103, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbDateSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbDateSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        masterPanel.add(jPanel5);
        jPanel5.setBounds(600, 240, 460, 30);

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Quantity", "Sell Price", "Date", "Status", "Database ID"
            }
        ));
        jTable1.setPreferredSize(new java.awt.Dimension(430, 280));
        jScrollPane1.setViewportView(jTable1);

        masterPanel.add(jScrollPane1);
        jScrollPane1.setBounds(430, 280, 630, 140);

        jPanel11.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel11);
        jPanel11.setBounds(380, 140, 280, 20);

        jPanel15.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel15);
        jPanel15.setBounds(680, 140, 100, 20);

        jPanel12.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 310, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel12);
        jPanel12.setBounds(800, 140, 310, 20);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel13);
        jPanel13.setBounds(380, 550, 340, 20);

        jPanel14.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel14);
        jPanel14.setBounds(380, 590, 610, 20);

        jPanel16.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel16);
        jPanel16.setBounds(730, 550, 370, 20);

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel17);
        jPanel17.setBounds(1000, 590, 100, 20);

        jPanel21.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel21);
        jPanel21.setBounds(1100, 10, 10, 650);

        jPanel22.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel22);
        jPanel22.setBounds(380, 20, 10, 630);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel18Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 110, Short.MAX_VALUE)
            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel18Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        masterPanel.add(jPanel18);
        jPanel18.setBounds(0, 0, 380, 110);

        jPanel28.setBackground(new java.awt.Color(255, 255, 102));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Total Pending Stocks :  0");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel13))
        );

        masterPanel.add(jPanel28);
        jPanel28.setBounds(860, 430, 210, 20);

        jPanel27.setBackground(new java.awt.Color(255, 255, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Total Stock in : 0");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5))
        );

        masterPanel.add(jPanel27);
        jPanel27.setBounds(410, 460, 200, 20);

        jPanel29.setBackground(new java.awt.Color(255, 255, 102));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Total Item Received :  0");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel8))
        );

        masterPanel.add(jPanel29);
        jPanel29.setBounds(410, 430, 200, 20);

        jPanel30.setBackground(new java.awt.Color(255, 255, 102));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Total Received Stocks :  0");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel12))
        );

        masterPanel.add(jPanel30);
        jPanel30.setBounds(620, 460, 230, 20);

        jPanel31.setBackground(new java.awt.Color(255, 255, 102));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("Total Sell Price :  0");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel9))
        );

        masterPanel.add(jPanel31);
        jPanel31.setBounds(620, 430, 230, 20);

        jPanel32.setBackground(new java.awt.Color(255, 255, 102));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Total Cancelled Stocks :  0");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel14))
        );

        masterPanel.add(jPanel32);
        jPanel32.setBounds(860, 460, 210, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1112, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void openPage(JFrame nextPage) {

        java.awt.Rectangle currentBounds = this.getBounds();

        boolean maximized
                = (this.getExtendedState() & JFrame.MAXIMIZED_BOTH)
                == JFrame.MAXIMIZED_BOTH;

        nextPage.setVisible(true);

        if (maximized) {
            nextPage.setExtendedState(JFrame.MAXIMIZED_BOTH);
        } else {
            nextPage.setBounds(currentBounds);
        }

        this.dispose();
    }

    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
        HomePage home = new HomePage();
        openPage(home);
    }//GEN-LAST:event_dashboardActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Log Out", javax.swing.JOptionPane.YES_NO_OPTION);

        if (choice == javax.swing.JOptionPane.YES_OPTION) {
            LoginPage loginForm = new LoginPage();
            loginForm.setVisible(true);
            this.dispose();
        } else {
        }
    }//GEN-LAST:event_logoutActionPerformed

    private void manageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageActionPerformed
        ManagePage manage = new ManagePage();
        openPage(manage);
    }//GEN-LAST:event_manageActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        ViewReportPage view = new ViewReportPage();
        openPage(view);
    }//GEN-LAST:event_viewActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        deleteArrival();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        recordArrival();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        loadStockInRecords();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_formComponentResized

    private void masterPanelAncestorResized(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_masterPanelAncestorResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_masterPanelAncestorResized

    private void stockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockActionPerformed

    }//GEN-LAST:event_stockActionPerformed

    private void stockoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockoutActionPerformed
        StockoutPage stockout = new StockoutPage();
        openPage(stockout);
    }//GEN-LAST:event_stockoutActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        if (!loadingDateOptions) {
            loadStockInRecords();
        }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        editArrival();
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {

    }//GEN-LAST:event_jButton2ActionPerformed

    private void cmbDateSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDateSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbDateSortActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new StockinPage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JComboBox<String> cmbDateSort;
    private javax.swing.JButton dashboard;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton logout;
    private javax.swing.JButton manage;
    private javax.swing.JPanel masterPanel;
    private javax.swing.JButton stock;
    private javax.swing.JButton stockout;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables
}
