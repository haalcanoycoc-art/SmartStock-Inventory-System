
package smartstock_inventory_system;


public class SmartStock_Inventory_System {

  
    //public static void main(String[] args) {
    //    
    //}
    
}
