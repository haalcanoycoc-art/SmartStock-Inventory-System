/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.sql.Date;
import java.awt.Font;
import java.awt.Image;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class StockoutPage extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(StockoutPage.class.getName());

    private boolean loadingDateOptions = false;
    private TableRowSorter<DefaultTableModel> sorter;

    
    public StockoutPage() {
        initComponents();
        setupResponsiveLayout();
        
        
        jTable1.setFillsViewportHeight(true);
        
        jTable1.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "ID", "Product Name", "Quantity",
            "Price", "Date", "Recipient", "Status", "Database ID"
        }
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    });

    jTable1.getTableHeader().setReorderingAllowed(false);

    jTable1.removeColumn(
        jTable1.getColumnModel().getColumn(7)
    );
    
    jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
    "All", "Completed", "Cancelled"
    }));
    jComboBox1.setSelectedItem("All");
    jComboBox1.addActionListener(e -> {
    if (!loadingDateOptions) {
        loadStockOutRecords();
    }
});
    
    setupStatusColors();
    setupSearch();
    setupDateSorting();
    loadStockOutRecords();
    
    }
    
    private void setupStatusColors() {
    javax.swing.table.DefaultTableCellRenderer renderer =
            new javax.swing.table.DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(
                javax.swing.JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {

            Component component = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            String status = value == null ? "" : value.toString();

            if (isSelected) {
                return component;
            }

            switch (status) {
                case "Completed":
                    component.setForeground(new java.awt.Color(20, 125, 65));   // green
                    component.setBackground(new java.awt.Color(215, 245, 225));
                    break;

                case "Cancelled":
                    component.setForeground(new java.awt.Color(190, 35, 35));   // red
                    component.setBackground(new java.awt.Color(255, 225, 225));
                    break;

                case "Archived":
                    component.setForeground(new java.awt.Color(80, 80, 80));
                    component.setBackground(new java.awt.Color(230, 230, 230));
                    break;

                default:
                    component.setForeground(table.getForeground());
                    component.setBackground(table.getBackground());
                    break;
            }

            component.setFont(component.getFont().deriveFont(java.awt.Font.BOLD));
            return component;
        }
    };

    
    jTable1.getColumnModel().getColumn(6).setCellRenderer(renderer);
}
    
    private void setupSearch() {
    DefaultTableModel model =
            (DefaultTableModel) jTable1.getModel();

    sorter = new TableRowSorter<>(model);

    for (int i = 0; i < model.getColumnCount(); i++) {
        sorter.setSortable(i, false);
    }

    jTable1.setRowSorter(sorter);

    
    jTextField1.getDocument().addDocumentListener(
        new DocumentListener() {
            private void filter() {
                String text = jTextField1.getText().trim();

                if (text.isEmpty()
                        || text.equalsIgnoreCase("Search Product")) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(
                        RowFilter.regexFilter(
                            "(?i)" +
                            java.util.regex.Pattern.quote(text),
                            1
                        )
                    );
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        }
    );
}
    
private static int availableToSell(Connection con, int productId, int userId)
        throws SQLException {
    String sql = "SELECT COALESCE(SUM(quantity), 0) FROM tbl_stocks_in "
            + "WHERE product_id = ? AND users_id = ? AND status = 'Received'";
    try (PreparedStatement pst = con.prepareStatement(sql)) {
        pst.setInt(1, productId);
        pst.setInt(2, userId);
        try (ResultSet rs = pst.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}

/** Takes stock from Received Stock In records (oldest first). Archives any that hit 0. */
private static void deductFromStockIn(Connection con, int productId, int userId,
                                      int saleId, int quantity) throws SQLException {
    java.util.List<int[]> batches = new ArrayList<>();   // {stockInId, qty}

    String selectSql = "SELECT id, quantity FROM tbl_stocks_in "
            + "WHERE product_id = ? AND users_id = ? "
            + "AND status = 'Received' AND quantity > 0 "
            + "ORDER BY date_in, id FOR UPDATE";
    try (PreparedStatement pst = con.prepareStatement(selectSql)) {
        pst.setInt(1, productId);
        pst.setInt(2, userId);
        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                batches.add(new int[]{rs.getInt("id"), rs.getInt("quantity")});
            }
        }
    }

    int remaining = quantity;
    for (int[] batch : batches) {
        if (remaining <= 0) break;

        int take = Math.min(batch[1], remaining);
        int left = batch[1] - take;

        try (PreparedStatement pst = con.prepareStatement(
                "UPDATE tbl_stocks_in SET quantity = ?, status = ? "
                + "WHERE id = ? AND users_id = ?")) {
            pst.setInt(1, left);
            pst.setString(2, left == 0 ? "Archived" : "Received");
            pst.setInt(3, batch[0]);
            pst.setInt(4, userId);
            pst.executeUpdate();
        }

        try (PreparedStatement pst = con.prepareStatement(
                "INSERT INTO tbl_stockout_allocations (stockout_id, stockin_id, quantity) "
                + "VALUES (?, ?, ?)")) {
            pst.setInt(1, saleId);
            pst.setInt(2, batch[0]);
            pst.setInt(3, take);
            pst.executeUpdate();
        }
        remaining -= take;
    }

    if (remaining > 0) {
        throw new SQLException("Not enough Received stock. Short by " + remaining);
    }
}


private static void returnToStockIn(Connection con, int saleId, int userId)
        throws SQLException {
    java.util.List<int[]> allocations = new ArrayList<>();   // {stockInId, qty}

    try (PreparedStatement pst = con.prepareStatement(
            "SELECT stockin_id, quantity FROM tbl_stockout_allocations WHERE stockout_id = ?")) {
        pst.setInt(1, saleId);
        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                allocations.add(new int[]{rs.getInt("stockin_id"), rs.getInt("quantity")});
            }
        }
    }

    for (int[] a : allocations) {
        try (PreparedStatement pst = con.prepareStatement(
                "UPDATE tbl_stocks_in SET "
                + "status = CASE WHEN status = 'Archived' AND quantity = 0 "
                + "THEN 'Received' ELSE status END, "
                + "quantity = quantity + ? "
                + "WHERE id = ? AND users_id = ?")) {
            pst.setInt(1, a[1]);
            pst.setInt(2, a[0]);
            pst.setInt(3, userId);
            pst.executeUpdate();
        }
    }

    try (PreparedStatement pst = con.prepareStatement(
            "DELETE FROM tbl_stockout_allocations WHERE stockout_id = ?")) {
        pst.setInt(1, saleId);
        pst.executeUpdate();
    }
}

private void loadStockOutRecords() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    int transactionCount = 0;
    int totalQuantity = 0;
    int completedCount = 0;
    int cancelledCount = 0;
    double totalRevenue = 0.0;

    String dateOrder = "DESC";
    if ("Oldest First".equals(cmbDateSort.getSelectedItem())) {
        dateOrder = "ASC";
    }

    String selectedCategory = String.valueOf(cmbCategory.getSelectedItem());
    String selectedStatus = String.valueOf(jComboBox1.getSelectedItem());

    String sql =
            "SELECT s.id, s.product_name, s.quantity, s.date_out, "
            + "s.costumer, s.status, s.total_amount "
            + "FROM tbl_stocks_out s "
            + "JOIN tbl_products p ON s.product_id = p.id "
            + "WHERE s.users_id = ? "
            + "AND s.status <> 'Archived' "
            + ("All".equals(selectedCategory) ? "" : "AND p.category = ? ")
            + ("All".equals(selectedStatus) ? "" : "AND s.status = ? ")
            + "ORDER BY s.date_out " + dateOrder
            + ", s.id " + dateOrder;

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to the database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            int param = 1;
            pst.setInt(param++, UserSession.getUserId());

            if (!"All".equals(selectedCategory)) {
                pst.setString(param++, selectedCategory);
            }
            if (!"All".equals(selectedStatus)) {
                pst.setString(param++, selectedStatus);
            }

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    int quantity = rs.getInt("quantity");
                    String status = rs.getString("status");
                    double totalAmount = rs.getDouble("total_amount");

                    model.addRow(new Object[]{
                        ++transactionCount,
                        rs.getString("product_name"),
                        "Completed".equalsIgnoreCase(status)
                                ? "-" + quantity : quantity,
                        String.format(java.util.Locale.US, "₱%.2f", totalAmount),
                        rs.getDate("date_out"),
                        rs.getString("costumer"),
                        status,
                        rs.getInt("id")
                    });

                    if ("Completed".equalsIgnoreCase(status)) {
                        totalQuantity += quantity;
                        totalRevenue += totalAmount;
                        completedCount++;
                    } else if ("Cancelled".equalsIgnoreCase(status)) {
                        cancelledCount++;
                    }
                }
            }
        }

        
        jLabel5.setText("Total Transaction : " + transactionCount);
        jLabel8.setText("Total Items Sold : " + totalQuantity);
        jLabel12.setText("Total Revenue : "
                + String.format(java.util.Locale.US, "₱%,.2f", totalRevenue));
        jLabel13.setText("Total Completed : " + completedCount);
        jLabel14.setText("Total Cancelled : " + cancelledCount);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Unable to load Stock Out records: " + e.getMessage()
        );
    }
}
    
private static class ProductOption {
    int id;
    String name;
    int stock;
    double price;

    ProductOption(int id, String name, int stock, double price) {
        this.id = id;
        this.name = name;
        this.stock = stock;
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " (Available: " + stock + ")";
    }
}

private void recordStockOut() {
    int userId = UserSession.getUserId();

    if (userId <= 0) {
        JOptionPane.showMessageDialog(this, "Please log in first.");
        return;
    }

    java.util.List<ProductOption> products = new ArrayList<>();

    // Only products that have Received stock from Stock In
    String sql =
            "SELECT p.id, p.product_name, p.price, "
            + "COALESCE(SUM(si.quantity), 0) AS available "
            + "FROM tbl_products p "
            + "JOIN tbl_stocks_in si ON si.product_id = p.id "
            + "AND si.users_id = p.users_id AND si.status = 'Received' "
            + "WHERE p.users_id = ? "
            + "GROUP BY p.id, p.product_name, p.price "
            + "HAVING available > 0 ORDER BY p.product_name";

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    products.add(new ProductOption(
                            rs.getInt("id"),
                            rs.getString("product_name"),
                            rs.getInt("available"),
                            rs.getDouble("price")
                    ));
                }
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
        return;
    }

    if (products.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "No Received stock found.\n"
                + "Record and mark items as Received in Stock In first."
        );
        return;
    }

    JComboBox<ProductOption> productBox =
            new JComboBox<>(products.toArray(new ProductOption[0]));

    JTextField quantityField = new JTextField();
    JTextField recipientField = new JTextField();
    JTextField dateField = new JTextField(LocalDate.now().toString());

    Object[] fields = {
        "Product (from Stock In):", productBox,
        "Quantity:", quantityField,
        "Recipient:", recipientField,
        "Date (YYYY-MM-DD):", dateField
    };

    if (JOptionPane.showConfirmDialog(
            this, fields, "Record Stock Out",
            JOptionPane.OK_CANCEL_OPTION
        ) != JOptionPane.OK_OPTION) {
        return;
    }

    ProductOption selected = (ProductOption) productBox.getSelectedItem();
    if (selected == null) return;

    String recipient = recipientField.getText().trim();
    int quantity;
    Date date;

    try {
        quantity = Integer.parseInt(quantityField.getText().trim());
        date = Date.valueOf(dateField.getText().trim());

        if (quantity <= 0) {
            JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.");
            return;
        }

        if (quantity > selected.stock) {
            JOptionPane.showMessageDialog(
                    this,
                    "Not enough Received stock.\nAvailable from Stock In: " + selected.stock
            );
            return;
        }

        if (recipient.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a recipient.");
            return;
        }

    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(
                this, "Enter a valid positive quantity and date (YYYY-MM-DD)."
        );
        return;
    }

    String insertSql =
            "INSERT INTO tbl_stocks_out "
            + "(users_id, product_id, product_name, quantity, costumer, "
            + "total_amount, date_out, status) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, 'Completed')";

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed.");
            return;
        }

        con.setAutoCommit(false);

        try {
            double price;
            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT price FROM tbl_products "
                    + "WHERE id = ? AND users_id = ? FOR UPDATE")) {
                pst.setInt(1, selected.id);
                pst.setInt(2, userId);
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Product was not found.");
                    }
                    price = rs.getDouble("price");
                }
            }

            int onShelf = availableToSell(con, selected.id, userId);
            if (onShelf < quantity) {
                throw new SQLException("Not enough Received stock. Available: " + onShelf);
            }

            int saleId;
            try (PreparedStatement pst = con.prepareStatement(
                    insertSql, Statement.RETURN_GENERATED_KEYS)) {
                pst.setInt(1, userId);
                pst.setInt(2, selected.id);
                pst.setString(3, selected.name);
                pst.setInt(4, quantity);
                pst.setString(5, recipient);
                pst.setDouble(6, price * quantity);
                pst.setDate(7, date);
                pst.executeUpdate();
                try (ResultSet keys = pst.getGeneratedKeys()) {
                    if (!keys.next()) {
                        throw new SQLException("Could not get sale ID.");
                    }
                    saleId = keys.getInt(1);
                }
            }

            
            deductFromStockIn(con, selected.id, userId, saleId, quantity);

            con.commit();
            ActivityLog.log("Sale recorded: " + selected.name + " -" + quantity);
            JOptionPane.showMessageDialog(this, "Stock Out recorded successfully.");
            loadStockOutRecords();

        } catch (Exception e) {
            con.rollback();
            JOptionPane.showMessageDialog(
                    this, "Stock Out failed: " + e.getMessage()
            );
        } finally {
            con.setAutoCommit(true);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}


 private void setupDateSorting() {
    loadingDateOptions = true;

    cmbDateSort.setSelectedItem("Newest First");

    loadingDateOptions = false;

    cmbDateSort.addActionListener(e -> {
        if (!loadingDateOptions) {
            loadStockOutRecords();
        }
    });
}

    
private void editStockOut() {
    int viewRow = jTable1.getSelectedRow();
    if (viewRow < 0) {
        JOptionPane.showMessageDialog(this, "Select a transaction first.");
        return;
    }

    int row = jTable1.convertRowIndexToModel(viewRow);
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    int transactionId = (int) model.getValueAt(row, 7);

    JTextField quantityField = new JTextField(
        String.valueOf(model.getValueAt(row, 2)).replace("-", "")
    );
    JTextField recipientField = new JTextField(
        String.valueOf(model.getValueAt(row, 5))
    );

    java.util.List<String> dateList = new java.util.ArrayList<>();
    java.time.LocalDate today = java.time.LocalDate.now();
    for (int i = -60; i <= 7; i++) {
        dateList.add(today.plusDays(i).toString());
    }
    JComboBox<String> dateBox = new JComboBox<>(dateList.toArray(new String[0]));

    String currentDate = String.valueOf(model.getValueAt(row, 4)).trim();
    if (currentDate.length() >= 10) {
        currentDate = currentDate.substring(0, 10);
    }
    dateBox.setSelectedItem(currentDate);
    if (dateBox.getSelectedIndex() < 0) {
        dateBox.setSelectedItem(today.toString());
    }

    JComboBox<String> statusBox = new JComboBox<>(
        new String[]{"Completed", "Cancelled"}
    );
    statusBox.setSelectedItem(model.getValueAt(row, 6));

    Object[] fields = {
        "Quantity:", quantityField,
        "Recipient:", recipientField,
        "Date:", dateBox,
        "Status:", statusBox
    };

    if (JOptionPane.showConfirmDialog(
            this, fields, "Edit Stock Out",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        ) != JOptionPane.OK_OPTION) {
        return;
    }

    int newQuantity;
    java.sql.Date newDate;
    String recipient = recipientField.getText().trim();
    String newStatus = (String) statusBox.getSelectedItem();

    try {
        newQuantity = Integer.parseInt(quantityField.getText().trim());
        if (newQuantity <= 0 || recipient.isEmpty()) {
            throw new IllegalArgumentException();
        }
        String selectedDate = (String) dateBox.getSelectedItem();
        newDate = java.sql.Date.valueOf(selectedDate);
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(
            this, "Enter a valid quantity and recipient."
        );
        return;
    }

    int userId = UserSession.getUserId();

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed.");
            return;
        }

        con.setAutoCommit(false);

        try {
            int productId;

            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT product_id FROM tbl_stocks_out " +
                    "WHERE id = ? AND users_id = ? FOR UPDATE")) {
                pst.setInt(1, transactionId);
                pst.setInt(2, userId);
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Transaction not found.");
                    }
                    productId = rs.getInt("product_id");
                }
            }

            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT id FROM tbl_products WHERE id = ? AND users_id = ? FOR UPDATE")) {
                pst.setInt(1, productId);
                pst.setInt(2, userId);
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Product not found.");
                    }
                }
            }

            
            returnToStockIn(con, transactionId, userId);

            
            if ("Completed".equalsIgnoreCase(newStatus)) {
                int onShelf = availableToSell(con, productId, userId);
                if (onShelf < newQuantity) {
                    throw new SQLException("Not enough Received stock. Available: " + onShelf);
                }
                deductFromStockIn(con, productId, userId, transactionId, newQuantity);
            }

            try (PreparedStatement pst = con.prepareStatement(
                    "UPDATE tbl_stocks_out SET quantity = ?, costumer = ?, " +
                    "date_out = ?, status = ?, total_amount = " +
                    "(SELECT price FROM tbl_products WHERE id = product_id) * ? " +
                    "WHERE id = ? AND users_id = ?")) {
                pst.setInt(1, newQuantity);
                pst.setString(2, recipient);
                pst.setDate(3, newDate);
                pst.setString(4, newStatus);
                pst.setInt(5, newQuantity);
                pst.setInt(6, transactionId);
                pst.setInt(7, userId);
                pst.executeUpdate();
            }

            con.commit();
            ActivityLog.log("Sale edited: " + model.getValueAt(row, 1)
                    + " (" + newStatus + ")");
            JOptionPane.showMessageDialog(this, "Transaction updated.");
            loadStockOutRecords();

        } catch (Exception e) {
            con.rollback();
            JOptionPane.showMessageDialog(
                this, "Edit failed: " + e.getMessage()
            );
        } finally {
            con.setAutoCommit(true);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}

private void deleteStockOut() {
    String[] options = {
        "Archive Selected Record",
        "View Archived List",
        "Cancel"
    };

    int choice = JOptionPane.showOptionDialog(
            this,
            "What do you want to do?",
            "Archive Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
    );

    if (choice == 0) {
        archiveSelectedStockOut();
    } else if (choice == 1) {
        viewArchivedStockOut();
    }
}

private void archiveSelectedStockOut() {
    int viewRow = jTable1.getSelectedRow();
    if (viewRow < 0) {
        JOptionPane.showMessageDialog(this, "Select a transaction first.");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Archive this transaction?\nIt will be hidden from the main list.",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION
    );
    if (confirm != JOptionPane.YES_OPTION) return;

    int row = jTable1.convertRowIndexToModel(viewRow);
    int transactionId = (int) jTable1.getModel().getValueAt(row, 7);
    int userId = UserSession.getUserId();

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Cannot connect to database.");
            return;
        }

        String sql = "UPDATE tbl_stocks_out SET status = 'Archived' "
                   + "WHERE id = ? AND users_id = ?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, transactionId);
            pst.setInt(2, userId);
            if (pst.executeUpdate() != 1) {
                throw new SQLException("Could not archive the record.");
            }
        }

        ActivityLog.log("Sale archived: " + jTable1.getModel().getValueAt(row, 1));
        loadStockOutRecords();
        JOptionPane.showMessageDialog(this, "Transaction archived.");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Archive failed: " + e.getMessage());
    }
}

private void viewArchivedStockOut() {
    DefaultTableModel archiveModel = new DefaultTableModel(
            new Object[]{"ID", "Product Name", "Quantity", "Price", "Date", "Recipient", "Status", "DB_ID"}, 0
    ) {
        @Override
        public boolean isCellEditable(int r, int c) { return false; }
    };

    javax.swing.JTable archiveTable = new javax.swing.JTable(archiveModel);
    archiveTable.setRowHeight(28);
    archiveTable.getTableHeader().setReorderingAllowed(false);
    archiveTable.getColumnModel().getColumn(7).setMinWidth(0);
    archiveTable.getColumnModel().getColumn(7).setMaxWidth(0);

    JComboBox<String> cmbCat = new JComboBox<>(new String[]{
        "All", "Supplies", "Office", "Electronics", "Consumables", "Others"
    });
    JComboBox<String> cmbSort = new JComboBox<>(new String[]{
        "Newest First", "Oldest First"
    });

    Runnable load = () -> {
        archiveModel.setRowCount(0);
        String cat = String.valueOf(cmbCat.getSelectedItem());
        String order = "Newest First".equals(cmbSort.getSelectedItem()) ? "DESC" : "ASC";

        String sql =
                "SELECT s.id, s.product_name, s.quantity, s.date_out, "
                + "s.costumer, s.status, s.total_amount "
                + "FROM tbl_stocks_out s "
                + "JOIN tbl_products p ON s.product_id = p.id "
                + "WHERE s.users_id = ? AND s.status = 'Archived' "
                + ("All".equals(cat) ? "" : "AND p.category = ? ")
                + "ORDER BY s.date_out " + order + ", s.id " + order;

        try (Connection con = DBConnection.connect()) {
            if (con == null) return;
            try (PreparedStatement pst = con.prepareStatement(sql)) {
                int p = 1;
                pst.setInt(p++, UserSession.getUserId());
                if (!"All".equals(cat)) pst.setString(p++, cat);

                try (ResultSet rs = pst.executeQuery()) {
                    int n = 1;
                    while (rs.next()) {
                        archiveModel.addRow(new Object[]{
                            n++,
                            rs.getString("product_name"),
                            rs.getInt("quantity"),
                            String.format(java.util.Locale.US, "₱%.2f", rs.getDouble("total_amount")),
                            rs.getDate("date_out"),
                            rs.getString("costumer"),
                            rs.getString("status"),
                            rs.getInt("id")
                        });
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    };

    cmbCat.addActionListener(e -> load.run());
    cmbSort.addActionListener(e -> load.run());
    load.run();

    JPanel topBar = new JPanel(new java.awt.BorderLayout());
    topBar.setBackground(new java.awt.Color(9, 9, 89));
    topBar.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 15, 10, 15));
    topBar.setPreferredSize(new java.awt.Dimension(0, 50));

    JLabel title = new JLabel("Archived Stock Out");
    title.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18));
    title.setForeground(new java.awt.Color(255, 153, 0));

    JPanel filters = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
    filters.setOpaque(false);
    JLabel cLab = new JLabel("Category:"); cLab.setForeground(java.awt.Color.WHITE);
    JLabel sLab = new JLabel("Sort:"); sLab.setForeground(java.awt.Color.WHITE);
    filters.add(cLab); filters.add(cmbCat);
    filters.add(sLab); filters.add(cmbSort);

    topBar.add(title, java.awt.BorderLayout.WEST);
    topBar.add(filters, java.awt.BorderLayout.EAST);

    JScrollPane scroll = new JScrollPane(archiveTable);
    scroll.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(9, 9, 89)));

    JPanel center = new JPanel(new java.awt.BorderLayout());
    center.setBackground(new java.awt.Color(255, 179, 0));
    center.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
    center.add(scroll, java.awt.BorderLayout.CENTER);

    
    JButton undoBtn = new JButton("Undo Archive");
    undoBtn.setBackground(new java.awt.Color(20, 125, 65));
    undoBtn.setForeground(java.awt.Color.WHITE);
    undoBtn.setFocusPainted(false);

    JButton closeBtn = new JButton("Close");
    closeBtn.setBackground(new java.awt.Color(9, 9, 89));
    closeBtn.setForeground(java.awt.Color.WHITE);
    closeBtn.setFocusPainted(false);

    JPanel bottom = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
    bottom.setBackground(new java.awt.Color(255, 179, 0));
    bottom.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 10, 10));
    bottom.add(undoBtn);
    bottom.add(closeBtn);

    JPanel main = new JPanel(new java.awt.BorderLayout());
    main.setBackground(new java.awt.Color(255, 179, 0));
    main.add(topBar, java.awt.BorderLayout.NORTH);
    main.add(center, java.awt.BorderLayout.CENTER);
    main.add(bottom, java.awt.BorderLayout.SOUTH);

    javax.swing.JDialog dialog = new javax.swing.JDialog(this, "Archive List", true);
    dialog.setContentPane(main);
    dialog.setSize(820, 420);
    dialog.setLocationRelativeTo(this);

    undoBtn.addActionListener(e -> {
        int sel = archiveTable.getSelectedRow();
        if (sel < 0) {
            JOptionPane.showMessageDialog(dialog, "Select a record to restore.");
            return;
        }
        int id = (int) archiveModel.getValueAt(sel, 7);
        try (Connection con = DBConnection.connect()) {
            if (con == null) return;
            try (PreparedStatement pst = con.prepareStatement(
                    "UPDATE tbl_stocks_out SET status = 'Completed' WHERE id = ? AND users_id = ?")) {
                pst.setInt(1, id);
                pst.setInt(2, UserSession.getUserId());
                if (pst.executeUpdate() == 1) {
                    ActivityLog.log("Sale restored: " + archiveModel.getValueAt(sel, 1));
                    JOptionPane.showMessageDialog(dialog, "Record restored.");
                    load.run();
                    loadStockOutRecords();
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog, ex.getMessage());
        }
    });

    closeBtn.addActionListener(e -> dialog.dispose());
    dialog.setVisible(true);
}

    
    private static final int DESIGN_WIDTH = 1100;
    private static final int DESIGN_HEIGHT = 652;
    
    private ResponsiveScaler responsiveScaler;

     private void setupResponsiveLayout() {
        setMinimumSize(new Dimension(DESIGN_WIDTH, DESIGN_HEIGHT));

        layoutAll(masterPanel);

        Container content = getContentPane();
        content.removeAll();
        content.setLayout(new java.awt.BorderLayout());
        content.add(masterPanel, java.awt.BorderLayout.CENTER);

       
        responsiveScaler = new ResponsiveScaler(
                masterPanel, DESIGN_WIDTH, DESIGN_HEIGHT);

        content.revalidate();
        content.repaint();
    }
     
     private static void layoutAll(Container container) {
        container.doLayout();

        for (Component component : container.getComponents()) {
            if (component instanceof Container) {
                layoutAll((Container) component);
            }
        }
    }
     
      private static final class ResponsiveScaler {

        private final JPanel root;
        private final int designWidth;
        private final int designHeight;

        private final Map<Component, java.awt.Rectangle> originalBounds =
                new IdentityHashMap<>();
        private final Map<JComponent, Font> originalFonts =
                new IdentityHashMap<>();
        private final Map<JComponent, Icon> originalIcons =
                new IdentityHashMap<>();

        ResponsiveScaler(JPanel root, int designWidth, int designHeight) {
            this.root = root;
            this.designWidth = designWidth;
            this.designHeight = designHeight;

            capture(root);
            update();
        }
        
         private void capture(Container parent) {
            for (Component component : parent.getComponents()) {
                originalBounds.put(
                        component,
                        new java.awt.Rectangle(component.getBounds()));

                if (component instanceof JComponent) {
                    JComponent jc = (JComponent) component;

                    if (jc.getFont() != null) {
                        originalFonts.put(jc, jc.getFont());
                    }

                    Icon icon = null;

                    if (jc instanceof javax.swing.JLabel) {
                        icon = ((javax.swing.JLabel) jc).getIcon();
                    } else if (jc instanceof AbstractButton) {
                        icon = ((AbstractButton) jc).getIcon();
                    }

                    if (icon != null) {
                        originalIcons.put(jc, icon);
                    }
                }
                
                
               
                if (component instanceof Container) {
                    Container child = (Container) component;
                    capture(child);
                    child.setLayout(null);
                }
            }
        }
         
         void update() {
            if (root.getWidth() <= 0 || root.getHeight() <= 0) {
                return;
            }

            double scaleX = root.getWidth() / (double) designWidth;
            double scaleY = root.getHeight() / (double) designHeight;

            
            double uniformScale = Math.min(scaleX, scaleY);

            for (Map.Entry<Component, java.awt.Rectangle> entry
                    : originalBounds.entrySet()) {

                Component component = entry.getKey();
                java.awt.Rectangle original = entry.getValue();

                int x = (int) Math.round(original.x * scaleX);
                int y = (int) Math.round(original.y * scaleY);
                int width = Math.max(
                        1, (int) Math.round(original.width * scaleX));
                int height;
                if (component instanceof javax.swing.JScrollPane) {
                    height = Math.max(1, (int) Math.round(original.height * uniformScale));
                } else {
                    height = Math.max(1, (int) Math.round(original.height * scaleY));
                }

                component.setBounds(x, y, width, height);
            }

            for (Map.Entry<JComponent, Font> entry
                    : originalFonts.entrySet()) {

                JComponent component = entry.getKey();
                Font original = entry.getValue();

                int size = Math.max(
                        8,
                        (int) Math.round(original.getSize2D() * uniformScale));

                component.setFont(original.deriveFont(
                        original.getStyle(), (float) size));
            }

            for (Map.Entry<JComponent, Icon> entry
                    : originalIcons.entrySet()) {

                JComponent component = entry.getKey();
                Icon originalIcon = entry.getValue();

                if (!(originalIcon instanceof ImageIcon)) {
                    continue;
                }

                ImageIcon imageIcon = (ImageIcon) originalIcon;
                Image image = imageIcon.getImage();

                int width = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconWidth() * scaleX));
                int height = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconHeight() * scaleY));

                Image scaledImage = image.getScaledInstance(
                        width, height, Image.SCALE_SMOOTH);

                ImageIcon scaledIcon = new ImageIcon(scaledImage);

                if (component instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) component).setIcon(scaledIcon);
                } else if (component instanceof AbstractButton) {
                    ((AbstractButton) component).setIcon(scaledIcon);
                }
            }

            root.revalidate();
            root.repaint();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        masterPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        dashboard = new javax.swing.JButton();
        manage = new javax.swing.JButton();
        view = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        stock = new javax.swing.JButton();
        stockout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        cmbDateSort = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        masterPanel.setPreferredSize(new java.awt.Dimension(0, 0));
        masterPanel.addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsListener() {
            public void ancestorMoved(java.awt.event.HierarchyEvent evt) {
            }
            public void ancestorResized(java.awt.event.HierarchyEvent evt) {
                masterPanelAncestorResized(evt);
            }
        });
        masterPanel.setLayout(null);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        jLabel2.setText("jLabel2");
        masterPanel.add(jLabel2);
        jLabel2.setBounds(0, 0, 380, 110);

        jPanel2.setBackground(new java.awt.Color(226, 136, 1));

        dashboard.setBackground(new java.awt.Color(255, 255, 51));
        dashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard.setForeground(new java.awt.Color(0, 0, 204));
        dashboard.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        dashboard.setText("Dashboard");
        dashboard.setFocusPainted(false);
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dashboard.addActionListener(this::dashboardActionPerformed);

        manage.setBackground(new java.awt.Color(255, 255, 51));
        manage.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        manage.setForeground(new java.awt.Color(0, 0, 204));
        manage.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        manage.setText("Manage Inventory  ");
        manage.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manage.addActionListener(this::manageActionPerformed);

        view.setBackground(new java.awt.Color(255, 255, 51));
        view.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 204));
        view.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        view.setText("SmartStock Report");
        view.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        view.addActionListener(this::viewActionPerformed);

        logout.setBackground(new java.awt.Color(255, 255, 51));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 0, 204));
        logout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (4).png")); // NOI18N
        logout.setText("Log Out");
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 268, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jLabel4.setBackground(new java.awt.Color(255, 153, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Main Menu");

        stock.setBackground(new java.awt.Color(255, 255, 51));
        stock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stock.setForeground(new java.awt.Color(0, 0, 204));
        stock.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        stock.setText("Stock In/Arrivals");
        stock.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stock.addActionListener(this::stockActionPerformed);

        stockout.setBackground(new java.awt.Color(255, 204, 51));
        stockout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockout.setForeground(new java.awt.Color(0, 0, 204));
        stockout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        stockout.setText("Stock Out/Sales");
        stockout.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        stockout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stockout.addActionListener(this::stockoutActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(manage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stockout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(58, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(121, 121, 121))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dashboard)
                .addGap(18, 18, 18)
                .addComponent(manage)
                .addGap(18, 18, 18)
                .addComponent(stock)
                .addGap(17, 17, 17)
                .addComponent(stockout)
                .addGap(18, 18, 18)
                .addComponent(view)
                .addGap(49, 49, 49)
                .addComponent(logout)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel2);
        jPanel2.setBounds(0, 111, 380, 540);

        jPanel3.setBackground(new java.awt.Color(9, 9, 89));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        jLabel3.setText("Stock Out/Sales");

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 391, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel3)))
                .addContainerGap(183, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel3);
        jPanel3.setBounds(376, 0, 730, 110);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton1.setBackground(new java.awt.Color(0, 51, 102));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("ⓘ Archive");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(0, 51, 102));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("✎ Edit");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 51, 102));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("✚ Record Sales");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 51, 102));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("↻ Refresh");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("🔍︎");

        jTextField1.setForeground(new java.awt.Color(51, 51, 51));
        jTextField1.setText(" Search Product");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(185, 185, 185))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton5)
                            .addComponent(jLabel7)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        masterPanel.add(jPanel1);
        jPanel1.setBounds(430, 190, 630, 40);

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        jLabel10.setBackground(new java.awt.Color(102, 102, 102));
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Category :");
        jLabel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel10.setOpaque(true);

        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Supplies", "Office", "Electronics", "Consumables", "Others" }));
        cmbCategory.addActionListener(this::cmbCategoryActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbCategory, 0, 78, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        masterPanel.add(jPanel10);
        jPanel10.setBounds(430, 240, 160, 30);

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        jLabel11.setBackground(new java.awt.Color(102, 102, 102));
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Date :");
        jLabel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel11.setOpaque(true);

        cmbDateSort.setForeground(new java.awt.Color(255, 255, 255));
        cmbDateSort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Newest First", "Oldest First", "All Dates" }));
        cmbDateSort.addActionListener(this::cmbDateSortActionPerformed);

        jLabel15.setBackground(new java.awt.Color(102, 102, 102));
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Status Category :");
        jLabel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel15.setOpaque(true);

        jComboBox1.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(69, Short.MAX_VALUE)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbDateSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbDateSort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4))
        );

        masterPanel.add(jPanel5);
        jPanel5.setBounds(600, 240, 460, 30);

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Quantity", "Price", "Date", "Recipient", "Status"
            }
        ));
        jTable1.setAutoscrolls(false);
        jTable1.setPreferredSize(new java.awt.Dimension(430, 280));
        jScrollPane1.setViewportView(jTable1);

        masterPanel.add(jScrollPane1);
        jScrollPane1.setBounds(430, 280, 630, 140);

        jPanel11.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel11);
        jPanel11.setBounds(380, 140, 280, 20);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel13);
        jPanel13.setBounds(380, 550, 340, 20);

        jPanel14.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel14);
        jPanel14.setBounds(380, 590, 610, 20);

        jPanel15.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1098, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel15);
        jPanel15.setBounds(680, 140, 1098, 20);

        jPanel16.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel16);
        jPanel16.setBounds(730, 550, 370, 20);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel18);
        jPanel18.setBounds(720, 400, 100, 20);

        jPanel12.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel12);
        jPanel12.setBounds(800, 140, 300, 20);

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel17);
        jPanel17.setBounds(1000, 590, 100, 20);

        jPanel22.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel22);
        jPanel22.setBounds(380, 20, 10, 630);

        jPanel21.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel21);
        jPanel21.setBounds(1090, 0, 10, 650);

        jPanel31.setBackground(new java.awt.Color(255, 255, 102));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Total Complete : ");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel13))
        );

        masterPanel.add(jPanel31);
        jPanel31.setBounds(650, 460, 210, 20);

        jPanel32.setBackground(new java.awt.Color(255, 255, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Total Transaction : ");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5))
        );

        masterPanel.add(jPanel32);
        jPanel32.setBounds(430, 460, 210, 20);

        jPanel33.setBackground(new java.awt.Color(255, 255, 102));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Total Items Sold : ");

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel33Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel8))
        );

        masterPanel.add(jPanel33);
        jPanel33.setBounds(430, 430, 210, 20);

        jPanel34.setBackground(new java.awt.Color(255, 255, 102));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Total Revenue : ");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel12))
        );

        masterPanel.add(jPanel34);
        jPanel34.setBounds(650, 430, 210, 20);

        jPanel35.setBackground(new java.awt.Color(255, 255, 102));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Total Cancelled : ");

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel14))
        );

        masterPanel.add(jPanel35);
        jPanel35.setBounds(870, 430, 210, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void openPage(JFrame nextPage) {

    java.awt.Rectangle currentBounds = this.getBounds();

    boolean maximized =
            (this.getExtendedState() & JFrame.MAXIMIZED_BOTH)
            == JFrame.MAXIMIZED_BOTH;

    nextPage.setVisible(true);

    if (maximized) {
        nextPage.setExtendedState(JFrame.MAXIMIZED_BOTH);
    } else {
        nextPage.setBounds(currentBounds);
    }

    this.dispose();
}
    
    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
       HomePage home = new HomePage();
       openPage(home);
    }//GEN-LAST:event_dashboardActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Log Out", javax.swing.JOptionPane.YES_NO_OPTION);
     
        if (choice == javax.swing.JOptionPane.YES_OPTION) {
              LoginPage loginForm = new LoginPage();
              loginForm.setVisible(true);
              this.dispose();
        } else {}
    }//GEN-LAST:event_logoutActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        ViewReportPage view = new ViewReportPage();
        openPage(view);
    }//GEN-LAST:event_viewActionPerformed

    private void manageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageActionPerformed
       ManagePage manage = new ManagePage();
       openPage(manage);
    }//GEN-LAST:event_manageActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       deleteStockOut();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       recordStockOut();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       loadStockOutRecords();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
       if (responsiveScaler != null) {
            responsiveScaler.update();
       }
    }//GEN-LAST:event_formComponentResized

    private void masterPanelAncestorResized(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_masterPanelAncestorResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_masterPanelAncestorResized

    private void stockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockActionPerformed
        StockinPage stockin = new StockinPage();
        openPage(stockin);
    }//GEN-LAST:event_stockActionPerformed

    private void stockoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockoutActionPerformed
       
    }//GEN-LAST:event_stockoutActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        editStockOut();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void cmbDateSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDateSortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbDateSortActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        loadStockOutRecords();
    }//GEN-LAST:event_cmbCategoryActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new StockoutPage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JComboBox<String> cmbDateSort;
    private javax.swing.JButton dashboard;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton logout;
    private javax.swing.JButton manage;
    private javax.swing.JPanel masterPanel;
    private javax.swing.JButton stock;
    private javax.swing.JButton stockout;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables
}
