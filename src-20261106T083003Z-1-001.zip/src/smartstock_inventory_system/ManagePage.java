/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;

import java.sql.*;
import java.awt.Color;
import java.text.SimpleDateFormat;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ManagePage extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ManagePage.class.getName());

    /**
     * Creates new form ManagePage
     */
    public ManagePage() {
        initComponents();
        setupResponsiveLayout();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"All", "Available", "Low", "Empty"}));
        jComboBox1.addActionListener(e -> jComboBox1ActionPerformed(e));
        cmbCategory.addActionListener(e -> cmbCategoryActionPerformed(e));
        
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{
        "Newest First", "Oldest First"
        }));
        jComboBox2.setSelectedItem("Newest First");
        jComboBox2.addActionListener(e -> jComboBox2ActionPerformed(e));

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"ID", "Product Name", "Category", "Product Value", "Stock", "Supplier", "Date", "Status", "DB_ID"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        jTable1.setModel(model);
        
        jTable1.getColumnModel().getColumn(8).setMinWidth(0);
        jTable1.getColumnModel().getColumn(8).setMaxWidth(0);
        jTable1.getColumnModel().getColumn(8).setPreferredWidth(0);
        
        jTable1.getColumnModel()
        .getColumn(6)
        .setPreferredWidth(135);

        jTable1.getColumnModel()
        .getColumn(6)
        .setMinWidth(135);
        
        jTable1.getColumnModel()
        .getColumn(7)
        .setPreferredWidth(70);

        jTable1.getColumnModel()
        .getColumn(7)
        .setMinWidth(70);
        
        jTable1.getColumnModel()
        .getColumn(1)
        .setPreferredWidth(90);

        jTable1.getColumnModel()
        .getColumn(1)
        .setMinWidth(90);
        
        jTable1.getColumnModel()
        .getColumn(3)
        .setPreferredWidth(90);

        jTable1.getColumnModel()
        .getColumn(3)
        .setMinWidth(90);
        
        jTable1.getTableHeader().setReorderingAllowed(false);

        setupStatusColors();

        loadCategories();
        cmbCategory.setSelectedItem("All");
        loadProducts();

    }
    
    private String formatDate(java.sql.Timestamp timestamp) {
    if (timestamp == null) {
        return "";
    }

    SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy hh:mm a");
    return sdf.format(timestamp);
}

    private void setupStatusColors() {
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected,
                    boolean hasFocus, int row, int column) {

                Component component
                        = super.getTableCellRendererComponent(
                                table, value, isSelected, hasFocus, row, column);

                String status = value == null
                        ? ""
                        : value.toString();

                if (isSelected) {
                    return component;
                }

                switch (status) {
                    case "Empty":
                        component.setForeground(new Color(190, 35, 35));
                        component.setBackground(new Color(255, 225, 225));
                        break;

                    case "Low":
                        component.setForeground(new Color(160, 110, 0));
                        component.setBackground(new Color(255, 245, 190));
                        break;

                    case "Available":
                        component.setForeground(new Color(20, 125, 65));
                        component.setBackground(new Color(215, 245, 225));
                        break;

                    default:
                        component.setForeground(table.getForeground());
                        component.setBackground(table.getBackground());
                        break;
                }

                component.setFont(
                        component.getFont().deriveFont(java.awt.Font.BOLD));

                return component;
            }
        };

        jTable1.getColumnModel()
                .getColumn(7)
                .setCellRenderer(renderer);
    }

     private void loadProducts() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
 
        String dateOrder = "Newest First".equals(String.valueOf(jComboBox2.getSelectedItem()))
                ? "DESC" : "ASC";
        String keyword = jTextField1.getText().trim();
        if (keyword.equalsIgnoreCase("Search Product")) {
            keyword = "";
        }
        String category = String.valueOf(cmbCategory.getSelectedItem());
        boolean byCategory = !category.equals("null") && !category.equals("All");
        String status = String.valueOf(jComboBox1.getSelectedItem());
 
        StringBuilder sql = new StringBuilder(
                "SELECT id, product_name, category, price, supplier, stock, date_added "
                + "FROM tbl_products WHERE users_id = ?");
        if (!keyword.isEmpty()) {
            sql.append(" AND product_name LIKE ?");
        }
        if (byCategory) {
            sql.append(" AND category = ?");
        }
        if ("Empty".equals(status)) {
            sql.append(" AND stock = 0");
        } else if ("Low".equals(status)) {
            sql.append(" AND stock > 0 AND stock <= 10");
        } else if ("Available".equals(status)) {
            sql.append(" AND stock > 10");
        }
        sql.append(" ORDER BY date_added ").append(dateOrder).append(", id ").append(dateOrder);
 
        try (Connection con = DBConnection.connect()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Cannot connect to the database.");
                return;
            }
            try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
                int p = 1;
                pst.setInt(p++, UserSession.getUserId());
                if (!keyword.isEmpty()) {
                    pst.setString(p++, "%" + keyword + "%");
                }
                if (byCategory) {
                    pst.setString(p++, category);
                }
                try (ResultSet rs = pst.executeQuery()) {
                    int rowNumber = 1;
                    while (rs.next()) {
                        int stock = rs.getInt("stock");
                        String rowStatus;
                        if (stock == 0) {
                            rowStatus = "Empty";
                        } else if (stock <= 10) {
                            rowStatus = "Low";
                        } else {
                            rowStatus = "Available";
                        }
                        model.addRow(new Object[]{
                            rowNumber++,
                            rs.getString("product_name"),
                            rs.getString("category"),
                            "₱" + String.format(java.util.Locale.US, "%.2f", rs.getDouble("price")),
                            stock,
                            rs.getString("supplier"),
                            formatDate(rs.getTimestamp("date_added")),
                            rowStatus,
                            rs.getInt("id")
                        });
                    }
                }
            }
            updateSummary();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Unable to load products: " + e.getMessage());
        }
    }

   private void loadCategories() {
        cmbCategory.removeAllItems();
        cmbCategory.addItem("All");
        try (Connection con = DBConnection.connect()) {
            if (con == null) {
                return;
            }
            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT DISTINCT category FROM tbl_products WHERE users_id = ? ORDER BY category")) {
                pst.setInt(1, UserSession.getUserId());
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        cmbCategory.addItem(rs.getString("category"));
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Unable to load categories: " + e.getMessage());
        }
    }

    
private void updateSummary() {
    int totalProducts = jTable1.getRowCount();
    int totalAvailable = 0;
    int totalLow = 0;
    int totalEmpty = 0;

    java.math.BigDecimal totalProductPrice
            = java.math.BigDecimal.ZERO;

    java.util.Set<String> categories
            = new java.util.HashSet<>();

    for (int i = 0; i < totalProducts; i++) {
        String category
                = jTable1.getValueAt(i, 2).toString();

        String status
                = jTable1.getValueAt(i, 7).toString();

        
        String priceText
                = jTable1.getValueAt(i, 3).toString()
                        .replace("₱", "")
                        .replace(",", "")
                        .trim();

        java.math.BigDecimal price
                = new java.math.BigDecimal(priceText);

        
        int stock
                = Integer.parseInt(
                        jTable1.getValueAt(i, 4).toString());

        categories.add(category);

       
        java.math.BigDecimal productTotal
                = price.multiply(
                        java.math.BigDecimal.valueOf(stock));

        totalProductPrice
                = totalProductPrice.add(productTotal);

        switch (status) {
            case "Available":
                totalAvailable++;
                break;

            case "Low":
                totalLow++;
                break;

            case "Empty":
                totalEmpty++;
                break;
        }
    }

    jLabel5.setText("Total Products : " + totalProducts);
    jLabel4.setText("Total Types : " + categories.size());
    jLabel8.setText("Total Available Products : " + totalAvailable);
    jLabel10.setText("Total Low Products : " + totalLow);
    jLabel11.setText("Total Empty Products : " + totalEmpty);

    jLabel13.setText(
            "Total Inventory Value : ₱"
            + totalProductPrice.setScale(
                    2, java.math.RoundingMode.HALF_UP)
                    .toPlainString());
}


    private static final int DESIGN_WIDTH = 1100;
    private static final int DESIGN_HEIGHT = 652;

    private ResponsiveScaler responsiveScaler;

    private void setupResponsiveLayout() {
        setMinimumSize(new Dimension(DESIGN_WIDTH, DESIGN_HEIGHT));

        layoutAll(masterPanel);

        Container content = getContentPane();
        content.removeAll();
        content.setLayout(new java.awt.BorderLayout());
        content.add(masterPanel, java.awt.BorderLayout.CENTER);

        responsiveScaler = new ResponsiveScaler(
                masterPanel, DESIGN_WIDTH, DESIGN_HEIGHT);

        content.revalidate();
        content.repaint();
    }

    private static void layoutAll(Container container) {
        container.doLayout();

        for (Component component : container.getComponents()) {
            if (component instanceof Container) {
                layoutAll((Container) component);
            }
        }
    }

    private static final class ResponsiveScaler {

        private final JPanel root;
        private final int designWidth;
        private final int designHeight;

        private final Map<Component, java.awt.Rectangle> originalBounds
                = new IdentityHashMap<>();
        private final Map<JComponent, Font> originalFonts
                = new IdentityHashMap<>();
        private final Map<JComponent, Icon> originalIcons
                = new IdentityHashMap<>();

        ResponsiveScaler(JPanel root, int designWidth, int designHeight) {
            this.root = root;
            this.designWidth = designWidth;
            this.designHeight = designHeight;

            capture(root);
            update();
        }

        private void capture(Container parent) {
            for (Component component : parent.getComponents()) {
                originalBounds.put(
                        component,
                        new java.awt.Rectangle(component.getBounds()));

                if (component instanceof JComponent) {
                    JComponent jc = (JComponent) component;

                    if (jc.getFont() != null) {
                        originalFonts.put(jc, jc.getFont());
                    }

                    Icon icon = null;

                    if (jc instanceof javax.swing.JLabel) {
                        icon = ((javax.swing.JLabel) jc).getIcon();
                    } else if (jc instanceof AbstractButton) {
                        icon = ((AbstractButton) jc).getIcon();
                    }

                    if (icon != null) {
                        originalIcons.put(jc, icon);
                    }
                }

                if (component instanceof Container) {
                    Container child = (Container) component;
                    capture(child);
                    child.setLayout(null);
                }
            }
        }

        void update() {
            if (root.getWidth() <= 0 || root.getHeight() <= 0) {
                return;
            }

            double scaleX = root.getWidth() / (double) designWidth;
            double scaleY = root.getHeight() / (double) designHeight;

            double uniformScale = Math.min(scaleX, scaleY);

            for (Map.Entry<Component, java.awt.Rectangle> entry
                    : originalBounds.entrySet()) {

                Component component = entry.getKey();
                java.awt.Rectangle original = entry.getValue();

                int x = (int) Math.round(original.x * scaleX);
                int y = (int) Math.round(original.y * scaleY);
                int width = Math.max(
                        1, (int) Math.round(original.width * scaleX));
                int height = Math.max(
                        1, (int) Math.round(original.height * scaleY));

                component.setBounds(x, y, width, height);
            }

            for (Map.Entry<JComponent, Font> entry
                    : originalFonts.entrySet()) {

                JComponent component = entry.getKey();
                Font original = entry.getValue();

                int size = Math.max(
                        8,
                        (int) Math.round(original.getSize2D() * uniformScale));

                component.setFont(original.deriveFont(
                        original.getStyle(), (float) size));
            }

            for (Map.Entry<JComponent, Icon> entry
                    : originalIcons.entrySet()) {

                JComponent component = entry.getKey();
                Icon originalIcon = entry.getValue();

                if (!(originalIcon instanceof ImageIcon)) {
                    continue;
                }

                ImageIcon imageIcon = (ImageIcon) originalIcon;
                Image image = imageIcon.getImage();

                int width = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconWidth() * scaleX));
                int height = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconHeight() * scaleY));

                Image scaledImage = image.getScaledInstance(
                        width, height, Image.SCALE_SMOOTH);

                ImageIcon scaledIcon = new ImageIcon(scaledImage);

                if (component instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) component).setIcon(scaledIcon);
                } else if (component instanceof AbstractButton) {
                    ((AbstractButton) component).setIcon(scaledIcon);
                }
            }

            root.revalidate();
            root.repaint();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        masterPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        dashboard = new javax.swing.JButton();
        manage = new javax.swing.JButton();
        stock = new javax.swing.JButton();
        stockout = new javax.swing.JButton();
        view = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        jPanel5 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        icon = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1101, 631));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        masterPanel.setPreferredSize(new java.awt.Dimension(0, 0));
        masterPanel.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                masterPanelComponentResized(evt);
            }
        });
        masterPanel.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(226, 136, 1));

        dashboard.setBackground(new java.awt.Color(255, 255, 51));
        dashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard.setForeground(new java.awt.Color(0, 0, 204));
        dashboard.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        dashboard.setText("Dashboard           ");
        dashboard.setFocusPainted(false);
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dashboard.addActionListener(this::dashboardActionPerformed);

        manage.setBackground(new java.awt.Color(255, 204, 51));
        manage.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        manage.setForeground(new java.awt.Color(0, 0, 204));
        manage.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        manage.setText("Manage Inventory");
        manage.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        manage.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manage.addActionListener(this::manageActionPerformed);

        stock.setBackground(new java.awt.Color(255, 255, 51));
        stock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stock.setForeground(new java.awt.Color(0, 0, 204));
        stock.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        stock.setText("Stock In/Arrivals");
        stock.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stock.addActionListener(this::stockActionPerformed);

        stockout.setBackground(new java.awt.Color(255, 255, 51));
        stockout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockout.setForeground(new java.awt.Color(0, 0, 204));
        stockout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        stockout.setText("Stock Out/Sales");
        stockout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stockout.addActionListener(this::stockoutActionPerformed);

        view.setBackground(new java.awt.Color(255, 255, 51));
        view.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 204));
        view.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        view.setText("SmartStock Reports");
        view.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        view.addActionListener(this::viewActionPerformed);

        logout.setBackground(new java.awt.Color(255, 255, 51));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 0, 204));
        logout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (4).png")); // NOI18N
        logout.setText("Log Out");
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        jLabel9.setBackground(new java.awt.Color(255, 179, 0));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Main Menu");
        jLabel9.setOpaque(true);

        jPanel20.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 268, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(manage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stockout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel9))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dashboard)
                .addGap(18, 18, 18)
                .addComponent(manage)
                .addGap(12, 12, 12)
                .addComponent(stock)
                .addGap(18, 18, 18)
                .addComponent(stockout)
                .addGap(18, 18, 18)
                .addComponent(view)
                .addGap(46, 46, 46)
                .addComponent(logout)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel2);
        jPanel2.setBounds(0, 111, 380, 540);

        jPanel3.setBackground(new java.awt.Color(9, 9, 89));
        jPanel3.setPreferredSize(new java.awt.Dimension(730, 106));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        jLabel3.setText("Manage Inventory");

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 363, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(191, 191, 191)
                .addComponent(jLabel3)
                .addContainerGap(187, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel3);
        jPanel3.setBounds(376, 0, 730, 110);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setForeground(new java.awt.Color(153, 153, 153));

        jTextField1.setForeground(new java.awt.Color(51, 51, 51));
        jTextField1.setText(" Search Product");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("🔍︎");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton2.setBackground(new java.awt.Color(0, 51, 102));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("✎ Edit");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 51, 102));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("✚ Add");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 51, 102));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("↻ Refresh");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 146, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(27, 27, 27)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7))
                            .addComponent(jButton2)
                            .addComponent(jButton3)
                            .addComponent(jButton5))
                        .addGap(0, 5, Short.MAX_VALUE)))
                .addContainerGap())
        );

        masterPanel.add(jPanel1);
        jPanel1.setBounds(430, 190, 630, 40);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel7);
        jPanel7.setBounds(0, 0, 10, 0);

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        jLabel2.setBackground(new java.awt.Color(102, 102, 102));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Category :");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel2.setOpaque(true);

        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Supplies", "Office", "Electronics", "Consumables" }));
        cmbCategory.addActionListener(this::cmbCategoryActionPerformed);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbCategory, 0, 84, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        masterPanel.add(jPanel10);
        jPanel10.setBounds(430, 240, 160, 34);

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        jLabel12.setBackground(new java.awt.Color(102, 102, 102));
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Status Category :");
        jLabel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel12.setOpaque(true);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        jLabel14.setBackground(new java.awt.Color(102, 102, 102));
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Date :");
        jLabel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel14.setOpaque(true);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Newest First", "Item 2", "Item 3", "Item 4" }));
        jComboBox2.addActionListener(this::jComboBox2ActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(88, Short.MAX_VALUE)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        masterPanel.add(jPanel5);
        jPanel5.setBounds(600, 240, 460, 30);

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Category", "Product Price", "Stock", "Supplier", "Date", "Status", "Database ID"
            }
        ));
        jTable1.setPreferredSize(new java.awt.Dimension(430, 280));
        jScrollPane1.setViewportView(jTable1);

        masterPanel.add(jScrollPane1);
        jScrollPane1.setBounds(430, 280, 630, 140);

        jPanel11.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel11);
        jPanel11.setBounds(380, 140, 280, 20);

        jPanel12.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel12);
        jPanel12.setBounds(800, 140, 300, 20);

        jPanel15.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel15);
        jPanel15.setBounds(680, 140, 100, 20);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel18);
        jPanel18.setBounds(720, 400, 100, 20);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel13);
        jPanel13.setBounds(380, 550, 340, 20);

        jPanel14.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel14);
        jPanel14.setBounds(380, 590, 610, 20);

        jPanel16.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel16);
        jPanel16.setBounds(730, 550, 370, 20);

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel17);
        jPanel17.setBounds(1000, 590, 100, 20);

        jPanel21.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel21);
        jPanel21.setBounds(1090, 20, 10, 630);

        jPanel23.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel23);
        jPanel23.setBounds(380, 20, 10, 630);

        icon.setBackground(new java.awt.Color(9, 9, 89));
        icon.setForeground(new java.awt.Color(0, 0, 102));
        icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        icon.setText("jLabel2");
        icon.setFocusTraversalPolicyProvider(true);
        icon.setOpaque(true);

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 379, Short.MAX_VALUE)
            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 116, Short.MAX_VALUE)
            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel22Layout.createSequentialGroup()
                    .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        masterPanel.add(jPanel22);
        jPanel22.setBounds(0, 0, 379, 110);

        jPanel19.setBackground(new java.awt.Color(255, 255, 102));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Total Available Products : 0");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addContainerGap())
        );

        masterPanel.add(jPanel19);
        jPanel19.setBounds(580, 470, 230, 30);

        jPanel24.setBackground(new java.awt.Color(255, 255, 102));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Total Products : 0");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel24);
        jPanel24.setBounds(430, 430, 140, 30);

        jPanel25.setBackground(new java.awt.Color(255, 255, 102));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Total Low Products : 0");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        masterPanel.add(jPanel25);
        jPanel25.setBounds(820, 470, 210, 30);

        jPanel26.setBackground(new java.awt.Color(255, 255, 102));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Total Types : 0");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
        );

        masterPanel.add(jPanel26);
        jPanel26.setBounds(430, 470, 140, 30);

        jPanel27.setBackground(new java.awt.Color(255, 255, 102));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("Total Empty Products : 0");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel27);
        jPanel27.setBounds(820, 430, 210, 30);

        jPanel28.setBackground(new java.awt.Color(255, 255, 102));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Total Inventory Value : 0");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addContainerGap())
        );

        masterPanel.add(jPanel28);
        jPanel28.setBounds(580, 430, 230, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void openPage(JFrame nextPage) {

        java.awt.Rectangle currentBounds = this.getBounds();

        boolean maximized
                = (this.getExtendedState() & JFrame.MAXIMIZED_BOTH)
                == JFrame.MAXIMIZED_BOTH;

        nextPage.setVisible(true);

        if (maximized) {
            nextPage.setExtendedState(JFrame.MAXIMIZED_BOTH);
        } else {
            nextPage.setBounds(currentBounds);
        }

        this.dispose();
    }

    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
        HomePage home = new HomePage();
        openPage(home);
    }//GEN-LAST:event_dashboardActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Log Out", javax.swing.JOptionPane.YES_NO_OPTION);

        if (choice == javax.swing.JOptionPane.YES_OPTION) {
            UserSession.clearSession();
            LoginPage loginForm = new LoginPage();
            loginForm.setVisible(true);
            this.dispose();
        } else {
        }
    }//GEN-LAST:event_logoutActionPerformed

    private void manageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageActionPerformed

    }//GEN-LAST:event_manageActionPerformed

    private void stockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockActionPerformed
        StockinPage stockin = new StockinPage();
        openPage(stockin);
    }//GEN-LAST:event_stockActionPerformed

    private void stockoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockoutActionPerformed
        StockoutPage stockout = new StockoutPage();
        openPage(stockout);
    }//GEN-LAST:event_stockoutActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        ViewReportPage view = new ViewReportPage();
        openPage(view);
    }//GEN-LAST:event_viewActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
   
    JTextField nameField = new JTextField();
    JComboBox<String> categoryBox = new JComboBox<>(
            new String[]{"Supplies", "Office", "Electronics",
                "Consumables", "Others"});
    JTextField priceField = new JTextField();
    JTextField stockField = new JTextField();
    JTextField supplierField = new JTextField();

    JPanel panel = new JPanel(new java.awt.GridLayout(0, 2, 5, 5));

    panel.add(new JLabel("Product Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Category:"));
    panel.add(categoryBox);
    panel.add(new JLabel("Product Price (₱):"));
    panel.add(priceField);
    panel.add(new JLabel("Stock Quantity:"));
    panel.add(stockField);
    panel.add(new JLabel("Supplier:"));
    panel.add(supplierField);

    int result = JOptionPane.showConfirmDialog(
            this, panel, "Add New Product",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE);

    if (result != JOptionPane.OK_OPTION) {
        return;
    }

    String name = nameField.getText().trim();
    String category = (String) categoryBox.getSelectedItem();
    String supplier = supplierField.getText().trim();

    if (name.isEmpty() || priceField.getText().trim().isEmpty()
            || stockField.getText().trim().isEmpty() || supplierField.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
        return;
    }

    try {
        java.math.BigDecimal price =
                new java.math.BigDecimal(priceField.getText().trim());
        int stock = Integer.parseInt(stockField.getText().trim());

        if (price.compareTo(java.math.BigDecimal.ZERO) < 0 || stock < 0) {
            JOptionPane.showMessageDialog(
                    this, "Price and stock cannot be negative.");
            return;
        }

        String status;
        if (stock == 0) {
            status = "Empty";
        } else if (stock <= 10) {
            status = "Low";
        } else {
            status = "Available";
        }

        String sql = "INSERT INTO tbl_products "
                + "(users_id, product_name, category, price, stock, supplier, status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.connect()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(
                        this, "Cannot connect to the database.");
                return;
            }

            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setInt(1, UserSession.getUserId());
                pst.setString(2, name);
                pst.setString(3, category);
                pst.setBigDecimal(4, price);
                pst.setInt(5, stock);
                pst.setString(6, supplier);
                pst.setString(7, status);

                pst.executeUpdate();
            }
        }

        ActivityLog.log("Product added: " + name);
        JOptionPane.showMessageDialog(this, "Product added successfully!");
        loadProducts();

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
                this, "Enter a valid price and whole-number stock quantity.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Error adding product: " + e.getMessage());
    }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jTextField1.setText("");
        loadProducts();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_formComponentResized

    private void masterPanelComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_masterPanelComponentResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_masterPanelComponentResized

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    int selectedRow = jTable1.getSelectedRow();

    if (selectedRow == -1) {
    JOptionPane.showMessageDialog(
            this, "Please select a product from the table first.");
    return;
    }

    int row = jTable1.convertRowIndexToModel(selectedRow);
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();


    int id = Integer.parseInt(model.getValueAt(row, 8).toString());

    JTextField nameField = new JTextField(
        model.getValueAt(row, 1).toString());

    JComboBox<String> categoryBox = new JComboBox<>(
        new String[]{"Supplies", "Office", "Electronics",
            "Consumables", "Others"});
    categoryBox.setSelectedItem(model.getValueAt(row, 2).toString());

    JTextField priceField = new JTextField(
        model.getValueAt(row, 3).toString().replace("₱", "").trim());

    JTextField stockField = new JTextField(
        model.getValueAt(row, 4).toString());
  
    JTextField supplierField = new JTextField(
        model.getValueAt(row, 5) == null
                ? "" : model.getValueAt(row, 5).toString());

    JPanel panel = new JPanel(new java.awt.GridLayout(0, 2, 5, 5));

    panel.add(new JLabel("Product Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Category:"));
    panel.add(categoryBox);
    panel.add(new JLabel("Price (₱):"));
    panel.add(priceField);
    panel.add(new JLabel("Stock Quantity:"));
    panel.add(stockField);
    panel.add(new JLabel("Supplier:"));
    panel.add(supplierField);

int result = JOptionPane.showConfirmDialog(
        this, panel, "Edit Product",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.PLAIN_MESSAGE);

if (result != JOptionPane.OK_OPTION) {
    return;
}

String name = nameField.getText().trim();
String category = (String) categoryBox.getSelectedItem();
String supplier = supplierField.getText().trim();

if (name.isEmpty()
        || priceField.getText().trim().isEmpty()
        || stockField.getText().trim().isEmpty()) {
    JOptionPane.showMessageDialog(
            this, "Please fill in all required fields.");
    return;
}

try {
    java.math.BigDecimal price =
            new java.math.BigDecimal(priceField.getText().trim());

    int stock = Integer.parseInt(stockField.getText().trim());

    if (price.compareTo(java.math.BigDecimal.ZERO) < 0 || stock < 0) {
        JOptionPane.showMessageDialog(
                this, "Price and stock cannot be negative.");
        return;
    }

    String status;

    if (stock == 0) {
        status = "Empty";
    } else if (stock <= 10) {
        status = "Low";
    } else {
        status = "Available";
    }

    String sql = "UPDATE tbl_products SET "
            + "product_name = ?, category = ?, price = ?, "
            + "stock = ?, supplier = ?, status = ?, "
            + "date_added = CURRENT_TIMESTAMP "
            + "WHERE id = ? AND users_id = ?";

    try (Connection conn = DBConnection.connect()) {
        if (conn == null) {
            JOptionPane.showMessageDialog(
                    this, "Cannot connect to the database.");
            return;
        }

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, name);
            pst.setString(2, category);
            pst.setBigDecimal(3, price);
            pst.setInt(4, stock);
            pst.setString(5, supplier);
            pst.setString(6, status);
            pst.setInt(7, id);
            pst.setInt(8, UserSession.getUserId());

            int updated = pst.executeUpdate();

            if (updated == 0) {
                JOptionPane.showMessageDialog(
                        this, "Product not found or you cannot edit it.");
                return;
            }
        }
    }

    ActivityLog.log("Product edited: " + name);
    JOptionPane.showMessageDialog(
            this, "Product updated successfully!");

    
    loadProducts();

} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(
            this, "Enter a valid price and whole-number stock quantity.");
} catch (SQLException e) {
    JOptionPane.showMessageDialog(
            this, "Error updating product: " + e.getMessage());
}
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
     String key = jTextField1.getText().trim();

    if (key.equalsIgnoreCase("Search Product") || key.isEmpty()) {
        loadProducts();
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    String sql = "SELECT id, product_name, category, price, stock, supplier, date_added "
            + "FROM tbl_products "
            + "WHERE users_id = ? AND product_name LIKE ? "
            + "ORDER BY product_name";

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(
                    this, "Cannot connect to the database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, UserSession.getUserId());
            pst.setString(2, "%" + key + "%");

            try (ResultSet rs = pst.executeQuery()) {
                int rowNumber = 1;

                while (rs.next()) {
                    int stock = rs.getInt("stock");

                    String status;
                    if (stock == 0) {
                        status = "Empty";
                    } else if (stock <= 10) {
                        status = "Low";
                    } else {
                        status = "Available";
                    }

                    model.addRow(new Object[]{
                        rowNumber++,
                        rs.getString("product_name"),
                        rs.getString("category"),
                        "₱" + String.format(
                        java.util.Locale.US, "%.2f",
                        rs.getDouble("price")),
                        stock,
                        rs.getString("supplier"),
                        formatDate(rs.getTimestamp("date_added")),
                        status,
                        rs.getInt("id")
                    });
                }
            }
        }
        loadProducts();
        updateSummary();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Search error: " + e.getMessage());
    }
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
    String cat = String.valueOf(cmbCategory.getSelectedItem());

    if (cat == null || cat.equals("All")) {
        loadProducts();
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    String dateOrder = "Newest First".equals(String.valueOf(jComboBox2.getSelectedItem()))
        ? "DESC" : "ASC";

    String sql = "SELECT id, product_name, category, price, stock, supplier, date_added "
        + "FROM tbl_products "
        + "WHERE users_id = ? AND category = ? "
        + "ORDER BY date_added " + dateOrder + ", id " + dateOrder;

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(
                    this, "Cannot connect to the database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, UserSession.getUserId());
            pst.setString(2, cat);

            try (ResultSet rs = pst.executeQuery()) {
                int rowNumber = 1;

                while (rs.next()) {
                    int stock = rs.getInt("stock");

                    String status;
                    if (stock == 0) {
                        status = "Empty";
                    } else if (stock <= 10) {
                        status = "Low";
                    } else {
                        status = "Available";
                    }

                    model.addRow(new Object[]{
                        rowNumber++,
                        rs.getString("product_name"),
                        rs.getString("category"),
                        "₱" + String.format(
                        java.util.Locale.US, "%.2f",
                        rs.getDouble("price")),
                        stock,
                        rs.getString("supplier"),
                        formatDate(rs.getTimestamp("date_added")),
                        status,
                        rs.getInt("id")
                    });
                }
            }
        }
        loadProducts();
        updateSummary();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Category filter error: " + e.getMessage());
    }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
    String selectedStatus = String.valueOf(jComboBox1.getSelectedItem());
    String selectedCategory = String.valueOf(cmbCategory.getSelectedItem());

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    StringBuilder sql = new StringBuilder(
            "SELECT id, product_name, category, price, stock, supplier, date_added "
            + "FROM tbl_products WHERE users_id = ?");

    if (selectedCategory != null && !selectedCategory.equals("All")) {
        sql.append(" AND category = ?");
    }

    if ("Empty".equals(selectedStatus)) {
        sql.append(" AND stock = 0");
    } else if ("Low".equals(selectedStatus)) {
        sql.append(" AND stock > 0 AND stock <= 10");
    } else if ("Available".equals(selectedStatus)) {
        sql.append(" AND stock > 10");
    }

    String dateOrder = "Newest First".equals(String.valueOf(jComboBox2.getSelectedItem()))
        ? "DESC" : "ASC";
    sql.append(" ORDER BY date_added ").append(dateOrder).append(", id ").append(dateOrder);

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            JOptionPane.showMessageDialog(
                    this, "Cannot connect to the database.");
            return;
        }

        try (PreparedStatement pst = con.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            pst.setInt(paramIndex++, UserSession.getUserId());

            if (selectedCategory != null && !selectedCategory.equals("All")) {
                pst.setString(paramIndex++, selectedCategory);
            }

            try (ResultSet rs = pst.executeQuery()) {
                int rowNumber = 1;

                while (rs.next()) {
                    int stock = rs.getInt("stock");

                    String status;
                    if (stock == 0) {
                        status = "Empty";
                    } else if (stock <= 10) {
                        status = "Low";
                    } else {
                        status = "Available";
                    }

                    model.addRow(new Object[]{
                        rowNumber++,
                        rs.getString("product_name"),
                        rs.getString("category"),
                        "₱" + String.format(
                        java.util.Locale.US, "%.2f",
                        rs.getDouble("price")),
                        stock,
                        rs.getString("supplier"),
                        formatDate(rs.getTimestamp("date_added")),
                        status,
                        rs.getInt("id")
                    });
                }
            }
        }
        loadProducts();
        updateSummary();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this, "Status filter error: " + e.getMessage());
    }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
     String selectedStatus = String.valueOf(jComboBox1.getSelectedItem());
    String selectedCategory = String.valueOf(cmbCategory.getSelectedItem());

    if ((selectedCategory == null || selectedCategory.equals("All"))
            && (selectedStatus == null || selectedStatus.equals("All"))) {
        loadProducts();
    } else {
        // Re-run the status filter (it already respects category + date order)
        jComboBox1ActionPerformed(evt);
    }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ManagePage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JButton dashboard;
    private javax.swing.JLabel icon;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton logout;
    private javax.swing.JButton manage;
    private javax.swing.JPanel masterPanel;
    private javax.swing.JButton stock;
    private javax.swing.JButton stockout;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables
}
