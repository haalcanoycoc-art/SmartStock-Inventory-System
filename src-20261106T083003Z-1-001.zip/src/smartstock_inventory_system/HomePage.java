/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package smartstock_inventory_system;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.util.IdentityHashMap;
import java.util.Map;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class HomePage extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(HomePage.class.getName());

    /**
     * Creates new form HomePage
     */
    public HomePage() {
        initComponents();
        setupResponsiveLayout();
        loadDashboard();
    }
    
   
     private void loadDashboard() {
    int userId = UserSession.getUserId();
    if (userId <= 0) {
        return;
    }

    try (Connection con = DBConnection.connect()) {
        if (con == null) {
            return;
        }

        
        int totalProducts = 0;
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT COUNT(*) FROM tbl_products WHERE users_id = ?")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) totalProducts = rs.getInt(1);
            }
        }
        jLabel6.setText(String.valueOf(totalProducts));

        int totalSales = 0;
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT COALESCE(SUM(quantity), 0) FROM tbl_stocks_out " +
                "WHERE users_id = ? AND status = 'Completed'")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) totalSales = rs.getInt(1);
            }
        }
        jLabel7.setText(String.valueOf(totalSales));

        double revenue = 0;
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT COALESCE(SUM(total_amount), 0) FROM tbl_stocks_out " +
                "WHERE users_id = ? AND status = 'Completed'")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) revenue = rs.getDouble(1);
            }
        }
        jLabel8.setText(String.format("%,.0f", revenue));

        String line1 = "- No low stock items.";
        String line2 = "- No recent activity.";
        String line3 = " ";

        
        try (PreparedStatement pst = con.prepareStatement(
                "SELECT product_name, stock FROM tbl_products " +
                "WHERE users_id = ? AND stock <= 10 " +
                "ORDER BY stock ASC LIMIT 1")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    int stock = rs.getInt("stock");
                    String name = rs.getString("product_name");
                    if (stock == 0) {
                        line1 = "- Low Stock Alert: \"" + name + "\" is Empty (0 left).";
                    } else {
                        line1 = "- Low Stock Alert: \"" + name + "\" is Low (" + stock + " left).";
                    }
                }
            }
        }

        
        ActivityLog.ensureTable(con);

        try (PreparedStatement pst = con.prepareStatement(
                "SELECT activity, created_at FROM tbl_activity_log " +
                "WHERE users_id = ? ORDER BY created_at DESC, id DESC LIMIT 2")) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                int n = 0;
                while (rs.next()) {
                    java.sql.Timestamp ts = rs.getTimestamp("created_at");
                    String when = ts == null ? "" : " ("
                            + ts.toLocalDateTime().format(
                                    java.time.format.DateTimeFormatter.ofPattern(
                                            "MMM d, h:mm a", java.util.Locale.US))
                            + ")";
                    String text = "- " + rs.getString("activity") + when;

                    if (n == 0) {
                        line2 = text;
                    } else {
                        line3 = text;
                    }
                    n++;
                }
            }
        }

        jLabel10.setText(line1);
        jLabel14.setText(line2);
        jLabel15.setText(line3);

        jButton3.setText("Alerts / Recent Activity");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Unable to load dashboard: " + e.getMessage());
    }
}

    private static final int DESIGN_WIDTH = 1100;
    private static final int DESIGN_HEIGHT = 652;

    private ResponsiveScaler responsiveScaler;

    private void setupResponsiveLayout() {
        setMinimumSize(new Dimension(DESIGN_WIDTH, DESIGN_HEIGHT));

       
        layoutAll(masterPanel);

       
        Container content = getContentPane();
        content.removeAll();
        content.setLayout(new java.awt.BorderLayout());
        content.add(masterPanel, java.awt.BorderLayout.CENTER);

       
        responsiveScaler = new ResponsiveScaler(
                masterPanel, DESIGN_WIDTH, DESIGN_HEIGHT);

        content.revalidate();
        content.repaint();
    }
    
      private static void layoutAll(Container container) {
        container.doLayout();

        for (Component component : container.getComponents()) {
            if (component instanceof Container) {
                layoutAll((Container) component);
            }
        }
    }
      
      private static final class ResponsiveScaler {

        private final JPanel root;
        private final int designWidth;
        private final int designHeight;

        private final Map<Component, java.awt.Rectangle> originalBounds =
                new IdentityHashMap<>();
        private final Map<JComponent, Font> originalFonts =
                new IdentityHashMap<>();
        private final Map<JComponent, Icon> originalIcons =
                new IdentityHashMap<>();

        ResponsiveScaler(JPanel root, int designWidth, int designHeight) {
            this.root = root;
            this.designWidth = designWidth;
            this.designHeight = designHeight;

            capture(root);
            update();
        }

        private void capture(Container parent) {
            for (Component component : parent.getComponents()) {
                originalBounds.put(
                        component,
                        new java.awt.Rectangle(component.getBounds()));

                if (component instanceof JComponent) {
                    JComponent jc = (JComponent) component;

                    if (jc.getFont() != null) {
                        originalFonts.put(jc, jc.getFont());
                    }

                    Icon icon = null;

                    if (jc instanceof javax.swing.JLabel) {
                        icon = ((javax.swing.JLabel) jc).getIcon();
                    } else if (jc instanceof AbstractButton) {
                        icon = ((AbstractButton) jc).getIcon();
                    }

                    if (icon != null) {
                        originalIcons.put(jc, icon);
                    }
                }

                
                if (component instanceof Container) {
                    Container child = (Container) component;
                    capture(child);
                    child.setLayout(null);
                }
            }
        }
        
         void update() {
            if (root.getWidth() <= 0 || root.getHeight() <= 0) {
                return;
            }

            double scaleX = root.getWidth() / (double) designWidth;
            double scaleY = root.getHeight() / (double) designHeight;

           
            double uniformScale = Math.min(scaleX, scaleY);

            for (Map.Entry<Component, java.awt.Rectangle> entry
                    : originalBounds.entrySet()) {

                Component component = entry.getKey();
                java.awt.Rectangle original = entry.getValue();

                int x = (int) Math.round(original.x * scaleX);
                int y = (int) Math.round(original.y * scaleY);
                int width = Math.max(
                        1, (int) Math.round(original.width * scaleX));
                int height = Math.max(
                        1, (int) Math.round(original.height * scaleY));

                component.setBounds(x, y, width, height);
            }

            for (Map.Entry<JComponent, Font> entry
                    : originalFonts.entrySet()) {

                JComponent component = entry.getKey();
                Font original = entry.getValue();

                int size = Math.max(
                        8,
                        (int) Math.round(original.getSize2D() * uniformScale));

                component.setFont(original.deriveFont(
                        original.getStyle(), (float) size));
            }

            for (Map.Entry<JComponent, Icon> entry
                    : originalIcons.entrySet()) {

                JComponent component = entry.getKey();
                Icon originalIcon = entry.getValue();

                if (!(originalIcon instanceof ImageIcon)) {
                    continue;
                }

                ImageIcon imageIcon = (ImageIcon) originalIcon;
                Image image = imageIcon.getImage();

                int width = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconWidth() * scaleX));
                int height = Math.max(
                        1,
                        (int) Math.round(
                                imageIcon.getIconHeight() * scaleY));

                Image scaledImage = image.getScaledInstance(
                        width, height, Image.SCALE_SMOOTH);

                ImageIcon scaledIcon = new ImageIcon(scaledImage);

                if (component instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) component).setIcon(scaledIcon);
                } else if (component instanceof AbstractButton) {
                    ((AbstractButton) component).setIcon(scaledIcon);
                }
            }

            root.revalidate();
            root.repaint();
        }
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        masterPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        Icon = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        dashboard = new javax.swing.JButton();
        manage = new javax.swing.JButton();
        stock = new javax.swing.JButton();
        stockout = new javax.swing.JButton();
        view = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });

        masterPanel.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                masterPanelComponentResized(evt);
            }
        });
        masterPanel.setLayout(null);

        Icon.setBackground(new java.awt.Color(9, 9, 89));
        Icon.setForeground(new java.awt.Color(0, 0, 102));
        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\1000520408.jpg")); // NOI18N
        Icon.setText("jLabel2");
        Icon.setOpaque(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        masterPanel.add(jPanel1);
        jPanel1.setBounds(0, 0, 379, 110);

        jPanel2.setBackground(new java.awt.Color(226, 136, 1));

        dashboard.setBackground(new java.awt.Color(255, 204, 51));
        dashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dashboard.setForeground(new java.awt.Color(0, 0, 204));
        dashboard.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        dashboard.setText("  Dashboard ");
        dashboard.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        dashboard.setFocusPainted(false);
        dashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dashboard.addActionListener(this::dashboardActionPerformed);

        manage.setBackground(new java.awt.Color(255, 255, 51));
        manage.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        manage.setForeground(new java.awt.Color(0, 0, 204));
        manage.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (5).png")); // NOI18N
        manage.setText("Manage Inventory  ");
        manage.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manage.addActionListener(this::manageActionPerformed);

        stock.setBackground(new java.awt.Color(255, 255, 51));
        stock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stock.setForeground(new java.awt.Color(0, 0, 204));
        stock.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (2).png")); // NOI18N
        stock.setText("Stock In/Arrivals");
        stock.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stock.addActionListener(this::stockActionPerformed);

        stockout.setBackground(new java.awt.Color(255, 255, 51));
        stockout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        stockout.setForeground(new java.awt.Color(0, 0, 204));
        stockout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (1).png")); // NOI18N
        stockout.setText("Stock Out/Sales");
        stockout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        stockout.addActionListener(this::stockoutActionPerformed);

        view.setBackground(new java.awt.Color(255, 255, 51));
        view.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        view.setForeground(new java.awt.Color(0, 0, 204));
        view.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (3).png")); // NOI18N
        view.setText("SmartStock Reports");
        view.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        view.addActionListener(this::viewActionPerformed);

        logout.setBackground(new java.awt.Color(255, 255, 51));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 0, 204));
        logout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools (4).png")); // NOI18N
        logout.setText("Log Out");
        logout.setFocusPainted(false);
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 102));
        jLabel16.setText("Main Menu");

        jPanel29.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 272, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(123, 123, 123))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(manage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(stockout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dashboard)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(manage)
                .addGap(18, 18, 18)
                .addComponent(stock)
                .addGap(18, 18, 18)
                .addComponent(stockout)
                .addGap(18, 18, 18)
                .addComponent(view)
                .addGap(45, 45, 45)
                .addComponent(logout)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel2);
        jPanel2.setBounds(0, 111, 380, 540);

        jPanel3.setBackground(new java.awt.Color(9, 9, 89));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 153, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Micov\\OneDrive\\Documents\\NetBeansProjects\\SmartStock_Inventory_System\\images\\output-smallpngtools.png")); // NOI18N
        jLabel3.setText("Dashboard Overview");

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 405, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(169, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel3)
                .addGap(16, 16, 16)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel3);
        jPanel3.setBounds(376, 0, 730, 110);

        jPanel5.setBackground(new java.awt.Color(255, 102, 0));
        jPanel5.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Products");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(136, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        masterPanel.add(jPanel5);
        jPanel5.setBounds(400, 140, 200, 40);

        jPanel6.setBackground(new java.awt.Color(255, 51, 0));
        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("128");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("*Overall Products*");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel6))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel2)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        masterPanel.add(jPanel6);
        jPanel6.setBounds(400, 180, 200, 100);

        jPanel7.setBackground(new java.awt.Color(0, 51, 153));
        jPanel7.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Units Sold");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addContainerGap(127, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
        );

        masterPanel.add(jPanel7);
        jPanel7.setBounds(630, 140, 200, 40);

        jPanel8.setBackground(new java.awt.Color(0, 0, 153));
        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("20,474");

        jLabel9.setBackground(new java.awt.Color(0, 0, 153));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("*For this Month*");
        jLabel9.setOpaque(true);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel7))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addContainerGap())
        );

        masterPanel.add(jPanel8);
        jPanel8.setBounds(630, 180, 200, 101);

        jPanel9.setBackground(new java.awt.Color(51, 153, 0));
        jPanel9.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Revenue");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(139, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addContainerGap())
        );

        masterPanel.add(jPanel9);
        jPanel9.setBounds(870, 140, 200, 40);

        jPanel10.setBackground(new java.awt.Color(0, 204, 0));
        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("381,750");

        jLabel11.setBackground(new java.awt.Color(0, 204, 0));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("*For this Month*");
        jLabel11.setOpaque(true);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel8))
                .addGap(36, 36, 36))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addContainerGap())
        );

        masterPanel.add(jPanel10);
        jPanel10.setBounds(870, 180, 200, 100);

        jPanel11.setBackground(new java.awt.Color(204, 153, 0));
        jPanel11.setBorder(new javax.swing.border.MatteBorder(null));

        jButton3.setBackground(new java.awt.Color(255, 153, 0));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText(" Alerts / Recent Activity");
        jButton3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addContainerGap(499, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(9, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addContainerGap())
        );

        masterPanel.add(jPanel11);
        jPanel11.setBounds(410, 310, 660, 40);

        jPanel12.setBackground(new java.awt.Color(255, 204, 0));
        jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("- No low stock items.");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("- No recent stock out.");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("- No recent stock in.");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 487, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(163, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel10)
                .addGap(14, 14, 14)
                .addComponent(jLabel14)
                .addGap(14, 14, 14)
                .addComponent(jLabel15)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        masterPanel.add(jPanel12);
        jPanel12.setBounds(410, 350, 660, 120);

        jPanel22.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel22);
        jPanel22.setBounds(380, 20, 10, 630);

        jPanel21.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel21);
        jPanel21.setBounds(1090, 20, 10, 630);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel13);
        jPanel13.setBounds(380, 550, 340, 20);

        jPanel14.setBackground(new java.awt.Color(255, 153, 0));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel14);
        jPanel14.setBounds(380, 590, 610, 20);

        jPanel16.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel16);
        jPanel16.setBounds(730, 550, 370, 20);

        jPanel17.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel17);
        jPanel17.setBounds(1000, 590, 100, 20);

        jPanel15.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel15);
        jPanel15.setBounds(390, 110, 700, 10);

        jPanel18.setBackground(new java.awt.Color(255, 204, 0));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel18);
        jPanel18.setBounds(1070, 330, 10, 140);

        jPanel19.setBackground(new java.awt.Color(204, 51, 0));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel19);
        jPanel19.setBounds(600, 160, 10, 120);

        jPanel20.setBackground(new java.awt.Color(0, 51, 204));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel20);
        jPanel20.setBounds(830, 160, 10, 120);

        jPanel23.setBackground(new java.awt.Color(51, 204, 0));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel23);
        jPanel23.setBounds(1070, 160, 10, 120);

        jPanel24.setBackground(new java.awt.Color(0, 51, 204));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel24);
        jPanel24.setBounds(680, 490, 20, 20);

        jPanel25.setBackground(new java.awt.Color(204, 0, 0));

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel25);
        jPanel25.setBounds(640, 490, 20, 20);

        jPanel26.setBackground(new java.awt.Color(255, 204, 0));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel26);
        jPanel26.setBounds(720, 490, 20, 20);

        jPanel27.setBackground(new java.awt.Color(102, 255, 0));

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel27);
        jPanel27.setBounds(760, 490, 20, 20);

        jPanel28.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        masterPanel.add(jPanel28);
        jPanel28.setBounds(800, 490, 20, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(masterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

     private void openPage(JFrame nextPage) {

    java.awt.Rectangle currentBounds = this.getBounds();

    boolean maximized =
            (this.getExtendedState() & JFrame.MAXIMIZED_BOTH)
            == JFrame.MAXIMIZED_BOTH;

    nextPage.setVisible(true);

    if (maximized) {
        nextPage.setExtendedState(JFrame.MAXIMIZED_BOTH);
    } else {
        nextPage.setBounds(currentBounds);
    }

    this.dispose();
}
    
    private void dashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardActionPerformed
     
    }//GEN-LAST:event_dashboardActionPerformed

    private void manageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageActionPerformed
        ManagePage manage = new ManagePage();
        openPage(manage);
    }//GEN-LAST:event_manageActionPerformed

    private void stockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockActionPerformed
        StockinPage stockin = new StockinPage();
        openPage(stockin);
    }//GEN-LAST:event_stockActionPerformed

    private void stockoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stockoutActionPerformed
        StockoutPage stockout = new StockoutPage();
        openPage(stockout);
    }//GEN-LAST:event_stockoutActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        ViewReportPage view = new ViewReportPage();
        openPage(view);
    }//GEN-LAST:event_viewActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = javax.swing.JOptionPane.showConfirmDialog(this, "Do you want to Logout?", "Log Out", javax.swing.JOptionPane.YES_NO_OPTION);

        if (choice == javax.swing.JOptionPane.YES_OPTION) {
            LoginPage loginForm = new LoginPage();
            loginForm.setVisible(true);
            UserSession.clearSession();
            this.dispose();
        } else {}
    }//GEN-LAST:event_logoutActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        loadDashboard();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void masterPanelComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_masterPanelComponentResized
        if (responsiveScaler != null) {
            responsiveScaler.update();
        }
    }//GEN-LAST:event_masterPanelComponentResized

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
         if (responsiveScaler != null) {
            responsiveScaler.update();
         }
    }//GEN-LAST:event_formComponentResized

 
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new HomePage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JButton dashboard;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton logout;
    private javax.swing.JButton manage;
    private javax.swing.JPanel masterPanel;
    private javax.swing.JButton stock;
    private javax.swing.JButton stockout;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables
}
