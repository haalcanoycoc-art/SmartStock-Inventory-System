-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2026 at 09:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartstock_inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activity_log`
--

CREATE TABLE `tbl_activity_log` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_activity_log`
--

INSERT INTO `tbl_activity_log` (`id`, `users_id`, `activity`, `created_at`) VALUES
(1, 1, 'Product edited: pencil', '2026-10-14 19:47:37'),
(2, 1, 'Sale recorded: anime -1', '2026-10-14 19:50:51'),
(3, 5, 'Product added: Ballpen', '2026-10-15 12:09:46'),
(4, 5, 'Product edited: Paper', '2026-10-15 12:16:35'),
(5, 5, 'Product edited: Notebook', '2026-10-15 12:16:46'),
(6, 5, 'Product edited: Chicken', '2026-10-15 12:16:54'),
(7, 5, 'Product added: Cantoon', '2026-10-15 12:17:56'),
(8, 5, 'Product added: Pencil', '2026-10-15 12:19:59'),
(9, 5, 'Product edited: Notebook', '2026-10-15 12:20:06'),
(10, 5, 'Product edited: Ballpen', '2026-10-15 12:20:12'),
(11, 5, 'Product edited: Paper', '2026-10-15 12:20:18'),
(12, 5, 'Stock In recorded: Ballpen +50', '2026-10-15 12:20:43'),
(13, 5, 'Stock In recorded: Cantoon +25', '2026-10-15 12:21:15'),
(14, 5, 'Stock In edited: Ballpen (Received)', '2026-10-15 12:21:29'),
(15, 5, 'Stock In edited: Cantoon (Received)', '2026-10-15 12:21:41'),
(16, 5, 'Sale recorded: Ballpen -10', '2026-10-15 12:24:49'),
(17, 5, 'Stock In recorded: Notebook +30', '2026-10-15 12:40:00'),
(18, 5, 'Stock In recorded: Ballpen +10', '2026-10-15 12:40:19'),
(19, 5, 'Stock In edited: Ballpen (Received)', '2026-10-15 12:40:45'),
(20, 5, 'Stock In edited: Notebook (Received)', '2026-10-15 12:41:07'),
(21, 5, 'Product added: Junkfood', '2026-10-15 13:45:14'),
(22, 5, 'Stock In recorded: Junkfood +15', '2026-10-15 13:45:45'),
(23, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 13:45:51'),
(24, 5, 'Product edited: Junkfood', '2026-10-15 13:47:25'),
(25, 5, 'Product edited: Junkfood', '2026-10-15 13:48:17'),
(26, 5, 'Product edited: Junkfood', '2026-10-15 13:48:34'),
(27, 5, 'Stock In archived: Junkfood', '2026-10-15 13:56:26'),
(28, 5, 'Stock In restored: Junkfood', '2026-10-15 13:56:51'),
(29, 5, 'Stock In archived: Junkfood', '2026-10-15 13:56:59'),
(30, 5, 'Stock In restored: Junkfood', '2026-10-15 13:57:14'),
(31, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 13:57:22'),
(32, 5, 'Stock In archived: Junkfood', '2026-10-15 13:57:31'),
(33, 5, 'Stock In restored: Junkfood', '2026-10-15 13:57:38'),
(34, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 13:57:46'),
(35, 5, 'Product edited: Junkfood', '2026-10-15 14:02:14'),
(36, 1, 'Stock In recorded: pencil +30', '2026-10-15 17:48:44'),
(37, 1, 'Stock In edited: pencil (Received)', '2026-10-15 17:48:57'),
(38, 1, 'Product added: Chicken', '2026-10-15 18:45:07'),
(39, 1, 'Stock In recorded: Chicken +5', '2026-10-15 18:45:58'),
(40, 1, 'Stock In edited: Chicken (Received)', '2026-10-15 18:46:06'),
(41, 1, 'Sale recorded: Chicken -5', '2026-10-15 18:46:16'),
(42, 1, 'Product edited: Chicken', '2026-10-15 19:31:51'),
(43, 1, 'Stock In edited: Chicken (Received)', '2026-10-15 19:32:05'),
(44, 5, 'Sale recorded: Ballpen -10', '2026-10-15 19:36:48'),
(45, 5, 'Stock In recorded: Junkfood +15', '2026-10-15 19:37:47'),
(46, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 19:37:56'),
(47, 5, 'Sale recorded: Junkfood -15', '2026-10-15 19:38:22'),
(48, 5, 'Sale recorded: Junkfood -10', '2026-10-15 19:38:54'),
(49, 5, 'Sale recorded: Junkfood -5', '2026-10-15 19:39:26'),
(50, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 19:53:18'),
(51, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 19:53:23'),
(52, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 19:53:41'),
(53, 5, 'Stock In archived: Junkfood', '2026-10-15 19:53:58'),
(54, 5, 'Stock In archived: Junkfood', '2026-10-15 19:54:02'),
(55, 5, 'Stock In recorded: Junkfood +9', '2026-10-15 19:54:12'),
(56, 5, 'Stock In edited: Junkfood (Received)', '2026-10-15 19:54:32'),
(57, 5, 'Sale recorded: Junkfood -9', '2026-10-15 19:54:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL COMMENT 'Ready'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `users_id`, `product_name`, `category`, `price`, `stock`, `supplier`, `date_added`, `status`) VALUES
(1, 0, 'hamon', 'Office', 80.00, 50, 'Gaisano', '2026-10-12 22:34:17', 'Available'),
(2, 0, 'ham', 'Others', 55.00, 100, 'Gaisano', '2026-10-12 22:34:35', 'Available'),
(3, 1, 'anime', 'Electronics', 70.00, 99, 'Gaisano', '2026-10-12 22:36:07', 'Available'),
(4, 1, 'pencil', 'Supplies', 12.00, 50, 'Gaisano', '2026-10-15 03:47:37', 'Available'),
(5, 1, 'coke', 'Consumables', 14.40, 4, 'Gaisano', '2026-10-13 00:11:07', 'Low'),
(6, 1, 'burger', 'Consumables', 50.00, 0, 'Gaisano', '2026-10-13 00:10:58', 'Empty'),
(7, 5, 'Chicken', 'Consumables', 50.00, 100, 'Gaisano', '2026-10-15 20:16:54', 'Available'),
(8, 5, 'Notebook', 'Office', 18.00, 100, 'Gaisano', '2026-10-15 20:20:06', 'Available'),
(9, 5, 'Paper', 'Office', 5.00, 100, 'Gaisano', '2026-10-15 20:20:18', 'Available'),
(10, 1, 'noodle', 'Supplies', 14.40, 5, 'Gaisano', '2026-10-13 00:10:49', 'Low'),
(11, 5, 'Ballpen', 'Office', 12.00, 90, 'Gaisano', '2026-10-15 20:20:12', 'Available'),
(12, 5, 'Cantoon', 'Consumables', 18.00, 50, 'Gaisano', '2026-10-15 20:17:56', 'Available'),
(13, 5, 'Pencil', 'Office', 10.00, 20, 'Gaisano', '2026-10-15 20:19:59', 'Available'),
(14, 5, 'Junkfood', 'Consumables', 12.00, 20, 'Gaisano', '2026-10-15 22:02:14', 'Available'),
(15, 1, 'Chicken', 'Supplies', 60.00, 5, 'Gaisano', '2026-10-16 03:31:51', 'Low');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stockout_allocations`
--

CREATE TABLE `tbl_stockout_allocations` (
  `id` int(11) NOT NULL,
  `stockout_id` int(11) NOT NULL,
  `stockin_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_stockout_allocations`
--

INSERT INTO `tbl_stockout_allocations` (`id`, `stockout_id`, `stockin_id`, `quantity`) VALUES
(1, 17, 22, 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stocks_in`
--

CREATE TABLE `tbl_stocks_in` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_in` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Received',
  `movement_type` varchar(20) NOT NULL DEFAULT 'Arrival',
  `remaining_quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_stocks_in`
--

INSERT INTO `tbl_stocks_in` (`id`, `users_id`, `product_id`, `product_name`, `quantity`, `date_in`, `status`, `movement_type`, `remaining_quantity`) VALUES
(2, 1, 3, 'anime', 50, '2026-10-09', 'Received', 'Arrival', 50),
(3, 1, 4, 'pencil', 150, '2026-10-10', 'Received', 'Arrival', 150),
(7, 1, 5, 'coke', 5, '2026-10-10', 'Received', 'Arrival', 5),
(8, 1, 4, 'pencil', 4, '2026-10-11', 'Received', 'Arrival', 0),
(9, 5, 7, 'Chicken', 100, '2026-10-11', 'Received', 'Arrival', 100),
(10, 1, 10, 'noodle', 40, '2026-10-11', 'Received', 'Arrival', 0),
(11, 1, 10, 'noodle', 5, '2026-10-12', 'Received', 'Arrival', 0),
(12, 1, 5, 'coke', 3, '2026-10-12', 'Archived', 'Arrival', 0),
(13, 1, 10, 'noodle', 3, '2026-10-12', 'Archived', 'Arrival', 0),
(14, 5, 11, 'Ballpen', 50, '2026-10-15', 'Received', 'Arrival', 0),
(15, 5, 12, 'Cantoon', 25, '2026-10-15', 'Received', 'Arrival', 0),
(16, 5, 8, 'Notebook', 30, '2026-10-15', 'Received', 'Arrival', 0),
(17, 5, 11, 'Ballpen', 10, '2026-10-15', 'Received', 'Arrival', 0),
(18, 5, 14, 'Junkfood', 1, '2026-10-15', 'Archived', 'Arrival', 0),
(19, 1, 4, 'pencil', 30, '2026-10-16', 'Received', 'Arrival', 0),
(20, 1, 15, 'Chicken', 10, '2026-10-16', 'Received', 'Arrival', 0),
(21, 5, 14, 'Junkfood', 5, '2026-10-16', 'Archived', 'Arrival', 0),
(22, 5, 14, 'Junkfood', 0, '2026-10-16', 'Archived', 'Arrival', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stocks_out`
--

CREATE TABLE `tbl_stocks_out` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `costumer` varchar(100) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `date_out` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Completed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_stocks_out`
--

INSERT INTO `tbl_stocks_out` (`id`, `users_id`, `product_id`, `product_name`, `quantity`, `costumer`, `total_amount`, `date_out`, `status`) VALUES
(1, 1, 3, 'anime', 140, 'mico', 9800.00, '2026-10-10', 'Archived'),
(2, 1, 4, 'pencil', 245, 'mico', 1225.00, '2026-10-10', 'Archived'),
(4, 1, 5, 'coke', 5, 'mico', 50.00, '2026-10-09', 'Completed'),
(5, 1, 3, 'anime', 10, 'mico', 700.00, '2026-10-10', 'Completed'),
(6, 1, 5, 'coke', 5, 'mico', 50.00, '2026-10-10', 'Completed'),
(7, 1, 5, 'coke', 1, 'mico', 10.00, '2026-10-10', 'Completed'),
(8, 1, 4, 'pencil', 1, 'mico', 5.00, '2026-10-11', 'Completed'),
(9, 5, 7, 'Chicken', 100, 'Mico', 5000.00, '2026-10-11', 'Completed'),
(10, 1, 3, 'anime', 1, 'mico', 70.00, '2026-10-15', 'Completed'),
(11, 5, 11, 'Ballpen', 10, 'mico', 120.00, '2026-10-15', 'Completed'),
(12, 1, 15, 'Chicken', 5, 'mico', 300.00, '2026-10-16', 'Completed'),
(13, 5, 11, 'Ballpen', 10, 'mico', 120.00, '2026-10-16', 'Completed'),
(14, 5, 14, 'Junkfood', 15, 'mico', 180.00, '2026-10-16', 'Completed'),
(15, 5, 14, 'Junkfood', 10, 'mico', 120.00, '2026-10-16', 'Completed'),
(16, 5, 14, 'Junkfood', 5, 'mico', 60.00, '2026-10-16', 'Completed'),
(17, 5, 14, 'Junkfood', 9, 'mico', 108.00, '2026-10-16', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `users_id` int(11) NOT NULL,
  `username` varchar(127) NOT NULL,
  `password` varchar(127) NOT NULL,
  `fullname` varchar(127) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`users_id`, `username`, `password`, `fullname`, `role`, `created_at`) VALUES
(1, 'mico', '123', 'Mico Vence Cabilto', 'user', '2026-10-11 18:13:50'),
(2, 'micovence', '1234567', 'Mico Vence O. Cabilto', 'user', '2026-10-11 18:13:50'),
(3, 'mamon', 'mamon123', 'arjie carged aguilar', 'user', '2026-10-11 18:13:50'),
(5, 'mico', 'Mico@123', 'mico vence cabilto', 'user', '2026-10-11 18:13:50'),
(6, 'mico', 'Mico@123', 'Mico Vence O. Cabilto', 'user', '2026-10-11 18:13:50'),
(7, 'admin', 'admin123', 'Mico Vence Cabilto', 'admin', '2026-10-11 18:13:50'),
(8, 'mico', 'Mico@123', 'mico vence cabilto', 'user', '2026-10-12 04:22:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activity_log`
--
ALTER TABLE `tbl_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_stockout_allocations`
--
ALTER TABLE `tbl_stockout_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stockout_id` (`stockout_id`),
  ADD KEY `stockin_id` (`stockin_id`);

--
-- Indexes for table `tbl_stocks_in`
--
ALTER TABLE `tbl_stocks_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_stocks_out`
--
ALTER TABLE `tbl_stocks_out`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activity_log`
--
ALTER TABLE `tbl_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_stockout_allocations`
--
ALTER TABLE `tbl_stockout_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_stocks_in`
--
ALTER TABLE `tbl_stocks_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_stocks_out`
--
ALTER TABLE `tbl_stocks_out`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
